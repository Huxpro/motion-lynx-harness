import * as ReactLynx from "@lynx-js/react";
const __snapshot_da39a_test_3 = "__snapshot_da39a_test_3";
ReactLynx.snapshotCreatorMap[__snapshot_da39a_test_3] = (__snapshot_da39a_test_3)=>ReactLynx.createSnapshot(__snapshot_da39a_test_3, function() {
        const pageId = ReactLynx.__pageId;
        const el = __CreateElement("list-item", pageId);
        return [
            el
        ];
    }, null, null, undefined, globDynamicComponentEntry, null, true);
const __snapshot_da39a_test_4 = "__snapshot_da39a_test_4";
ReactLynx.snapshotCreatorMap[__snapshot_da39a_test_4] = (__snapshot_da39a_test_4)=>ReactLynx.createSnapshot(__snapshot_da39a_test_4, function() {
        const pageId = ReactLynx.__pageId;
        const el = __CreateElement("list-item", pageId);
        return [
            el
        ];
    }, null, null, undefined, globDynamicComponentEntry, null, true);
const __snapshot_da39a_test_2 = "__snapshot_da39a_test_2";
ReactLynx.snapshotCreatorMap[__snapshot_da39a_test_2] = (__snapshot_da39a_test_2)=>ReactLynx.createSnapshot(__snapshot_da39a_test_2, function(snapshotInstance) {
        const pageId = ReactLynx.__pageId;
        const el = ReactLynx.snapshotCreateList(pageId, snapshotInstance, 0);
        return [
            el
        ];
    }, null, [
        [
            ReactLynx.__DynamicPartListSlotV2,
            0
        ]
    ], undefined, globDynamicComponentEntry, null, true);
const __snapshot_da39a_test_1 = "__snapshot_da39a_test_1";
ReactLynx.snapshotCreatorMap[__snapshot_da39a_test_1] = (__snapshot_da39a_test_1)=>ReactLynx.createSnapshot(__snapshot_da39a_test_1, function() {
        const pageId = ReactLynx.__pageId;
        const el = __CreateView(pageId);
        const el1 = __CreateWrapperElement(pageId);
        __AppendElement(el, el1);
        const el2 = __CreateView(pageId);
        __AppendElement(el, el2);
        return [
            el,
            el1,
            el2
        ];
    }, null, [
        [
            ReactLynx.__DynamicPartSlotV2,
            1
        ],
        [
            ReactLynx.__DynamicPartSlotV2,
            2
        ]
    ], undefined, globDynamicComponentEntry, null, true);
<__snapshot_da39a_test_1 $0={<__snapshot_da39a_test_2 $0={<>
          <__snapshot_da39a_test_3/>
          <__snapshot_da39a_test_4/>
        </>}/>} $1={<A/>}/>;
