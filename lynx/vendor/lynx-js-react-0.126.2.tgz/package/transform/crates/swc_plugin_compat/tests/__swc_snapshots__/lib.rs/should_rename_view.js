const a = <view/>;
