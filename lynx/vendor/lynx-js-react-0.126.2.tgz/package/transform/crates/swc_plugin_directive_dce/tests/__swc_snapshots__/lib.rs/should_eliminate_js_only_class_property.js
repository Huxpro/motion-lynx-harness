class Test {
    method = ()=>{};
    #privateMethod = ()=>{};
}
