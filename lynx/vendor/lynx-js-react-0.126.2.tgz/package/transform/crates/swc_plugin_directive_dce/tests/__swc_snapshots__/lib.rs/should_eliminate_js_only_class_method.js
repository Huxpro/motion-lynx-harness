class Test {
    method() {}
    #privateMethod() {}
}
