export default function useExposure() {}
