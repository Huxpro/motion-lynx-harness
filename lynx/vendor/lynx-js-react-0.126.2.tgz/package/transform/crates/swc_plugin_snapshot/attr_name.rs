use swc_core::ecma::ast::*;
use swc_plugins_shared::lynx_event::parse_lynx_event_attribute_name;

#[derive(Debug, Clone)]
pub enum AttrName {
  Attr(String),
  Dataset(String),
  Event(String, String),
  WorkletEvent(
    /* worklet_type */ String,
    /* event_type */ String,
    /* event_name */ String,
  ),
  Style,
  Class,
  ID,
  Ref,
  TimingFlag,
  WorkletRef(/* worklet_type */ String),
  ListItemPlatformInfo,
  Gesture(String),
}

impl From<String> for AttrName {
  fn from(name: String) -> Self {
    if let Some(stripped_name) = name.strip_prefix("data-") {
      AttrName::Dataset(stripped_name.to_string())
    } else if name == "class" || name == "className" {
      AttrName::Class
    } else if name == "style" {
      AttrName::Style
    } else if name == "id" {
      AttrName::ID
    } else if name == "ref" {
      AttrName::Ref
    } else if name == "__lynx_timing_flag" {
      AttrName::TimingFlag
    } else if let Some((event_type, event_name)) = get_event_type_and_name(name.as_str()) {
      AttrName::Event(event_type, event_name)
    } else {
      AttrName::Attr(name)
    }
  }
}

impl From<Str> for AttrName {
  fn from(name: Str) -> Self {
    let name = name.value.to_string_lossy().into_owned();
    Self::from(name)
  }
}

impl From<Ident> for AttrName {
  fn from(name: Ident) -> Self {
    let name = name.sym.as_ref().to_string();
    Self::from(name)
  }
}

impl AttrName {
  pub fn from_ns(ns: Ident, name: Ident) -> Self {
    let ns_str = ns.sym.as_ref().to_string();
    let name_str = name.sym.as_ref().to_string();
    if name_str == "ref" {
      AttrName::WorkletRef(ns_str)
    } else if let Some((event_type, event_name)) = get_event_type_and_name(name_str.as_str()) {
      AttrName::WorkletEvent(ns_str, event_type, event_name)
    } else if name_str == "gesture" {
      AttrName::Gesture(ns_str)
    } else {
      todo!()
    }
  }
}

fn get_event_type_and_name(props_key: &str) -> Option<(String, String)> {
  let (event_type, event_name) = parse_lynx_event_attribute_name(props_key)?;
  let event_type = if event_type.contains("capture") {
    event_type.to_string()
  } else {
    format!("{event_type}Event")
  };
  Some((event_type, event_name.to_string()))
}
