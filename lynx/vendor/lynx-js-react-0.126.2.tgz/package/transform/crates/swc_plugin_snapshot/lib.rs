use serde::Deserialize;
use std::{
  cell::RefCell,
  collections::{HashMap, HashSet},
  rc::Rc,
};

use once_cell::sync::Lazy;
use swc_core::{
  common::{
    comments::{CommentKind, Comments},
    errors::HANDLER,
    sync::Lrc,
    util::take::Take,
    Mark, SourceMap, Span, Spanned, SyntaxContext, DUMMY_SP,
  },
  ecma::{
    ast::{JSXExpr, *},
    utils::{is_literal, prepend_stmt, private_ident},
    visit::{VisitMut, VisitMutWith},
  },
  quote, quote_expr,
};

mod attr_name;
mod legacy_slot;

#[cfg(feature = "napi")]
pub mod napi;

use swc_plugins_shared::{
  css::get_string_inline_style_from_literal,
  defines::{collect_define, DefineKind, DefinesCollector},
  jsx_helpers::{
    jsx_attr_name, jsx_attr_to_prop, jsx_attr_value, jsx_children_to_expr, jsx_has_dynamic_key,
    jsx_is_children_full_dynamic, jsx_is_custom, jsx_is_list, jsx_is_list_item, jsx_name,
    jsx_props_to_obj, jsx_text_to_str, transform_jsx_attr_str,
  },
  target::TransformTarget,
  transform_mode::TransformMode,
  utils::{calc_hash, calc_hash_number},
};

use self::attr_name::AttrName;

// impl From<i32> for Expr {
//     fn from(value: i32) -> Self {
//         Expr::Lit(Lit::Num(Number {
//             span: DUMMY_SP,
//             value: value as f64,
//             raw: None,
//         }))
//     }
// }

static WRAPPER_NODE: Lazy<JSXElement> = Lazy::new(|| JSXElement {
  span: DUMMY_SP,
  opening: JSXOpeningElement {
    span: DUMMY_SP,
    name: JSXElementName::Ident(Ident::new(
      "wrapper".into(),
      DUMMY_SP,
      SyntaxContext::default(),
    )),
    attrs: vec![],
    self_closing: true,
    type_args: None,
  },
  closing: None,
  children: vec![],
});

static WRAPPER_NODE_2: Lazy<JSXElement> = Lazy::new(|| JSXElement {
  span: DUMMY_SP,
  opening: JSXOpeningElement {
    span: DUMMY_SP,
    name: JSXElementName::Ident(Ident::new(
      "wrapper".into(),
      DUMMY_SP,
      SyntaxContext::default(),
    )),
    attrs: vec![],
    self_closing: false,
    type_args: None,
  },
  closing: Some(JSXClosingElement {
    span: DUMMY_SP,
    name: JSXElementName::Ident(Ident::new(
      "wrapper".into(),
      DUMMY_SP,
      SyntaxContext::default(),
    )),
  }),
  children: vec![],
});

static NO_FLATTEN_ATTRIBUTES: Lazy<HashSet<String>> = Lazy::new(|| {
  HashSet::from([
    "name".to_string(),
    "clip-radius".to_string(),
    "overlap".to_string(),
    "exposure-scene".to_string(),
    "exposure-id".to_string(),
  ])
});

#[derive(Clone, Debug, Deserialize)]
pub struct UISourceMapRecord {
  pub ui_source_map: i32,
  pub line_number: u32,
  pub column_number: u32,
  pub snapshot_id: String,
}

#[derive(Debug)]
pub enum DynamicPart {
  Attr(Expr, i32, AttrName),
  Spread(Expr, i32, bool),
  Slot(Expr, i32),
  ListSlot(Expr, i32),
}

pub fn i32_to_expr(i: &i32) -> Expr {
  Expr::Lit(Lit::Num(Number {
    span: DUMMY_SP,
    value: *i as f64,
    raw: None,
  }))
}

pub fn bool_to_expr(b: &bool) -> Expr {
  Expr::Lit(Lit::Bool(Bool {
    span: DUMMY_SP,
    value: *b,
  }))
}

fn bool_jsx_attr(value: bool) -> JSXAttrValue {
  JSXAttrValue::JSXExprContainer(JSXExprContainer {
    span: DUMMY_SP,
    expr: JSXExpr::Expr(Box::new(Expr::Lit(Lit::Bool(Bool {
      span: DUMMY_SP,
      value,
    })))),
  })
}

impl DynamicPart {
  fn to_updater(&self, runtime_id: Expr, target: TransformTarget, exp_index: i32) -> Expr {
    match target {
      TransformTarget::LEPUS | TransformTarget::MIXED => match self {
        DynamicPart::Attr(_, element_index, attr_name) => match attr_name {
          AttrName::Attr(name) => quote!(
            "function (ctx) {
              if (ctx.__elements) {
                __SetAttribute(ctx.__elements[$element_index], $name, ctx.__values[$exp_index]);
              }
            }" as Expr,
            name: Expr = Expr::Lit(Lit::Str(name.clone().into())),
            element_index: Expr = i32_to_expr(element_index),
            exp_index: Expr = i32_to_expr(&exp_index),
          ),
          AttrName::TimingFlag => quote!(
            "function (ctx) {
              if (ctx.__elements) {
                __SetAttribute(ctx.__elements[$element_index], '__lynx_timing_flag', ctx.__values[$exp_index].__ltf);
              }
            }" as Expr,
            element_index: Expr = i32_to_expr(element_index),
            exp_index: Expr = i32_to_expr(&exp_index),
          ),
          AttrName::Dataset(name) => quote!(
            "function (ctx) {
              if (ctx.__elements) {
                __AddDataset(ctx.__elements[$element_index], $name, ctx.__values[$exp_index]);
              }
            }" as Expr,
            name: Expr = Expr::Lit(Lit::Str(name.clone().into())),
            element_index: Expr = i32_to_expr(element_index),
            exp_index: Expr = i32_to_expr(&exp_index),
          ),
          AttrName::Style => quote!(
            "function (ctx) {
              if (ctx.__elements) {
                __SetInlineStyles(ctx.__elements[$element_index], ctx.__values[$exp_index]);
              }
            }" as Expr,
            element_index: Expr = i32_to_expr(element_index),
            exp_index: Expr = i32_to_expr(&exp_index),
          ),
          AttrName::Class => quote!(
            "function (ctx) {
              if (ctx.__elements) {
                __SetClasses(ctx.__elements[$element_index], ctx.__values[$exp_index] || '');
              }
            }" as Expr,
            element_index: Expr = i32_to_expr(element_index),
            exp_index: Expr = i32_to_expr(&exp_index),
          ),
          AttrName::ID => quote!(
            "function (ctx) {
              if (ctx.__elements) {
                __SetID(ctx.__elements[$element_index], ctx.__values[$exp_index]);
              }
            }" as Expr,
            element_index: Expr = i32_to_expr(element_index),
            exp_index: Expr = i32_to_expr(&exp_index),
          ),
          AttrName::Event(event_type, event_name) => quote!(
            "(snapshot, index, oldValue) => $runtime_id.updateEvent(snapshot, index, oldValue, $element_index, $event_type, $event_name, '')" as Expr,
            runtime_id: Expr = runtime_id.clone(),
            event_type: Expr = Expr::Lit(Lit::Str(event_type.clone().into())),
            event_name: Expr = Expr::Lit(Lit::Str(event_name.clone().into())),
            element_index: Expr = i32_to_expr(element_index),
          ),
          AttrName::WorkletEvent(worklet_type, event_type, event_name) => quote!(
            "(snapshot, index, oldValue) => $runtime_id.updateWorkletEvent(snapshot, index, oldValue, $element_index, $worklet_type, $event_type, $event_name)" as Expr,
            runtime_id: Expr = runtime_id.clone(),
            worklet_type: Expr = Expr::Lit(Lit::Str(worklet_type.clone().into())),
            event_type: Expr = Expr::Lit(Lit::Str(event_type.clone().into())),
            event_name: Expr = Expr::Lit(Lit::Str(event_name.clone().into())),
            element_index: Expr = i32_to_expr(element_index),
          ),
          AttrName::Ref => quote!(
            "(snapshot, index, oldValue) => $runtime_id.updateRef(snapshot, index, oldValue, $element_index)" as Expr,
            runtime_id: Expr = runtime_id.clone(),
            element_index: Expr = i32_to_expr(element_index),
          ),
          AttrName::WorkletRef(worklet_type) => quote!(
            "(snapshot, index, oldValue) => $runtime_id.updateWorkletRef(snapshot, index, oldValue, $element_index, $worklet_type)" as Expr,
            runtime_id: Expr = runtime_id.clone(),
            element_index: Expr = i32_to_expr(element_index),
            worklet_type: Expr = Expr::Lit(Lit::Str(worklet_type.clone().into())),
          ),
          AttrName::ListItemPlatformInfo => quote!(
            "(snapshot, index, oldValue) => $runtime_id.updateListItemPlatformInfo(snapshot, index, oldValue, $element_index)" as Expr,
            runtime_id: Expr = runtime_id.clone(),
            element_index: Expr = i32_to_expr(element_index),
          ),
          AttrName::Gesture(ns) => quote!(
            "(snapshot, index, oldValue) => $runtime_id.updateGesture(snapshot, index, oldValue, $element_index, $ns)" as Expr,
            runtime_id: Expr = runtime_id.clone(),
            element_index: Expr = i32_to_expr(element_index),
            ns: Expr = Expr::Lit(Lit::Str(ns.clone().into())),
          ),
        },
        DynamicPart::Spread(_, element_index, is_list_item) => quote!(
          "(snapshot, index, oldValue) => $runtime_id.updateSpread(snapshot, index, oldValue, $element_index, $is_list_item)" as Expr,
          runtime_id: Expr = runtime_id.clone(),
          element_index: Expr = i32_to_expr(element_index),
          is_list_item: Expr = bool_to_expr(is_list_item)
        ),
        DynamicPart::Slot(_, _) => Expr::Lit(Lit::Null(Null { span: DUMMY_SP })),
        DynamicPart::ListSlot(_, _) => Expr::Lit(Lit::Null(Null { span: DUMMY_SP })),
      },
      TransformTarget::JS => Expr::Lit(Lit::Null(Null { span: DUMMY_SP })),
    }
  }
}

pub struct DynamicPartExtractor<'a, V, F>
where
  V: VisitMut,
  F: Fn(Span) -> Expr,
{
  page_id: Lazy<Ident>,
  runtime_id: Expr,
  parent_element: Option<Ident>,
  element_index: i32,
  element_ids: HashMap<i32, Ident>,
  static_stmts: Vec<RefCell<Stmt>>,
  si_id: Lazy<Ident>,
  snapshot_creator: Option<Function>,
  dynamic_parts: Vec<DynamicPart>,
  dynamic_part_visitor: &'a mut V,
  key: Option<JSXAttrValue>,
  enable_ui_source_map: bool,
  node_index_fn: F,
}

impl<'a, V, F> DynamicPartExtractor<'a, V, F>
where
  V: VisitMut,
  F: Fn(Span) -> Expr,
{
  fn new(
    runtime_id: Expr,
    dynamic_part_visitor: &'a mut V,
    enable_ui_source_map: bool,
    node_index_fn: F,
  ) -> Self {
    DynamicPartExtractor {
      page_id: Lazy::new(|| private_ident!("pageId")),
      runtime_id,
      parent_element: None,
      element_index: 0,
      element_ids: HashMap::new(),
      static_stmts: vec![],
      si_id: Lazy::new(|| private_ident!("snapshotInstance")),
      snapshot_creator: None,
      dynamic_parts: vec![],
      dynamic_part_visitor,
      key: None,
      enable_ui_source_map,
      node_index_fn,
    }
  }

  fn node_index_expr_from_span(&self, span: Span) -> Expr {
    (self.node_index_fn)(span)
  }

  fn node_index_config_expr(&self, span: Span) -> Expr {
    Expr::Object(ObjectLit {
      span: DUMMY_SP,
      props: vec![PropOrSpread::Prop(Box::new(Prop::KeyValue(KeyValueProp {
        key: PropName::Ident(IdentName::new("nodeIndex".into(), DUMMY_SP)),
        value: Box::new(self.node_index_expr_from_span(span)),
      })))],
    })
  }

  fn static_stmt_from_create_call(
    &self,
    element: Ident,
    callee: &str,
    mut args: Vec<Expr>,
    span: Span,
  ) -> Stmt {
    if self.enable_ui_source_map {
      args.push(self.node_index_config_expr(span));
    }

    Stmt::Decl(Decl::Var(Box::new(VarDecl {
      ctxt: SyntaxContext::default(),
      span: DUMMY_SP,
      kind: VarDeclKind::Const,
      declare: false,
      decls: vec![VarDeclarator {
        span: DUMMY_SP,
        definite: false,
        name: Pat::Ident(element.into()),
        init: Some(Box::new(Expr::Call(CallExpr {
          ctxt: SyntaxContext::default(),
          span: DUMMY_SP,
          callee: Callee::Expr(Box::new(Expr::Ident(
            IdentName::new(callee.into(), DUMMY_SP).into(),
          ))),
          args: args
            .into_iter()
            .map(|expr| ExprOrSpread {
              spread: None,
              expr: Box::new(expr),
            })
            .collect(),
          type_args: None,
        }))),
      }],
    })))
  }

  fn static_stmt_from_jsx_element(&mut self, n: &JSXElement, el: Ident) -> Stmt {
    let mut static_stmt: Stmt = Stmt::Empty(EmptyStmt { span: DUMMY_SP });

    if let Expr::Lit(Lit::Str(str)) = *jsx_name(n.opening.name.clone()) {
      let tag = str.value.to_string_lossy();
      match tag.as_ref() {
        "view" => {
          static_stmt = self.static_stmt_from_create_call(
            el.clone(),
            "__CreateView",
            vec![Expr::Ident(self.page_id.clone())],
            n.opening.span,
          );
        }
        "scroll-view" => {
          static_stmt = self.static_stmt_from_create_call(
            el.clone(),
            "__CreateScrollView",
            vec![Expr::Ident(self.page_id.clone())],
            n.opening.span,
          );
        }
        "x-scroll-view" => {
          static_stmt = self.static_stmt_from_create_call(
            el.clone(),
            "__CreateScrollView",
            vec![Expr::Ident(self.page_id.clone())],
            n.opening.span,
          );
        }
        "image" => {
          static_stmt = self.static_stmt_from_create_call(
            el.clone(),
            "__CreateImage",
            vec![Expr::Ident(self.page_id.clone())],
            n.opening.span,
          );
        }
        "text" => {
          static_stmt = self.static_stmt_from_create_call(
            el.clone(),
            "__CreateText",
            vec![Expr::Ident(self.page_id.clone())],
            n.opening.span,
          );
        }
        "wrapper" => {
          static_stmt = quote!(
            r#"const $element = __CreateWrapperElement($page_id)"# as Stmt,
            element = el.clone(),
            page_id = self.page_id.clone(),
          );
        }
        "list" => {
          static_stmt = quote!(
              r#"const $element = $runtime_id.snapshotCreateList($page_id, $si_id, $element_index)"#
                  as Stmt,
              element = el.clone(),
              runtime_id: Expr = self.runtime_id.clone(),
              page_id = self.page_id.clone(),
              si_id = self.si_id.clone(),
              element_index: Expr = Expr::Lit(Lit::Num(Number { span: DUMMY_SP, value: self.element_index as f64, raw: None })),
          );
        }
        "frame" => {
          static_stmt = self.static_stmt_from_create_call(
            el.clone(),
            "__CreateFrame",
            vec![Expr::Ident(self.page_id.clone())],
            n.opening.span,
          );
        }
        _ => {
          static_stmt = self.static_stmt_from_create_call(
            el.clone(),
            "__CreateElement",
            vec![Expr::Lit(Lit::Str(str)), Expr::Ident(self.page_id.clone())],
            n.opening.span,
          );
        }
      };
    }

    static_stmt
  }
}

impl<V, F> VisitMut for DynamicPartExtractor<'_, V, F>
where
  V: VisitMut,
  F: Fn(Span) -> Expr,
{
  fn visit_mut_jsx_element_childs(&mut self, n: &mut Vec<JSXElementChild>) {
    if n.is_empty() {
      return;
    }

    // merge dynamic parts together to reduce wrapper node count

    let mut merged_children: Vec<JSXElementChild> = vec![];
    let mut current_chunk: Vec<JSXElementChild> = vec![];

    for mut child in n.take() {
      let should_merge: bool;
      match child {
        JSXElementChild::JSXText(ref text) => {
          if jsx_text_to_str(&text.value).is_empty() {
            should_merge = current_chunk.is_empty();
          } else {
            should_merge = true;
          }
        }
        JSXElementChild::JSXElement(ref element) => {
          should_merge = !jsx_is_custom(element);
        }
        JSXElementChild::JSXExprContainer(JSXExprContainer {
          expr: JSXExpr::Expr(ref _expr),
          ..
        }) => {
          should_merge = false;
        }
        JSXElementChild::JSXFragment(_)
        | JSXElementChild::JSXExprContainer(JSXExprContainer {
          expr: JSXExpr::JSXEmptyExpr(_),
          ..
        }) => {
          should_merge = true;
        }
        JSXElementChild::JSXSpreadChild(_) => {
          unreachable!("JSXSpreadChild is not supported yet");
        }
      }

      if should_merge {
        if !current_chunk.is_empty() {
          current_chunk.visit_mut_with(self.dynamic_part_visitor);
          self.dynamic_parts.push(DynamicPart::Slot(
            jsx_children_to_expr(current_chunk.take()),
            self.element_index,
          ));

          let mut child = JSXElementChild::JSXElement(Box::new(WRAPPER_NODE_2.clone()));
          child.visit_mut_with(self);
          merged_children.push(child);
        }

        child.visit_mut_with(self);
        merged_children.push(child);
      } else {
        current_chunk.push(child);
      }
    }

    if !current_chunk.is_empty() {
      current_chunk.visit_mut_with(self.dynamic_part_visitor);
      self.dynamic_parts.push(DynamicPart::Slot(
        jsx_children_to_expr(current_chunk.take()),
        self.element_index,
      ));

      let mut child = JSXElementChild::JSXElement(Box::new(WRAPPER_NODE_2.clone()));
      child.visit_mut_with(self);
      merged_children.push(child);
    }

    *n = merged_children;
  }

  fn visit_mut_jsx_element(&mut self, n: &mut JSXElement) {
    if !jsx_is_custom(n) {
      match Lazy::<Ident>::get(&self.page_id) {
        Some(_) => {}
        None => {
          self.static_stmts.push(RefCell::new(quote!(
            r#"const $page_id = $runtime_id.__pageId"# as Stmt,
            page_id = self.page_id.clone(),
            runtime_id: Expr = self.runtime_id.clone(),
          )));
        }
      }

      let el = private_ident!("el");
      self.element_ids.insert(self.element_index, el.clone());

      if (jsx_has_dynamic_key(n)) && self.parent_element.is_some() {
        n.visit_mut_with(self.dynamic_part_visitor);
        let expr = Expr::JSXElement(Box::new(n.take()));

        if jsx_is_list(n) {
          self
            .dynamic_parts
            .push(DynamicPart::ListSlot(expr, self.element_index));
        } else {
          self
            .dynamic_parts
            .push(DynamicPart::Slot(expr, self.element_index));
        }

        *n = WRAPPER_NODE_2.clone();
      }

      let static_stmt = self.static_stmt_from_jsx_element(n, el.clone());
      let static_stmt = RefCell::new(static_stmt);
      self.static_stmts.push(static_stmt.clone());

      {
        let mut flatten = None;
        for attr in &n.opening.attrs {
          if let JSXAttrOrSpread::JSXAttr(attr) = attr {
            let name = jsx_attr_name(&attr.name.clone()).to_string();
            if NO_FLATTEN_ATTRIBUTES.contains(&name) {
              flatten = Some(JSXAttrOrSpread::JSXAttr(JSXAttr {
                span: DUMMY_SP,
                name: JSXAttrName::Ident(IdentName::new("flatten".into(), DUMMY_SP)),
                value: Some(bool_jsx_attr(false)),
              }));
              break;
            }
          }
        }

        if let Some(flatten) = flatten {
          let mut has_origin_flatten = false;
          for attr in &mut n.opening.attrs {
            if let JSXAttrOrSpread::JSXAttr(attr) = attr {
              let name = jsx_attr_name(&attr.name.clone()).to_string();
              if name == *"flatten" {
                attr.value = Some(bool_jsx_attr(false));
                has_origin_flatten = true;
              }
            }
          }
          if !has_origin_flatten {
            n.opening.attrs.push(flatten);
          }
        }
      }

      let has_spread_element = n
        .opening
        .attrs
        .iter()
        .any(|attr_or_spread| match attr_or_spread {
          JSXAttrOrSpread::SpreadElement(_) => true,
          JSXAttrOrSpread::JSXAttr(_) => false,
          #[cfg(swc_ast_unknown)]
          _ => panic!("unknown node"),
        });

      let is_list_item = jsx_is_list_item(n);
      if is_list_item {
        if has_spread_element {
        } else {
          let mut list_item_platform_info: Vec<JSXAttr> = vec![];
          n.opening.attrs.retain_mut(|attr_or_spread| {
            match attr_or_spread {
              JSXAttrOrSpread::JSXAttr(attr) => {
                if let JSXAttrName::Ident(id) = &attr.name {
                  match id.sym.to_string().as_str() {
                    "reuse-identifier"
                    | "full-span"
                    | "item-key"
                    | "sticky-top"
                    | "sticky-bottom"
                    | "estimated-height"
                    | "estimated-height-px"
                    | "estimated-main-axis-size-px"
                    | "recyclable" => {
                      list_item_platform_info.push(attr.clone());
                      return false;
                    }
                    &_ => {}
                  }
                }
              }
              JSXAttrOrSpread::SpreadElement(_spread) => {
                return false;
              }
              #[cfg(swc_ast_unknown)]
              _ => panic!("unknown node"),
            }

            true
          });
          if !list_item_platform_info.is_empty() {
            self.dynamic_parts.push(DynamicPart::Attr(
              Expr::Object(ObjectLit {
                span: DUMMY_SP,
                props: list_item_platform_info
                  .iter()
                  .map(jsx_attr_to_prop)
                  .collect(),
              }),
              self.element_index,
              AttrName::ListItemPlatformInfo,
            ));
          }
        }
      }

      // pick key from n.opening.attrs
      n.opening
        .attrs
        .retain_mut(|attr_or_spread| match attr_or_spread {
          JSXAttrOrSpread::SpreadElement(_) => true,
          JSXAttrOrSpread::JSXAttr(JSXAttr { name, value, .. }) => match name {
            JSXAttrName::Ident(ident_name) => match ident_name.sym.as_ref() {
              "key" => {
                if self.parent_element.is_none() {
                  self.key = value.take();
                }
                false
              }
              _ => true,
            },
            JSXAttrName::JSXNamespacedName(_) => true,
            #[cfg(swc_ast_unknown)]
            _ => panic!("unknown node"),
          },
          #[cfg(swc_ast_unknown)]
          _ => panic!("unknown node"),
        });

      if has_spread_element {
        // TODO: avoid clone
        let mut spread_obj = jsx_props_to_obj(n).unwrap();
        spread_obj.props.push(
          Prop::KeyValue(KeyValueProp {
            key: PropName::Ident(IdentName::new("__spread".into(), DUMMY_SP)),
            value: Expr::Lit(Lit::Bool(true.into())).into(),
          })
          .into(),
        );
        self.dynamic_parts.push(DynamicPart::Spread(
          Expr::Object(spread_obj),
          self.element_index,
          is_list_item,
        ));
      } else {
        let el = Expr::Ident(el.clone());

        n.opening
          .attrs
          .iter_mut()
          .for_each(|attr_or_spread| match attr_or_spread {
            JSXAttrOrSpread::SpreadElement(_) => todo!(),
            JSXAttrOrSpread::JSXAttr(JSXAttr { name, value, .. }) => {
              match name {
                JSXAttrName::Ident(ident_name) => {
                  let attr_name = AttrName::from(<IdentName as Into<Ident>>::into(ident_name.clone()));
                  match &attr_name {
                    AttrName::Attr(name) => {
                      match value {
                        None => {
                          let stmt = quote!(
                              r#"__SetAttribute($element, $name, $value)"# as Stmt,
                              element: Expr = el.clone(),
                              name: Expr = name.clone().into(),
                              value: Expr = Expr::Lit(Lit::Bool(Bool {span: DUMMY_SP, value: true}))
                          );
                          self.static_stmts.push(RefCell::new(stmt));
                        }
                        Some(JSXAttrValue::Str(s)) => {
                          let value = transform_jsx_attr_str(&s.value);
                          let stmt = quote!(
                              r#"__SetAttribute($element, $name, $value)"# as Stmt,
                              element: Expr = el.clone(),
                              name: Expr =  name.clone().into(),
                              value: Expr = Expr::Lit(Lit::Str(Str { span: s.span, value: value.into(), raw: None }))
                          );
                          self.static_stmts.push(RefCell::new(stmt));
                        }
                        Some(JSXAttrValue::JSXExprContainer(JSXExprContainer {
                          expr: JSXExpr::Expr(expr),
                          ..
                        })) => {
                          // expr.map_with_mut(|value| {
                          //     value.fold_with(self.dynamic_part_visitor)
                          // });
                          match &**expr {
                            Expr::Lit(value) => {
                              let stmt = quote!(
                                  r#"__SetAttribute($element, $name, $value)"# as Stmt,
                                  element: Expr = el.clone(),
                                  name: Expr =  name.clone().into(),
                                  value: Expr = Expr::Lit(value.clone())
                              );
                              self.static_stmts.push(RefCell::new(stmt));
                            }
                            _ => {
                              self.dynamic_parts.push(DynamicPart::Attr(
                                *expr.clone(),
                                self.element_index,
                                attr_name.clone(),
                              ));
                            }
                          }
                        }
                        Some(JSXAttrValue::JSXExprContainer(JSXExprContainer {
                          expr: JSXExpr::JSXEmptyExpr(_),
                          ..
                        })) => {}
                        Some(JSXAttrValue::JSXElement(_)) => unreachable!("Unexpected JSXElement in JSX attribute value - not supported"),
                        Some(JSXAttrValue::JSXFragment(_)) => unreachable!("Unexpected JSXFragment in JSX attribute value - not supported"),
                        #[cfg(swc_ast_unknown)]
                        _ => panic!("unknown node"),
                      };
                    }
                    AttrName::Dataset(name) => {
                      match value {
                        None => {
                          let stmt = quote!(
                              r#"__AddDataset($element, $name, $value)"# as Stmt,
                              element: Expr = el.clone(),
                              name: Expr =  name.clone().into(),
                              value: Expr = Expr::Lit(Lit::Bool(Bool {span: DUMMY_SP, value: true}))
                          );
                          self.static_stmts.push(RefCell::new(stmt));
                        }
                        Some(JSXAttrValue::Str(s)) => {
                          let value = transform_jsx_attr_str(&s.value);
                          let stmt = quote!(
                              r#"__AddDataset($element, $name, $value)"# as Stmt,
                              element: Expr = el.clone(),
                              name: Expr =  name.clone().into(),
                              value: Expr = Expr::Lit(Lit::Str(Str { span: s.span, value: value.into(), raw: None }))
                          );
                          self.static_stmts.push(RefCell::new(stmt));
                        }
                        Some(JSXAttrValue::JSXExprContainer(JSXExprContainer {
                          expr: JSXExpr::Expr(expr),
                          ..
                        })) => {
                          self.dynamic_parts.push(DynamicPart::Attr(
                            *expr.clone(),
                            self.element_index,
                            attr_name.clone(),
                          ));
                        }
                        Some(JSXAttrValue::JSXExprContainer(JSXExprContainer {
                          expr: JSXExpr::JSXEmptyExpr(_),
                          ..
                        })) => {}
                        Some(JSXAttrValue::JSXElement(_)) => unreachable!("Unexpected JSXElement in JSX attribute value - not supported"),
                        Some(JSXAttrValue::JSXFragment(_)) => unreachable!("Unexpected JSXFragment in JSX attribute value - not supported"),
                        #[cfg(swc_ast_unknown)]
                        _ => panic!("unknown node"),
                      };
                    }
                    AttrName::Event(..) | AttrName::Ref => {
                      self.dynamic_parts.push(DynamicPart::Attr(
                        *jsx_attr_value((*value).clone()),
                        self.element_index,
                        attr_name.clone(),
                      ));
                    }
                    AttrName::TimingFlag => {
                      self.dynamic_parts.push(DynamicPart::Attr(
                        *quote_expr!("{__ltf: $flag}", flag: Expr = *jsx_attr_value((*value).clone())),
                        self.element_index,
                        attr_name.clone(),
                      ));
                    }
                    AttrName::Style => {
                      match value {
                        None => {}
                        Some(JSXAttrValue::Str(s)) => {
                          // <view style="width: 100rpx" />;
                          let value = transform_jsx_attr_str(&s.value);
                          let stmt = quote!(
                              r#"__SetInlineStyles($element, $value)"# as Stmt,
                              element: Expr = el.clone(),
                              value: Expr = Expr::Lit(Lit::Str(Str { span: s.span, value: value.into(), raw: None }))
                          );
                          self.static_stmts.push(RefCell::new(stmt));
                        }
                        Some(JSXAttrValue::JSXExprContainer(JSXExprContainer {
                          expr: JSXExpr::Expr(expr),
                          span,
                          ..
                        })) => {
                          let expr = &**expr;
                          if is_literal(expr) {
                            if let Some(s) = get_string_inline_style_from_literal(expr, span) {
                              // <view style={{backgroundColor: "red"}} />;
                              // <view style={`background-color: red;`} />;
                              let s = Lit::Str(Str {
                                span: *span,
                                value: s.into(),
                                raw: None,
                              });
                              let stmt = quote!(
                                r#"__SetInlineStyles($element, $value)"# as Stmt,
                                element: Expr = el.clone(),
                                value: Expr = Expr::Lit(s)
                              );
                              self.static_stmts.push(RefCell::new(stmt));
                            }
                          } else {
                            self.dynamic_parts.push(DynamicPart::Attr(
                              expr.clone(),
                              self.element_index,
                              attr_name.clone(),
                            ));
                          }
                        }
                        Some(JSXAttrValue::JSXExprContainer(JSXExprContainer {
                          expr: JSXExpr::JSXEmptyExpr(_),
                          ..
                        })) => {}
                        Some(JSXAttrValue::JSXElement(_)) => unreachable!("Unexpected JSXElement in JSX attribute value - not supported"),
                        Some(JSXAttrValue::JSXFragment(_)) => unreachable!("Unexpected JSXFragment in JSX attribute value - not supported"),
                        #[cfg(swc_ast_unknown)]
                        _ => panic!("unknown node"),
                      };
                    }
                    AttrName::Class => {
                      match value {
                        None => {}
                        Some(JSXAttrValue::Str(s)) => {
                          let value = transform_jsx_attr_str(&s.value);
                          let stmt = quote!(
                              r#"__SetClasses($element, $value)"# as Stmt,
                              element: Expr = el.clone(),
                              value: Expr = Expr::Lit(Lit::Str(Str { span: s.span, value: value.into(), raw: None }))
                          );
                          self.static_stmts.push(RefCell::new(stmt));
                        }
                        Some(JSXAttrValue::JSXExprContainer(JSXExprContainer {
                          expr: JSXExpr::Expr(expr),
                          ..
                        })) => match &**expr {
                          Expr::Lit(value) => {
                            let stmt = quote!(
                                r#"__SetClasses($element, $value)"# as Stmt,
                                element: Expr = el.clone(),
                                value: Expr = Expr::Lit(value.clone())
                            );
                            self.static_stmts.push(RefCell::new(stmt));
                          }
                          _ => {
                            self.dynamic_parts.push(DynamicPart::Attr(
                              *expr.clone(),
                              self.element_index,
                              attr_name.clone(),
                            ));
                          }
                        },
                        Some(JSXAttrValue::JSXExprContainer(JSXExprContainer {
                          expr: JSXExpr::JSXEmptyExpr(_),
                          ..
                        })) => {}
                        Some(JSXAttrValue::JSXElement(_)) => unreachable!("Unexpected JSXElement in JSX attribute value - not supported"),
                        Some(JSXAttrValue::JSXFragment(_)) => unreachable!("Unexpected JSXFragment in JSX attribute value - not supported"),
                        #[cfg(swc_ast_unknown)]
                        _ => panic!("unknown node"),
                      };
                    }
                    AttrName::ID => {
                      match value {
                        None => {}
                        Some(JSXAttrValue::Str(s)) => {
                          let value = transform_jsx_attr_str(&s.value);
                          let stmt = quote!(
                              r#"__SetID($element, $value)"# as Stmt,
                              element: Expr = el.clone(),
                              value: Expr = Expr::Lit(Lit::Str(Str { span: s.span, value: value.into(), raw: None }))
                          );
                          self.static_stmts.push(RefCell::new(stmt));
                        }
                        Some(JSXAttrValue::JSXExprContainer(JSXExprContainer {
                          expr: JSXExpr::Expr(expr),
                          ..
                        })) => {
                          self.dynamic_parts.push(DynamicPart::Attr(
                            *expr.clone(),
                            self.element_index,
                            attr_name,
                          ));
                        }
                        Some(JSXAttrValue::JSXExprContainer(JSXExprContainer {
                          expr: JSXExpr::JSXEmptyExpr(_),
                          ..
                        })) => {}
                        Some(JSXAttrValue::JSXElement(_)) => unreachable!("Unexpected JSXElement in JSX attribute value - not supported"),
                        Some(JSXAttrValue::JSXFragment(_)) => unreachable!("Unexpected JSXFragment in JSX attribute value - not supported"),
                        #[cfg(swc_ast_unknown)]
                        _ => panic!("unknown node"),
                      };
                    }
                    AttrName::ListItemPlatformInfo => unreachable!("Unexpected ListItemPlatformInfo attribute in static JSX processing"),
                    AttrName::WorkletEvent(..) | AttrName::WorkletRef(..) => {
                      unreachable!("A worklet event should have an attribute namespace.")
                    }
                    AttrName::Gesture(..) => {
                      unreachable!("A gesture should have an attribute namespace.")
                    }
                  }
                }
                JSXAttrName::JSXNamespacedName(JSXNamespacedName { ns, name, .. }) => {
                  let attr_name: AttrName = AttrName::from_ns(ns.clone().into(), name.clone().into());
                  match attr_name {
                    AttrName::WorkletEvent(..) | AttrName::WorkletRef(..) => {
                      self.dynamic_parts.push(DynamicPart::Attr(
                        *jsx_attr_value((*value).clone()),
                        self.element_index,
                        attr_name.clone(),
                      ));
                    }
                    AttrName::Gesture(..) => {
                      self.dynamic_parts.push(DynamicPart::Attr(
                        *jsx_attr_value((*value).clone()),
                        self.element_index,
                        attr_name.clone(),
                      ));
                    }
                    _ => todo!(),
                  }
                }
                #[cfg(swc_ast_unknown)]
                _ => panic!("unknown node"),
              };
            }
            #[cfg(swc_ast_unknown)]
            _ => panic!("unknown node"),
          });
      }

      if let Some(parent_el) = &self.parent_element {
        self.static_stmts.push(RefCell::new(quote!(
            r#"__AppendElement($parent, $child)"# as Stmt,
            parent: Ident = parent_el.clone(),
            child: Ident = el.clone(),
        )));
      };

      let is_children_full_dynamic = jsx_is_children_full_dynamic(n);

      if !is_children_full_dynamic {
        self.element_index += 1;

        let pre_parent_element = self.parent_element.take();
        self.parent_element = Some(el.clone());
        n.children.visit_mut_with(self);
        self.parent_element = pre_parent_element;
      } else {
        n.children.visit_mut_with(self.dynamic_part_visitor);
        let children_expr = jsx_children_to_expr(n.children.take());
        if jsx_is_list(n) {
          self
            .dynamic_parts
            .push(DynamicPart::ListSlot(children_expr, self.element_index));
        } else {
          self
            .dynamic_parts
            .push(DynamicPart::Slot(children_expr, self.element_index));
        }

        self.element_index += 1;
      }

      if self.parent_element.is_none() {
        let elements = Expr::Array(ArrayLit {
          span: DUMMY_SP,
          elems: (0..self.element_ids.len())
            .step_by(1)
            .map(|e| e as i32)
            .map(|e| {
              Some(ExprOrSpread {
                spread: None,
                expr: Box::new(Expr::Ident(self.element_ids[&e].clone())),
              })
            })
            .collect(),
        });

        self.static_stmts.push(RefCell::new(quote!(
          r#"return $elements;"# as Stmt,
          elements: Expr = elements,
        )));

        self.snapshot_creator = Some(Function {
          ctxt: SyntaxContext::default(),
          params: match Lazy::<Ident>::get(&self.si_id) {
            Some(_) => vec![Param {
              span: DUMMY_SP,
              decorators: vec![],
              pat: Pat::Ident(BindingIdent {
                id: self.si_id.take(),
                type_ann: None,
              }),
            }],
            None => vec![],
          },
          decorators: vec![],
          this_param: None,
          span: DUMMY_SP,
          body: Some(FunctionBody {
            span: DUMMY_SP,
            stmts: self
              .static_stmts
              .take()
              .into_iter()
              .map(|mut stmt| stmt.get_mut().take())
              .collect(),
          }),
          is_generator: false,
          is_async: false,
          type_params: None,
          return_type: None,
        });
      };
    } else {
      n.visit_mut_children_with(self.dynamic_part_visitor);

      if self.parent_element.is_some() {
        self.dynamic_parts.push(DynamicPart::Slot(
          Expr::JSXElement(Box::new(n.take())),
          self.element_index,
        ));

        // self.element_index += 1;
        *n = WRAPPER_NODE.clone();
        n.visit_mut_with(self);
      }
    }
  }

  fn visit_mut_jsx_text(&mut self, n: &mut JSXText) {
    let t = jsx_text_to_str(&n.value);

    if !t.is_empty() {
      let el = private_ident!("el");
      self.element_ids.insert(self.element_index, el.clone());

      self.static_stmts.push(RefCell::new(quote!(
          r#"const $element = __CreateRawText($t)"# as Stmt,
          element = el.clone(),
          t: Expr = t.into(),
      )));

      if let Some(parent_el) = &self.parent_element {
        self.static_stmts.push(RefCell::new(quote!(
            r#"__AppendElement($parent, $child)"# as Stmt,
            parent: Ident = parent_el.clone(),
            child: Ident = el.clone(),
        )));
      };

      self.element_index += 1;
    }
  }
}

/// @internal
#[derive(Deserialize, PartialEq, Clone, Debug)]
#[serde(rename_all = "camelCase")]
pub struct JSXTransformerConfig {
  /// @internal
  pub preserve_jsx: bool,
  /// @internal
  pub runtime_pkg: String,
  /// @internal
  pub jsx_import_source: Option<String>,
  /// @internal
  pub filename: String,
  /// @internal
  pub target: TransformTarget,
  /// @internal
  #[serde(default)]
  pub enable_ui_source_map: bool,
  /// @internal
  pub is_dynamic_component: Option<bool>,
  /// @internal
  #[serde(default)]
  pub is_external_bundle: Option<bool>,
  /// Compile dynamic children with the frozen legacy (pre-SlotV2) codegen in
  /// `legacy_slot.rs` so the output runs on legacy runtimes without `SlotV2`
  /// support (< 0.120.0).
  /// @internal
  #[serde(default)]
  pub legacy_slot: Option<bool>,
}

impl Default for JSXTransformerConfig {
  fn default() -> Self {
    Self {
      preserve_jsx: false,
      runtime_pkg: "@lynx-js/react".into(),
      jsx_import_source: Some("@lynx-js/react".into()),
      filename: Default::default(),
      target: TransformTarget::LEPUS,
      enable_ui_source_map: false,
      is_dynamic_component: Some(false),
      is_external_bundle: Some(false),
      legacy_slot: Some(false),
    }
  }
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn build_snapshot_registration(
  dev_creator_param: bool,
  runtime_id: Expr,
  creator_runtime_expr: Expr,
  creator_runtime_id: Ident,
  snapshot_id: Ident,
  snapshot_creator: Expr,
  snapshot_dynamic_parts_def: Expr,
  slot: Expr,
  css_id: Expr,
  entry_name: Expr,
  snapshot_refs_and_spread_index: Expr,
) -> Expr {
  if dev_creator_param {
    quote!(
        r#"$runtime_id.snapshotCreatorMap[$snapshot_id] = ($snapshot_id, $creator_runtime) => $creator_runtime_ref.createSnapshot(
             $snapshot_id,
             $snapshot_creator,
             $snapshot_dynamic_parts_def,
             $slot,
             $css_id,
             $entry_name,
             $snapshot_refs_and_spread_index,
             true
        )"# as Expr,
        runtime_id: Expr = runtime_id,
        creator_runtime = creator_runtime_id,
        creator_runtime_ref: Expr = creator_runtime_expr,
        snapshot_id = snapshot_id,
        entry_name: Expr = entry_name,
        snapshot_creator: Expr = snapshot_creator,
        snapshot_dynamic_parts_def: Expr = snapshot_dynamic_parts_def,
        slot: Expr = slot,
        css_id: Expr = css_id,
        snapshot_refs_and_spread_index: Expr = snapshot_refs_and_spread_index,
    )
  } else {
    quote!(
        r#"$runtime_id.snapshotCreatorMap[$snapshot_id] = ($snapshot_id) => $runtime_id.createSnapshot(
             $snapshot_id,
             $snapshot_creator,
             $snapshot_dynamic_parts_def,
             $slot,
             $css_id,
             $entry_name,
             $snapshot_refs_and_spread_index,
             true
        )"# as Expr,
        runtime_id: Expr = runtime_id,
        snapshot_id = snapshot_id,
        entry_name: Expr = entry_name,
        snapshot_creator: Expr = snapshot_creator,
        snapshot_dynamic_parts_def: Expr = snapshot_dynamic_parts_def,
        slot: Expr = slot,
        css_id: Expr = css_id,
        snapshot_refs_and_spread_index: Expr = snapshot_refs_and_spread_index,
    )
  }
}

pub struct JSXTransformer<C>
where
  C: Comments + Clone,
{
  // react_transformer: Box<dyn Fold>,
  cfg: JSXTransformerConfig,
  filename_hash: String,
  content_hash: String,
  runtime_id: Lazy<Expr>,
  dev_creator_param: bool,
  runtime_components_ident: Ident,
  runtime_components_module_item: Option<ModuleItem>,
  css_id_value: Option<Expr>,
  snapshot_counter: u32,
  current_snapshot_defs: Vec<ModuleItem>,
  current_snapshot_id: Option<Ident>,
  defines_collector: Option<DefinesCollector>,
  comments: Option<C>,
  pub ui_source_map_records: Rc<RefCell<Vec<UISourceMapRecord>>>,
  pub source_map: Option<Lrc<SourceMap>>,
}

impl<C> JSXTransformer<C>
where
  C: Comments + Clone,
{
  pub fn with_content_hash(mut self, content_hash: String) -> Self {
    self.content_hash = content_hash;
    self
  }

  pub fn with_defines_collector(mut self, collector: DefinesCollector) -> Self {
    self.defines_collector = Some(collector);
    self
  }

  pub fn new(
    cfg: JSXTransformerConfig,
    comments: Option<C>,
    mode: TransformMode,
    source_map: Option<Lrc<SourceMap>>,
  ) -> Self {
    JSXTransformer {
      filename_hash: calc_hash(&cfg.filename.clone()),
      content_hash: "test".into(),
      // Bound via the `import * as ReactLynx from <cfg.runtime_pkg>` prepended
      // in `visit_mut_module` — no dev-only `require()`, so promise (async)
      // externals are awaited through the regular import machinery.
      runtime_id: Lazy::new(|| Expr::Ident(private_ident!("ReactLynx"))),
      // Dev creators are stringified for cross-thread HMR
      // (`DEV_ONLY_AddSnapshot`) and take the runtime as an arrow parameter
      // instead of capturing module bindings. Production creators keep the
      // module-scope reference, which stays statically tree-shakeable.
      dev_creator_param: matches!(mode, TransformMode::Development),
      runtime_components_ident: private_ident!("ReactLynxRuntimeComponents"),
      runtime_components_module_item: None,
      cfg,
      css_id_value: None,
      snapshot_counter: 0,
      current_snapshot_defs: vec![],
      current_snapshot_id: None,
      defines_collector: None,
      comments,
      ui_source_map_records: Rc::new(RefCell::new(vec![])),
      source_map,
    }
  }

  fn parse_directives(&mut self, span: Span) {
    self.comments.with_leading(span.lo, |comments| {
      for cmt in comments {
        if cmt.kind != CommentKind::Block {
          continue;
        }
        for line in cmt.text.lines() {
          let mut line = line.trim();
          if line.starts_with('*') {
            line = line[1..].trim();
          }

          if !line.starts_with("@jsx") {
            continue;
          }

          let mut words = line.split_whitespace();
          loop {
            let pragma = words.next();
            if pragma.is_none() {
              break;
            }
            let val = words.next();
            if let Some("@jsxCSSId") = pragma {
              if let Some(css_id) = val {
                self.css_id_value = Some(Expr::Lit(Lit::Num(
                  css_id
                    .parse::<f64>()
                    .expect("should have numeric cssId")
                    .into(),
                )));
              }
            }
          }
        }
      }
    });
  }
}

impl<C> VisitMut for JSXTransformer<C>
where
  C: Comments + Clone,
{
  fn visit_mut_jsx_element(&mut self, node: &mut JSXElement) {
    match *jsx_name(node.opening.name.clone()) {
      Expr::Lit(lit) => {
        if let Lit::Str(s) = &lit {
          let tag = s.value.to_string_lossy();
          let tag_str = tag.as_ref();
          if tag_str == "wrapper" {
            return node.visit_mut_children_with(self);
          }
          if tag_str == "page" {
            if self.runtime_components_module_item.is_none() {
              self.runtime_components_module_item = Some(quote!(
                r#"import * as $runtime_components_ident from '@lynx-js/react/runtime-components';"#
                  as ModuleItem,
                runtime_components_ident = self.runtime_components_ident.clone(),
              ));
            }

            if let JSXElementName::Ident(_ident) = &mut node.opening.name {
              node.opening.name = JSXElementName::JSXMemberExpr(JSXMemberExpr {
                obj: JSXObject::Ident(self.runtime_components_ident.clone()),
                prop: private_ident!("Page").into(),
                span: node.opening.span,
              });

              if let Some(JSXClosingElement { name, .. }) = &mut node.closing {
                if let JSXElementName::Ident(ident) = name {
                  *name = JSXElementName::JSXMemberExpr(JSXMemberExpr {
                    obj: JSXObject::Ident(self.runtime_components_ident.clone()),
                    prop: private_ident!("Page").into(),
                    span: ident.span(),
                  });
                }
              }
            }
            return node.visit_mut_children_with(self);
          }

          if tag_str == "component" {
            HANDLER.with(|handler| {
              handler
                .struct_span_err(node.opening.name.span(), "<component /> is not supported")
                .emit()
            });
          }
        }
      }
      _ => {
        return node.visit_mut_children_with(self);
      }
    }

    if matches!(self.cfg.legacy_slot, Some(true)) {
      // Frozen pre-SlotV2 codegen lives entirely in legacy_slot.rs; keep the
      // default (SlotV2) pipeline below free of legacy concerns.
      return legacy_slot::transform_jsx_element(self, node);
    }

    self.snapshot_counter += 1;

    let snapshot_uid = format!(
      "__snapshot_{}_{}_{}",
      self.filename_hash, self.content_hash, self.snapshot_counter
    );
    let snapshot_id = Ident::new(
      // format!("__snapshot_{}", snapshot_uid).into(),
      snapshot_uid.clone().into(),
      DUMMY_SP,
      SyntaxContext::default().apply_mark(Mark::fresh(Mark::root())),
    );

    let target = self.cfg.target;
    let collecting = self.defines_collector.is_some();
    let runtime_id = self.runtime_id.clone();
    // In dev the creator arrow is stringified for cross-thread HMR
    // (`DEV_ONLY_AddSnapshot`), so everything inside it references the runtime
    // through the arrow's own parameter; in production it keeps the
    // module-scope import binding (statically tree-shakeable).
    let creator_runtime_id = private_ident!("__runtime__");
    let creator_runtime_expr = if self.dev_creator_param {
      // `__runtime__` is passed by runtimes that pass `SnapshotCreator`'s
      // second argument; the inline `require` keeps the compiled output
      // working on older runtimes that still call creators with a single
      // argument (they load synchronously, so the pending-promise issue the
      // parameter solves cannot occur there).
      // TODO(compat): drop the `require` fallback once runtimes without
      // `snapshotCreatorRuntime` are out of support.
      quote!(
        "($creator_runtime || require($runtime_pkg))" as Expr,
        creator_runtime = creator_runtime_id.clone(),
        runtime_pkg: Expr = Expr::Lit(Lit::Str(self.cfg.runtime_pkg.clone().into())),
      )
    } else {
      self.runtime_id.clone()
    };
    let filename_hash = self.filename_hash.clone();
    let content_hash = self.content_hash.clone();
    let ui_source_map_records = self.ui_source_map_records.clone();
    let snapshot_uid_for_captured = snapshot_uid.clone();
    let source_map = self.source_map.clone();
    let node_index_fn = move |span: Span| {
      let ui_source_map =
        calc_hash_number(&format!("{}:{}:{}", filename_hash, content_hash, span.lo.0));

      // record ui source map entry
      let mut line_number = 0;
      let mut column_number = 0;
      if span.lo.0 > 0 {
        if let Some(cm) = &source_map {
          let loc = cm.lookup_char_pos(span.lo);
          line_number = loc.line as u32;
          column_number = loc.col.0 as u32 + 1;
        }
      }
      ui_source_map_records.borrow_mut().push(UISourceMapRecord {
        ui_source_map,
        line_number,
        column_number,
        snapshot_id: snapshot_uid_for_captured.clone(),
      });

      Expr::Lit(Lit::Num(Number {
        span: DUMMY_SP,
        value: ui_source_map as f64,
        raw: None,
      }))
    };

    let mut dynamic_part_extractor = DynamicPartExtractor::new(
      creator_runtime_expr.clone(),
      self,
      self.cfg.enable_ui_source_map,
      node_index_fn,
    );

    node.visit_mut_with(&mut dynamic_part_extractor);

    let mut snapshot_values: Vec<Option<ExprOrSpread>> = vec![];
    let mut snapshot_values_has_attr = false;
    let mut snapshot_attrs: Vec<JSXAttrOrSpread> = vec![];
    let mut snapshot_children: Vec<Expr> = vec![];
    let mut snapshot_dynamic_part_def: Vec<Option<ExprOrSpread>> = vec![];
    let mut snapshot_dynamic_part_def_mt: Vec<Option<ExprOrSpread>> = vec![];
    let mut snapshot_refs_and_spread_index: Vec<Option<ExprOrSpread>> = vec![];
    let mut snapshot_slot_def: Vec<Option<ExprOrSpread>> = vec![];
    let mut list_item_platform_info_index: Option<i32> = None;

    if let Some(key) = dynamic_part_extractor.key {
      snapshot_attrs.push(JSXAttrOrSpread::JSXAttr(JSXAttr {
        span: DUMMY_SP,
        name: JSXAttrName::Ident(IdentName::new("key".into(), DUMMY_SP)),
        value: Some(key),
      }));
    }

    let (dynamic_part_attr, dynamic_part_children): (Vec<_>, Vec<_>) = dynamic_part_extractor
      .dynamic_parts
      .into_iter()
      .partition(|dynamic_part| match dynamic_part {
        DynamicPart::Attr(_, _, _) | DynamicPart::Spread(_, _, _) => true,
        DynamicPart::Slot(_, _) | DynamicPart::ListSlot(_, _) => false,
      });

    dynamic_part_attr.into_iter().for_each(|dynamic_part| {
      match &dynamic_part {
        DynamicPart::Attr(_, _, _) | DynamicPart::Spread(_, _, _) => {
          if let DynamicPart::Attr(_, _, AttrName::Ref) | DynamicPart::Spread(_, _, _) =
            dynamic_part
          {
            snapshot_refs_and_spread_index.push(Some(
              Expr::Lit(Lit::Num(snapshot_dynamic_part_def.len().into())).into(),
            ));
          }
          let updater_index = snapshot_dynamic_part_def.len() as i32;
          let updater = |target: TransformTarget| ExprOrSpread {
            spread: None,
            expr: Box::new(dynamic_part.to_updater(
              creator_runtime_expr.clone(),
              target,
              updater_index,
            )),
          };
          if collecting {
            snapshot_dynamic_part_def_mt.push(Some(updater(TransformTarget::LEPUS)));
          }
          snapshot_dynamic_part_def.push(Some(updater(target)));
        }
        DynamicPart::Slot(_, _) => {}
        DynamicPart::ListSlot(_, _) => {}
      }

      match dynamic_part {
        DynamicPart::Attr(value, _, attr_name) => {
          if matches!(attr_name, AttrName::ListItemPlatformInfo) {
            list_item_platform_info_index = Some(snapshot_values.len() as i32);
          }
          snapshot_values.push(Some(ExprOrSpread {
            spread: None,
            expr: Box::new(if let AttrName::Event(_, _) = attr_name {
              if target == TransformTarget::LEPUS {
                quote!("1" as Expr)
              } else {
                value
              }
            } else if let AttrName::Ref = attr_name {
              if target == TransformTarget::LEPUS {
                quote!("1" as Expr)
              } else {
                quote!(
                  "$runtime_id.transformRef($value)" as Expr,
                  runtime_id: Expr = runtime_id.clone(),
                  value: Expr = value,
                )
              }
            } else {
              value
            }),
          }));
          snapshot_values_has_attr = true;
        }
        DynamicPart::Spread(value, _, is_list_item) => {
          if is_list_item {
            list_item_platform_info_index = Some(snapshot_values.len() as i32);
          }
          snapshot_values.push(Some(ExprOrSpread {
            spread: None,
            expr: Box::new(value),
          }));
          snapshot_values_has_attr = true;
        }
        DynamicPart::ListSlot(_, _) => {}
        DynamicPart::Slot(_, _) => {}
      }
    });

    let slot_expr = match (dynamic_part_children.len(), dynamic_part_children.first()) {
      (0, _) => Expr::Lit(Lit::Null(Null { span: DUMMY_SP })),
      (1, Some(DynamicPart::Slot(expr, 0))) => {
        snapshot_children.push(expr.clone());
        quote!(
          "$runtime_id.__DynamicPartSlotV2_0" as Expr,
          runtime_id: Expr = creator_runtime_expr.clone(),
        )
      }
      _ => {
        dynamic_part_children
          .into_iter()
          .for_each(|dynamic_part| match dynamic_part {
            DynamicPart::Attr(_, _, _) => {}
            DynamicPart::Spread(_, _, _) => {}
            DynamicPart::ListSlot(expr, element_index) => {
              snapshot_children.push(expr);
              snapshot_slot_def.push(Some(ExprOrSpread {
                spread: None,
                expr: Box::new(quote!(
                  "[$runtime_id.__DynamicPartListSlotV2, $element_index]" as Expr,
                  runtime_id: Expr = creator_runtime_expr.clone(),
                  element_index: Expr = i32_to_expr(&element_index),
                )),
              }));
            }
            DynamicPart::Slot(expr, element_index) => {
              snapshot_children.push(expr);
              snapshot_slot_def.push(Some(ExprOrSpread {
                spread: None,
                expr: Box::new(quote!(
                  "[$runtime_id.__DynamicPartSlotV2, $element_index]" as Expr,
                  runtime_id: Expr = creator_runtime_expr.clone(),
                  element_index: Expr = i32_to_expr(&element_index),
                )),
              }));
            }
          });

        Expr::Array(ArrayLit {
          span: DUMMY_SP,
          elems: snapshot_slot_def,
        })
      }
    };

    let snapshot_creator_fn = dynamic_part_extractor.snapshot_creator.unwrap();
    let snapshot_creator_mt = collecting.then(|| {
      Expr::Fn(FnExpr {
        ident: None,
        function: Box::new(snapshot_creator_fn.clone()),
      })
    });
    let snapshot_creator = if target == TransformTarget::JS {
      Expr::Lit(Lit::Null(Null { span: DUMMY_SP }))
    } else {
      Expr::Fn(FnExpr {
        ident: None,
        function: Box::new(snapshot_creator_fn),
      })
    };

    // External bundles have no `globDynamicComponentEntry` in scope; use the
    // `__Card__` entry-name literal.
    let entry_name: Expr = if matches!(self.cfg.is_external_bundle, Some(true))
      && !matches!(self.cfg.is_dynamic_component, Some(true))
    {
      Expr::Lit(Lit::Str("__Card__".into()))
    } else {
      Expr::Ident("globDynamicComponentEntry".into())
    };

    let snapshot_dynamic_parts_def: Expr = match (target, snapshot_dynamic_part_def.len()) {
      (TransformTarget::JS, _) | (_, 0) => Expr::Lit(Lit::Null(Null { span: DUMMY_SP })),
      _ => Expr::Array(ArrayLit {
        span: DUMMY_SP,
        elems: snapshot_dynamic_part_def,
      }),
    };
    let snapshot_dynamic_parts_def_mt: Expr = match snapshot_dynamic_part_def_mt.len() {
      0 => Expr::Lit(Lit::Null(Null { span: DUMMY_SP })),
      _ => Expr::Array(ArrayLit {
        span: DUMMY_SP,
        elems: snapshot_dynamic_part_def_mt,
      }),
    };
    let css_id: Expr = match &self.css_id_value {
      Some(css_id_expr) => css_id_expr.clone(),
      // We use `undefined` here since runtime will skip `__SetCSSId` when `cssId === undefined && entryName === undefined`
      None => Expr::Ident("undefined".into()),
    };
    let snapshot_refs_and_spread_index: Expr = match snapshot_refs_and_spread_index.len() {
      0 => Expr::Lit(Lit::Null(Null { span: DUMMY_SP })),
      _ => Expr::Array(ArrayLit {
        span: DUMMY_SP,
        elems: snapshot_refs_and_spread_index,
      }),
    };

    let snapshot_create_call_mt = snapshot_creator_mt.map(|snapshot_creator_mt| {
      build_snapshot_registration(
        self.dev_creator_param,
        self.runtime_id.clone(),
        creator_runtime_expr.clone(),
        creator_runtime_id.clone(),
        snapshot_id.clone(),
        snapshot_creator_mt,
        snapshot_dynamic_parts_def_mt,
        slot_expr.clone(),
        css_id.clone(),
        entry_name.clone(),
        snapshot_refs_and_spread_index.clone(),
      )
    });
    let snapshot_create_call = build_snapshot_registration(
      self.dev_creator_param,
      self.runtime_id.clone(),
      creator_runtime_expr,
      creator_runtime_id,
      snapshot_id.clone(),
      snapshot_creator,
      snapshot_dynamic_parts_def,
      slot_expr,
      css_id,
      entry_name,
      snapshot_refs_and_spread_index,
    );

    let mut entry_snapshot_uid = quote!("$snapshot_uid" as Expr, snapshot_uid: Expr = Expr::Lit(Lit::Str(snapshot_uid.clone().into())));
    if matches!(self.cfg.is_dynamic_component, Some(true)) {
      entry_snapshot_uid = quote!("`${globDynamicComponentEntry}:${$snapshot_uid}`" as Expr, snapshot_uid: Expr = Expr::Lit(Lit::Str(snapshot_uid.clone().into())));
    }

    let entry_snapshot_uid_def = ModuleItem::Stmt(quote!(
        r#"const $snapshot_id = $entry_snapshot_uid"#
            as Stmt,
        snapshot_id = snapshot_id.clone(),
        entry_snapshot_uid: Expr = entry_snapshot_uid.clone(),
    ));
    let snapshot_def = ModuleItem::Stmt(quote!(
        r#"$snapshot_create_call"#
            as Stmt,
        snapshot_create_call: Expr = snapshot_create_call,
    ));

    if let Some(snapshot_create_call_mt) = snapshot_create_call_mt {
      collect_define(
        &self.defines_collector,
        DefineKind::Snapshot,
        snapshot_uid,
        vec![
          entry_snapshot_uid_def.clone(),
          ModuleItem::Stmt(quote!(
            r#"$snapshot_create_call"# as Stmt,
            snapshot_create_call: Expr = snapshot_create_call_mt,
          )),
        ],
      );
    }

    self.current_snapshot_id = Some(snapshot_id.clone());
    self.current_snapshot_defs.push(entry_snapshot_uid_def);
    self.current_snapshot_defs.push(snapshot_def);

    *node =
      JSXElement {
        span: node.span(),
        opening: JSXOpeningElement {
          name: JSXElementName::Ident(snapshot_id.clone()),
          span: node.span,
          attrs: {
            if snapshot_values_has_attr {
              snapshot_attrs.push(JSXAttrOrSpread::JSXAttr(JSXAttr {
                span: DUMMY_SP,
                name: JSXAttrName::Ident(IdentName::new("values".into(), DUMMY_SP)),
                value: Some(JSXAttrValue::JSXExprContainer(JSXExprContainer {
                  span: DUMMY_SP,
                  expr: JSXExpr::Expr(Box::new(Expr::Array(ArrayLit {
                    span: DUMMY_SP,
                    elems: snapshot_values,
                  }))),
                })),
              }))
            };
            if let Some(index) = list_item_platform_info_index {
              snapshot_attrs.push(JSXAttrOrSpread::JSXAttr(JSXAttr {
                span: DUMMY_SP,
                name: JSXAttrName::Ident(IdentName::new(
                  "__listItemPlatformInfoIndex".into(),
                  DUMMY_SP,
                )),
                value: Some(JSXAttrValue::JSXExprContainer(JSXExprContainer {
                  span: DUMMY_SP,
                  expr: JSXExpr::Expr(Box::new(i32_to_expr(&index))),
                })),
              }))
            }
            snapshot_attrs.extend(snapshot_children.iter_mut().enumerate().map(
              |(index, child)| {
                JSXAttrOrSpread::JSXAttr(JSXAttr {
                  span: DUMMY_SP,
                  name: JSXAttrName::Ident(IdentName::new(format!("${index}").into(), DUMMY_SP)),
                  value: Some(JSXAttrValue::JSXExprContainer(JSXExprContainer {
                    span: DUMMY_SP,
                    expr: JSXExpr::Expr(Box::new(child.take())),
                  })),
                })
              },
            ));
            snapshot_attrs
          },
          self_closing: true,
          type_args: None,
        },
        children: vec![],
        closing: None,
      };
  }

  fn visit_mut_module_items(&mut self, n: &mut Vec<ModuleItem>) {
    let mut new_items: Vec<ModuleItem> = Vec::with_capacity(n.len());
    for mut item in n.take() {
      item.visit_mut_with(self);
      new_items.extend(self.current_snapshot_defs.take());
      new_items.push(item);
    }

    if let Some(module_item) = &self.runtime_components_module_item {
      new_items.insert(0, module_item.clone());
    }

    *n = new_items;
  }

  fn visit_mut_module(&mut self, n: &mut Module) {
    self.parse_directives(n.span);
    for item in &n.body {
      let span = item.span();
      self.parse_directives(span);
    }

    if self.css_id_value.is_none() && matches!(self.cfg.is_dynamic_component, Some(true)) {
      self.css_id_value = Some(Expr::Lit(Lit::Num(0.into())));
    }

    n.visit_mut_children_with(self);

    if let Expr::Ident(runtime_id) = &*self.runtime_id {
      if self.snapshot_counter > 0 {
        prepend_stmt(
          &mut n.body,
          ModuleItem::ModuleDecl(ModuleDecl::Import(ImportDecl {
            span: DUMMY_SP,
            specifiers: vec![ImportSpecifier::Namespace(ImportStarAsSpecifier {
              span: DUMMY_SP,
              local: runtime_id.clone(),
            })],
            src: Box::new(Str {
              span: DUMMY_SP,
              raw: None,
              value: self.cfg.runtime_pkg.clone().into(),
            }),
            type_only: Default::default(),
            // asserts: Default::default(),
            with: Default::default(),
            phase: ImportPhase::Evaluation,
          })),
        );
      }
    }
  }
}

// #[plugin_transform]
// pub fn process_transform(program: Program, metadata: TransformPluginProgramMetadata) -> Program {
//     let filename = metadata
//         .get_context(&TransformPluginMetadataContextKind::Filename)
//         .unwrap();

//     program.fold_with(&mut JSXTransformer {
//         // filename: "index.js".into(),
//         filename,
//         snapshot_counter: 0,
//         current_snapshot_defs: vec![],
//     })
// }

#[cfg(test)]
mod tests {
  use swc_core::{
    common::{comments::SingleThreadedComments, Mark},
    ecma::{
      parser::{EsSyntax, Syntax},
      transforms::{
        base::resolver,
        react,
        testing::{test, Tester},
      },
      visit::visit_mut_pass,
    },
  };

  use std::{cell::RefCell, rc::Rc};

  use crate::JSXTransformer;
  use swc_plugins_shared::{
    defines::{DefineKind, DefinesCollector},
    target::TransformTarget,
    transform_mode::TransformMode,
  };

  #[test]
  fn should_collect_main_thread_defines_while_targeting_js() {
    Tester::run(|tester| {
      let top_level_mark = Mark::new();
      let unresolved_mark = Mark::new();
      let collector: DefinesCollector = Rc::new(RefCell::new(vec![]));

      tester.apply_transform(
        (
          resolver(unresolved_mark, top_level_mark, true),
          visit_mut_pass(
            JSXTransformer::<&SingleThreadedComments>::new(
              super::JSXTransformerConfig {
                preserve_jsx: false,
                target: TransformTarget::JS,
                ..Default::default()
              },
              None,
              TransformMode::Test,
              Some(tester.cm.clone()),
            )
            .with_defines_collector(collector.clone()),
          ),
        ),
        "input.js",
        Syntax::Es(EsSyntax {
          jsx: true,
          ..Default::default()
        }),
        Some(true),
        r#"function App() { return <view><text>hi</text></view>; }"#,
      )?;

      let defines = collector.borrow();
      assert_eq!(defines.len(), 1);
      assert_eq!(defines[0].kind, DefineKind::Snapshot);
      assert!(defines[0].id.starts_with("__snapshot_"));
      let collected = format!("{:?}", defines[0].items);
      assert!(collected.contains("__CreateView"));
      assert!(collected.contains("__CreateText"));

      Ok(())
    });
  }

  #[test]
  fn should_leave_the_emitted_code_unchanged_while_collecting() {
    Tester::run(|tester| {
      let comments = Rc::new(SingleThreadedComments::default());
      let source = r#"function App() { return <view><text>hi</text></view>; }"#;

      let mut transform = |collector: Option<DefinesCollector>| {
        let top_level_mark = Mark::new();
        let unresolved_mark = Mark::new();
        let transformer = JSXTransformer::<&SingleThreadedComments>::new(
          super::JSXTransformerConfig {
            preserve_jsx: false,
            target: TransformTarget::JS,
            ..Default::default()
          },
          None,
          TransformMode::Test,
          Some(tester.cm.clone()),
        );
        let transformer = match collector {
          Some(collector) => transformer.with_defines_collector(collector),
          None => transformer,
        };

        tester
          .apply_transform(
            (
              resolver(unresolved_mark, top_level_mark, true),
              visit_mut_pass(transformer),
            ),
            "input.js",
            Syntax::Es(EsSyntax {
              jsx: true,
              ..Default::default()
            }),
            Some(true),
            source,
          )
          .map(|program| tester.print(&program, &comments))
      };

      let emitted = transform(None)?;
      let emitted_while_collecting = transform(Some(Rc::new(RefCell::new(vec![]))))?;

      assert_eq!(emitted, emitted_while_collecting);

      Ok(())
    });
  }

  #[test]
  fn should_keep_jsx_in_children_prop_map_callback_scope() {
    Tester::run(|tester| {
      let top_level_mark = Mark::new();
      let unresolved_mark = Mark::new();

      let program = tester.apply_transform(
        (
          resolver(unresolved_mark, top_level_mark, true),
          visit_mut_pass(JSXTransformer::<&SingleThreadedComments>::new(
            super::JSXTransformerConfig {
              preserve_jsx: false,
              target: TransformTarget::MIXED,
              ..Default::default()
            },
            None,
            TransformMode::Test,
            Some(tester.cm.clone()),
          )),
          react::react::<&SingleThreadedComments>(
            tester.cm.clone(),
            None,
            react::Options {
              next: Some(false),
              runtime: Some(react::Runtime::Automatic),
              import_source: Some("@lynx-js/react".into()),
              pragma: None,
              pragma_frag: None,
              throw_if_namespace: None,
              development: Some(false),
              refresh: None,
              ..Default::default()
            },
            top_level_mark,
            unresolved_mark,
          ),
        ),
        "input.js",
        Syntax::Es(EsSyntax {
          jsx: true,
          ..Default::default()
        }),
        Some(true),
        r#"
        const render_data_array = ['1', '2', '3'];

        export function App() {
          return (
            <view
              children={render_data_array.map((item, index123, array123) => (
                <text key={item}>{array123[index123]}</text>
              ))}
            />
          );
        }
        "#,
      )?;

      let comments = tester.comments.clone();
      let output = tester.print(&program, &comments);
      assert!(
        output.contains("render_data_array.map((item, index123, array123)=>")
          && output.contains("_jsx(\"text\""),
        "the JSX in children={{...}} should stay inside the map callback; output:\n{output}",
      );
      assert!(
        !output.contains("$0: array123[index123]"),
        "snapshot child slots must not capture map callback locals outside their scope; output:\n{output}",
      );

      Ok(())
    });
  }

  #[test]
  fn should_emit_list_item_platform_info_marker_without_repeating_values() {
    Tester::run(|tester| {
      let top_level_mark = Mark::new();
      let unresolved_mark = Mark::new();

      let program = tester.apply_transform(
        (
          resolver(unresolved_mark, top_level_mark, true),
          visit_mut_pass(JSXTransformer::<&SingleThreadedComments>::new(
            super::JSXTransformerConfig {
              preserve_jsx: true,
              target: TransformTarget::MIXED,
              ..Default::default()
            },
            None,
            TransformMode::Test,
            Some(tester.cm.clone()),
          )),
        ),
        "input.js",
        Syntax::Es(EsSyntax {
          jsx: true,
          ..Default::default()
        }),
        Some(true),
        r#"
        const node = (
          <list>
            <list-item item-key={getItemKey()} full-span />
          </list>
        );
        "#,
      )?;

      let comments = tester.comments.clone();
      let output = tester.print(&program, &comments);
      assert!(
        output.contains("__listItemPlatformInfoIndex={0}"),
        "list-item snapshot JSX should carry the platform-info value index; output:\n{output}",
      );
      assert_eq!(
        output.matches("getItemKey").count(),
        1,
        "platform info marker must not duplicate dynamic expression evaluation; output:\n{output}",
      );

      Ok(())
    });
  }

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| {
      let unresolved_mark = Mark::new();
      let top_level_mark = Mark::new();

      (
        resolver(unresolved_mark, top_level_mark, true),
        visit_mut_pass(JSXTransformer::new(
          super::JSXTransformerConfig {
            preserve_jsx: true,
            enable_ui_source_map: true,
            ..Default::default()
          },
          Some(t.comments.clone()),
          TransformMode::Test,
          Some(t.cm.clone()),
        )),
      )
    },
    basic_full_static,
    // Input codes
    r#"
    <view>
      <text>!!!</text>
      <frame/>
    </view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        target: TransformTarget::MIXED,
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    should_emit_list_item_platform_info_marker_for_non_zero_value_index,
    // Input codes
    r#"
    const node = (
      <view id={getViewId()}>
        <list-item item-key={getItemKey()} />
      </view>
    );
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| {
      let unresolved_mark = Mark::new();
      let top_level_mark = Mark::new();

      (
        resolver(unresolved_mark, top_level_mark, true),
        visit_mut_pass(JSXTransformer::new(
          super::JSXTransformerConfig {
            preserve_jsx: true,
            target: TransformTarget::MIXED,
            ..Default::default()
          },
          Some(t.comments.clone()),
          TransformMode::Test,
          Some(t.cm.clone()),
        )),
      )
    },
    should_emit_list_item_platform_info_marker_for_spread_props,
    // Input codes
    r#"
    const node = (
      <list>
        <list-item {...getProps()} />
      </list>
    );
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| {
      let unresolved_mark = Mark::new();
      let top_level_mark = Mark::new();

      (
        resolver(unresolved_mark, top_level_mark, true),
        visit_mut_pass(JSXTransformer::new(
          super::JSXTransformerConfig {
            preserve_jsx: true,
            enable_ui_source_map: true,
            ..Default::default()
          },
          Some(t.comments.clone()),
          TransformMode::Test,
          Some(t.cm.clone()),
        )),
      )
    },
    full_static_children_self_close,
    // Input codes
    r#"
    <view className="parent">
			<view className="child"/>
			<view className="child"/>
		</view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| {
      let unresolved_mark = Mark::new();
      let top_level_mark = Mark::new();

      (
        resolver(unresolved_mark, top_level_mark, true),
        visit_mut_pass(JSXTransformer::new(
          super::JSXTransformerConfig {
            preserve_jsx: true,
            enable_ui_source_map: true,
            ..Default::default()
          },
          Some(t.comments.clone()),
          TransformMode::Test,
          Some(t.cm.clone()),
        )),
      )
    },
    full_static_children_new_line,
    // Input codes
    r#"
    <view className="parent">
			<view className="child">
      </view>
			<view className="child">
      </view>
		</view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| {
      let unresolved_mark = Mark::new();
      let top_level_mark = Mark::new();

      (
        resolver(unresolved_mark, top_level_mark, true),
        visit_mut_pass(JSXTransformer::new(
          super::JSXTransformerConfig {
            preserve_jsx: true,
            ..Default::default()
          },
          Some(t.comments.clone()),
          TransformMode::Test,
          Some(t.cm.clone()),
        )),
      )
    },
    full_static_children_comments,
    // Input codes
    r#"
    <view className="parent">
			<view className="child">
        {/** foo */}
      </view>
			<view className="child">
        {/** bar */}
      </view>
		</view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| {
      let unresolved_mark = Mark::new();
      let top_level_mark = Mark::new();

      (
        resolver(unresolved_mark, top_level_mark, true),
        visit_mut_pass(JSXTransformer::new(
          super::JSXTransformerConfig {
            preserve_jsx: true,
            ..Default::default()
          },
          Some(t.comments.clone()),
          TransformMode::Test,
          Some(t.cm.clone()),
        )),
      )
    },
    full_static_children_map_jsx,
    // Input codes
    r#"
    <view className="parent">
			<view className="child">{[].map(() => null)}</view>
			<view className="child">{[].map(() => null)}</view>
		</view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| {
      let unresolved_mark = Mark::new();
      let top_level_mark = Mark::new();

      (
        resolver(unresolved_mark, top_level_mark, true),
        visit_mut_pass(JSXTransformer::new(
          super::JSXTransformerConfig {
            preserve_jsx: true,
            ..Default::default()
          },
          Some(t.comments.clone()),
          TransformMode::Test,
          Some(t.cm.clone()),
        )),
      )
    },
    basic_full_static_snapshot_extract,
    // Input codes
    r#"let s = __SNAPSHOT__(<view><text>!!!</text></view>);"#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| {
      let unresolved_mark = Mark::new();
      let top_level_mark = Mark::new();

      (
        resolver(unresolved_mark, top_level_mark, true),
        visit_mut_pass(JSXTransformer::new(
          super::JSXTransformerConfig {
            preserve_jsx: true,
            ..Default::default()
          },
          Some(t.comments.clone()),
          TransformMode::Test,
          Some(t.cm.clone()),
        )),
      )
    },
    basic_full_static_snapshot_extract_it,
    // Input codes
    r#"
    it('basic', async function() {
      const run = withEnv(function() {
        let s = __SNAPSHOT__(<view><text>!!!</text></view>);
      });
      await run();
    });
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    basic_component,
    // Input codes
    r#"
    <view>
      <A/>
    </view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    page_component,
    // Input codes
    r#"
    <Page custom-key-str="custom-value" custom-key-var={customVariable} class="classValue" data-attr={dataAttr}>
      <view>
        <Page/>
        <A/>
      </view>
    </Page>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Development,
      Some(t.cm.clone()),
    )),
    page_element_dev,
    // Input codes
    r#"
    <page custom-key-str="custom-value" custom-key-var={customVariable} class="classValue" data-attr={dataAttr}>
      <view>
        <page />
        <A/>
      </view>
    </page>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    page_element,
    // Input codes
    r#"
    <page custom-key-str="custom-value" custom-key-var={customVariable} class="classValue" data-attr={dataAttr}>
      <view>
        <page />
        <A/>
      </view>
    </page>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    basic_component_with_static_sibling,
    // Input codes
    r#"
    <view>
      <text>!!!</text>
      <A/>
    </view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| {
      let top_level_mark = Mark::new();
      let unresolved_mark = Mark::new();
      (
        visit_mut_pass(JSXTransformer::<&SingleThreadedComments>::new(
          super::JSXTransformerConfig {
            preserve_jsx: false,
            ..Default::default()
          },
          None,
          TransformMode::Test,
          Some(t.cm.clone()),
        )),
        react::react::<&SingleThreadedComments>(
          t.cm.clone(),
          None,
          react::Options {
            next: Some(false),
            runtime: Some(react::Runtime::Automatic),
            import_source: Some("@lynx-js/react".into()),
            pragma: None,
            pragma_frag: None,
            throw_if_namespace: None,
            development: Some(false),
            refresh: None,
            ..Default::default()
          },
          top_level_mark,
          unresolved_mark,
        ),
      )
    },
    basic_component_with_static_sibling_jsx,
    // Input codes
    r#"
    <view>
      <text>!!!</text>
      <A/>
    </view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| {
      let top_level_mark = Mark::new();
      let unresolved_mark = Mark::new();
      (
        visit_mut_pass(JSXTransformer::<&SingleThreadedComments>::new(
          super::JSXTransformerConfig {
            preserve_jsx: false,
            ..Default::default()
          },
          None,
          TransformMode::Test,
          Some(t.cm.clone()),
        )),
        react::react::<&SingleThreadedComments>(
          t.cm.clone(),
          None,
          react::Options {
            next: Some(false),
            runtime: Some(react::Runtime::Automatic),
            import_source: Some("@lynx-js/react".into()),
            pragma: None,
            pragma_frag: None,
            throw_if_namespace: None,
            development: Some(true),
            refresh: None,
            ..Default::default()
          },
          top_level_mark,
          unresolved_mark,
        ),
      )
    },
    basic_component_with_static_sibling_jsx_dev,
    // Input codes
    r#"
    <view>
      <text>!!!</text>
      <A/>
    </view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    basic_expr_container,
    // Input codes
    r#"
    <view>
      {a}
    </view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    basic_expr_container_with_static_sibling,
    // Input codes
    r#"
    <view>
      <text>!!!</text>
      {a}
    </view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    should_inject_implicit_flatten,
    // Input codes
    r#"
    <view>
      <view className={'commdityV1Wrapper'}>
        <view id={id} className={'dotComm'} />
        <view className={'commdityV1TextWrapper'}>
          <view className={'commdityV1TextVerticalWrapper'}>
            <ItemTextWithTag/>
            {desc}
          </view>
          {unit}
        </view>
        {unit}
        {unit}
      </view>
    </view>;
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    should_static_extract_inline_style,
    // Input codes
    r#"
    <view style={{
      backgroundColor: 'red',
      width: '100%',
      height: '100%',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      borderRadius: '50%',
      opacity: 0.5,
    }} />;
    <view style="background-color: red;" />;
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    should_static_extract_dynamic_inline_style,
    // Input codes
    r#"
    <view style={`background-color: red;`} />;
    <view style={`background-color: red; width: ${w};`} />;
    <view style={{backgroundColor: "red", width: w, height: "100rpx"}} />;
    <view style={{backgroundColor: "red", ...style}} />;
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    should_extract_css_id_without_css_id,
    // Input codes
    r#"
    <view style={`background-color: red;`} />;
    <view style={`background-color: red; width: ${w};`} />;
    <view style={{backgroundColor: "red", width: w, height: "100rpx"}} />;
    <view style={{backgroundColor: "red", ...style}} />;
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    should_extract_css_id,
    // Input codes
    r#"
/**
 * @jsxCSSId 100
 */
    <view style={`background-color: red;`} />;
    <view style={`background-color: red; width: ${w};`} />;
    <view style={{backgroundColor: "red", width: w, height: "100rpx"}} />;
    <view style={{backgroundColor: "red", ...style}} />;
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        is_dynamic_component: Some(true),
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    should_extract_css_id_dynamic_component,
    // Input codes
    r#"
/**
 * @jsxCSSId 100
 */
    <view style={`background-color: red;`} />;
    <view style={`background-color: red; width: ${w};`} />;
    <view style={{backgroundColor: "red", width: w, height: "100rpx"}} />;
    <view style={{backgroundColor: "red", ...style}} />;
    "#
  );

  // External bundles use the `"__Card__"` entry-name literal in `createSnapshot`.
  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        is_external_bundle: Some(true),
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    external_bundle_uses_card_entry_name,
    // Input codes
    r#"
    <view><text>hello</text></view>;
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        is_dynamic_component: Some(true),
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    should_extract_css_id_dynamic_component_without_css_id,
    // Input codes
    r#"
    <view style={`background-color: red;`} />;
    <view style={`background-color: red; width: ${w};`} />;
    <view style={{backgroundColor: "red", width: w, height: "100rpx"}} />;
    <view style={{backgroundColor: "red", ...style}} />;
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| {
      let top_level_mark = Mark::new();
      let unresolved_mark = Mark::new();
      (
        visit_mut_pass(JSXTransformer::<&SingleThreadedComments>::new(
          super::JSXTransformerConfig {
            preserve_jsx: false,
            ..Default::default()
          },
          None,
          TransformMode::Test,
          Some(t.cm.clone()),
        )),
        react::react::<&SingleThreadedComments>(
          t.cm.clone(),
          None,
          react::Options {
            next: Some(false),
            runtime: Some(react::Runtime::Automatic),
            import_source: Some("@lynx-js/react".into()),
            pragma: None,
            pragma_frag: None,
            throw_if_namespace: None,
            development: Some(false),
            refresh: None,
            ..Default::default()
          },
          top_level_mark,
          unresolved_mark,
        ),
      )
    },
    basic_spread,
    // Input codes
    r#"
    <view>
      <text before={"bbb"} {...obj} after={"aaa"}>!!!</text>
    </view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| {
      let top_level_mark = Mark::new();
      let unresolved_mark = Mark::new();
      (
        visit_mut_pass(JSXTransformer::<&SingleThreadedComments>::new(
          super::JSXTransformerConfig {
            preserve_jsx: false,
            ..Default::default()
          },
          None,
          TransformMode::Test,
          Some(t.cm.clone()),
        )),
        react::react::<&SingleThreadedComments>(
          t.cm.clone(),
          None,
          react::Options {
            next: Some(false),
            runtime: Some(react::Runtime::Automatic),
            import_source: Some("@lynx-js/react".into()),
            pragma: None,
            pragma_frag: None,
            throw_if_namespace: None,
            development: Some(false),
            refresh: None,
            ..Default::default()
          },
          top_level_mark,
          unresolved_mark,
        ),
      )
    },
    basic_spread_list_item,
    // Input codes
    r#"
    <list>
      <list-item key="hello" item-key="world" {...obj}>!!!</list-item>
    </list>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |_| {
      visit_mut_pass(JSXTransformer::<&SingleThreadedComments>::new(
        super::JSXTransformerConfig {
          preserve_jsx: false,
          ..Default::default()
        },
        None,
        TransformMode::Test,
        None,
      ))
    },
    inline_style_literal,
    // Input codes
    r#"
    <view style={{ color: "red", 'height': "100px", flexShrink: 1 }}>
    </view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |_| {
      visit_mut_pass(JSXTransformer::<&SingleThreadedComments>::new(
        super::JSXTransformerConfig {
          preserve_jsx: false,
          ..Default::default()
        },
        None,
        TransformMode::Test,
        None,
      ))
    },
    inline_style_literal_unknown_property,
    // Input codes
    r#"
    <view style={{ unknown: "red", height: "100px", display: 'linear', 'unknown-foo': 'bar' }}>
    </view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |_| {
      visit_mut_pass(JSXTransformer::<&SingleThreadedComments>::new(
        super::JSXTransformerConfig {
          preserve_jsx: false,
          ..Default::default()
        },
        None,
        TransformMode::Test,
        None,
      ))
    },
    empty_module,
    // Input codes
    r#"
    console.log('hello, world')
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |_| {
      visit_mut_pass(JSXTransformer::<&SingleThreadedComments>::new(
        super::JSXTransformerConfig {
          preserve_jsx: false,
          runtime_pkg: "@lynx-js/react/internal".into(),
          ..Default::default()
        },
        None,
        TransformMode::Development,
        None,
      ))
    },
    mode_development_spread,
    // Input codes
    r#"
    <view {...{ style: { height: "100px" }}} main-thread:bindtap={xxx}>
    </view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| {
      let top_level_mark = Mark::new();
      let unresolved_mark = Mark::new();
      (
        visit_mut_pass(JSXTransformer::<&SingleThreadedComments>::new(
          super::JSXTransformerConfig {
            preserve_jsx: false,
            target: TransformTarget::MIXED,
            ..Default::default()
          },
          None,
          TransformMode::Development,
          Some(t.cm.clone()),
        )),
        react::react::<&SingleThreadedComments>(
          t.cm.clone(),
          None,
          react::Options {
            next: Some(false),
            runtime: Some(react::Runtime::Automatic),
            import_source: Some("@lynx-js/react".into()),
            pragma: None,
            pragma_frag: None,
            throw_if_namespace: None,
            development: Some(false),
            refresh: None,
            ..Default::default()
          },
          top_level_mark,
          unresolved_mark,
        ),
      )
    },
    basic_event,
    // Input codes
    r#"
    function Comp() {
      const handleTap = () => {}
      return (
        <view>
          <text bindtap={handleTap}>1</text>
        </view>
      )
    }
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| {
      let top_level_mark = Mark::new();
      let unresolved_mark = Mark::new();
      (
        visit_mut_pass(JSXTransformer::<&SingleThreadedComments>::new(
          super::JSXTransformerConfig {
            preserve_jsx: false,
            target: TransformTarget::MIXED,
            ..Default::default()
          },
          None,
          TransformMode::Development,
          Some(t.cm.clone()),
        )),
        react::react::<&SingleThreadedComments>(
          t.cm.clone(),
          None,
          react::Options {
            next: Some(false),
            runtime: Some(react::Runtime::Automatic),
            import_source: Some("@lynx-js/react".into()),
            pragma: None,
            pragma_frag: None,
            throw_if_namespace: None,
            development: Some(false),
            refresh: None,
            ..Default::default()
          },
          top_level_mark,
          unresolved_mark,
        ),
      )
    },
    basic_ref,
    // Input codes
    r#"
    function Comp() {
      const handleRef = () => {}
      return (
        <view>
          <text ref={handleRef}>1</text>
          <text bindtap={handleRef}>2</text>
          <text ref={handleRef}>3</text>
        </view>
      )
    }
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| {
      let top_level_mark = Mark::new();
      let unresolved_mark = Mark::new();
      (
        visit_mut_pass(JSXTransformer::<&SingleThreadedComments>::new(
          super::JSXTransformerConfig {
            preserve_jsx: false,
            target: TransformTarget::MIXED,
            ..Default::default()
          },
          None,
          TransformMode::Development,
          Some(t.cm.clone()),
        )),
        react::react::<&SingleThreadedComments>(
          t.cm.clone(),
          None,
          react::Options {
            next: Some(false),
            runtime: Some(react::Runtime::Automatic),
            import_source: Some("@lynx-js/react".into()),
            pragma: None,
            pragma_frag: None,
            throw_if_namespace: None,
            development: Some(false),
            refresh: None,
            ..Default::default()
          },
          top_level_mark,
          unresolved_mark,
        ),
      )
    },
    worklet,
    // Input codes
    r#"
    function Comp() {
      const handleTap = () => {}
      const handleRef = () => {}
      return (
        <view>
          <text main-thread:bindtap={handleTap}>1</text>
          <text main-thread:ref={handleRef}>1</text>
        </view>
      )
    }
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| {
      let top_level_mark = Mark::new();
      let unresolved_mark = Mark::new();
      (
        visit_mut_pass(JSXTransformer::<&SingleThreadedComments>::new(
          super::JSXTransformerConfig {
            preserve_jsx: false,
            target: TransformTarget::MIXED,
            ..Default::default()
          },
          None,
          TransformMode::Development,
          Some(t.cm.clone()),
        )),
        react::react::<&SingleThreadedComments>(
          t.cm.clone(),
          None,
          react::Options {
            next: Some(false),
            runtime: Some(react::Runtime::Automatic),
            import_source: Some("@lynx-js/react".into()),
            pragma: None,
            pragma_frag: None,
            throw_if_namespace: None,
            development: Some(false),
            refresh: None,
            ..Default::default()
          },
          top_level_mark,
          unresolved_mark,
        ),
      )
    },
    gesture,
    // Input codes
    r#"
    function Comp() {
      const gesture = {}
      return (
        <view>
          <text main-thread:gesture={gesture}>1</text>
        </view>
      )
    }
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| {
      let top_level_mark = Mark::new();
      let unresolved_mark = Mark::new();
      (
        visit_mut_pass(JSXTransformer::<&SingleThreadedComments>::new(
          super::JSXTransformerConfig {
            preserve_jsx: false,
            target: TransformTarget::MIXED,
            ..Default::default()
          },
          None,
          TransformMode::Development,
          Some(t.cm.clone()),
        )),
        react::react::<&SingleThreadedComments>(
          t.cm.clone(),
          None,
          react::Options {
            next: Some(false),
            runtime: Some(react::Runtime::Automatic),
            import_source: Some("@lynx-js/react".into()),
            pragma: None,
            pragma_frag: None,
            throw_if_namespace: None,
            development: Some(false),
            refresh: None,
            ..Default::default()
          },
          top_level_mark,
          unresolved_mark,
        ),
      )
    },
    basic_timing_flag,
    // Input codes
    r#"
    function Comp() {
      return (
        <view>
          <text __lynx_timing_flag={'timing_flag'}>1</text>
        </view>
      )
    }
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    should_escape_newline_character,
    // Input codes
    r#"
    <view>
      <view className="123
456"></view>
      <view className="123
      456"></view>
      <view className="123

456"></view>
      <view className="123\n456"></view>
      <view className="123 456"></view>
      <view className="123  456"></view>
      <view className="123\t456"></view>
      <svg
        content='<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path d="M14.3723 11.9999L7.53902 5.16659C7.34376 4.97133 7.34376 4.65475 7.53902 4.45948L8.45826 3.54025C8.65353 3.34498 8.97011 3.34498 9.16537 3.54025L17.2714 11.6463C17.4667 11.8416 17.4667 12.1582 17.2714 12.3534L9.16537 20.4595C8.97011 20.6547 8.65353 20.6547 8.45826 20.4595L7.53902 19.5402C7.34376 19.345 7.34376 19.0284 7.53903 18.8331L14.3723 11.9999Z" fill="white"/>
        </svg>'
        style={{
          width: "24rpx",
          height: "24rpx",
          opacity: "0.4",
        }}
        id="x
y"
        data-attr="x
        y"
        __lynx_timing_flag="
aaaaa
"
      ></svg>
    </view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    should_wrap_dynamic_key,
    // Input codes
    r#"
    <view>
      <text>Hello, ReactLynx, {hello}</text>
      <text key={hello}>{hello}</text>
      <text key="hello">{hello}</text>
    </view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    should_set_attribute_for_text_node,
    // Input codes
    r#"
    <view>
      <text text="Hello World 0"></text>
      <text text=" "></text>
      <text></text>
      <text class="hello" text="Hello World 1"></text>
      <text {...attrs} text="Hello World 2"></text>
      <text text="Hello Lynx" text="Hello World 3"></text>
    </view>
    "#
  );

  test!(
    module,
    Syntax::Es(EsSyntax {
      jsx: true,
      ..Default::default()
    }),
    |t| visit_mut_pass(JSXTransformer::new(
      super::JSXTransformerConfig {
        preserve_jsx: true,
        ..Default::default()
      },
      Some(t.comments.clone()),
      TransformMode::Test,
      Some(t.cm.clone()),
    )),
    should_create_raw_text_node_for_text_node,
    // Input codes
    r#"
    <view>
      <text>{hello}, ReactLynx 1</text>
      <text>{hello}</text>
      <text>
        Hello
        <text text="ReactLynx 2"></text>
      </text>
      <x-text>Hello, ReactLynx 3</x-text>
    </view>
    "#
  );
}
