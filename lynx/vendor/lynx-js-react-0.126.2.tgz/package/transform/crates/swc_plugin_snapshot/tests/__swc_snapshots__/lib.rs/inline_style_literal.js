import * as ReactLynx from "@lynx-js/react";
const __snapshot_da39a_test_1 = "__snapshot_da39a_test_1";
ReactLynx.snapshotCreatorMap[__snapshot_da39a_test_1] = (__snapshot_da39a_test_1)=>ReactLynx.createSnapshot(__snapshot_da39a_test_1, function() {
        const pageId = ReactLynx.__pageId;
        const el = __CreateView(pageId);
        __SetInlineStyles(el, "color:red;height:100px;flex-shrink:1");
        return [
            el
        ];
    }, null, null, undefined, globDynamicComponentEntry, null, true);
<__snapshot_da39a_test_1/>;
