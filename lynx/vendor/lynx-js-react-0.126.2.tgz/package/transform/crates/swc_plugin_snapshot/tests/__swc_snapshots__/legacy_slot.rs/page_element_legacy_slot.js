import * as ReactLynx from "@lynx-js/react";
import * as ReactLynxRuntimeComponents from '@lynx-js/react/runtime-components';
const __snapshot_da39a_test_1 = "__snapshot_da39a_test_1";
ReactLynx.snapshotCreatorMap[__snapshot_da39a_test_1] = (__snapshot_da39a_test_1)=>ReactLynx.createSnapshot(__snapshot_da39a_test_1, function() {
        const pageId = ReactLynx.__pageId;
        const el = __CreateView(pageId);
        return [
            el
        ];
    }, null, ReactLynx.__DynamicPartChildren_0, undefined, globDynamicComponentEntry, null, true);
<ReactLynxRuntimeComponents.Page custom-key-str="custom-value" custom-key-var={customVariable} class="classValue" data-attr={dataAttr}>
      <__snapshot_da39a_test_1>{[
    <ReactLynxRuntimeComponents.Page/>,
    <A/>
]}</__snapshot_da39a_test_1>
    </ReactLynxRuntimeComponents.Page>;
