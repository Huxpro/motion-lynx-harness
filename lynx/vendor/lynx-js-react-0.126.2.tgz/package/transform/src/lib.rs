#![deny(clippy::all)]
#![allow(clippy::boxed_local, clippy::borrowed_box, clippy::deprecated_cfg_attr)]

#[macro_use]
extern crate napi_derive;
mod bundle;
mod esbuild;
mod swc_plugin_compat_post;
mod swc_plugin_extract_str;
mod swc_plugin_refresh;
mod swc_plugin_transform_builtin_attribute_names;
mod swc_plugin_worklet_post_process;

use std::{cell::RefCell, rc::Rc, vec};

use napi::{bindgen_prelude::AsyncTask, Either, Env, Task};

use rustc_hash::FxBuildHasher;

use swc_core::{
  atoms::Atom,
  base::{
    config::{GlobalPassOption, IsModule, SourceMapsConfig},
    Compiler, PrintArgs,
  },
  common::{
    comments::SingleThreadedComments,
    errors::{DiagnosticBuilder, Emitter, Handler, HANDLER},
    pass::Optional,
    sync::Lrc,
    FileName, FilePathMapping, Mark, SourceMap, DUMMY_SP, GLOBALS,
  },
  ecma::{
    ast::*,
    codegen,
    parser::{Syntax, TsSyntax},
    transforms::{
      base::{
        fixer::fixer,
        helpers,
        hygiene::{hygiene_with_config, Config},
        resolver,
      },
      optimization::{simplifier, simplify},
      react, typescript,
    },
    visit::visit_mut_pass,
  },
};

// currently `use xxx as yyy` is not supported by napi-rs
// So we have to use different name
use swc_plugin_background_only::BackgroundOnlyVisitor;
use swc_plugin_compat::napi::{CompatVisitor, CompatVisitorConfig};
use swc_plugin_compat_post::CompatPostVisitor;
use swc_plugin_css_scope::napi::{CSSScopeVisitor, CSSScopeVisitorConfig};
use swc_plugin_define_dce::napi::DefineDCEVisitorConfig;
use swc_plugin_directive_dce::napi::{DirectiveDCEVisitor, DirectiveDCEVisitorConfig};
use swc_plugin_dynamic_import::napi::{DynamicImportVisitor, DynamicImportVisitorConfig};
use swc_plugin_element_template::napi::{
  ElementTemplateAsset, ElementTemplateTransformer, ElementTemplateTransformerConfig,
};
use swc_plugin_element_template::ElementTemplateAsset as CoreElementTemplateAsset;
use swc_plugin_inject::napi::{InjectVisitor, InjectVisitorConfig};
use swc_plugin_refresh::{RefreshVisitor, RefreshVisitorConfig};
use swc_plugin_shake::napi::{ShakeVisitor, ShakeVisitorConfig};
use swc_plugin_snapshot::{
  napi::{
    JSXTransformer as SnapshotJSXTransformer, JSXTransformerConfig as SnapshotJSXTransformerConfig,
  },
  UISourceMapRecord as SnapshotCoreUISourceMapRecord,
};
use swc_plugin_transform_builtin_attribute_names::TransformBuiltinAttributeNamesVisitor;
pub use swc_plugin_transform_builtin_attribute_names::{
  TransformBuiltinAttributeNamesMode, TransformBuiltinAttributeNamesOptions,
};
use swc_plugin_worklet::napi::{WorkletVisitor, WorkletVisitorConfig};
use swc_plugins_shared::defines::{DefineKind, DefinesCollector};
use swc_plugins_shared::{
  engine_version::is_engine_version_ge,
  transform_mode_napi::TransformMode,
  utils::{calc_hash, WEBPACK_VARS},
};

#[derive(Debug, Clone, Copy)]
pub struct SyntaxConfig(Syntax);

impl From<SyntaxConfig> for Syntax {
  fn from(value: SyntaxConfig) -> Self {
    value.0
  }
}

impl Default for SyntaxConfig {
  fn default() -> Self {
    // override default
    Self(Syntax::Typescript(TsSyntax {
      tsx: true,
      decorators: true,
      ..Default::default()
    }))
  }
}

impl napi::bindgen_prelude::FromNapiValue for SyntaxConfig {
  unsafe fn from_napi_value(
    env: napi::sys::napi_env,
    napi_val: napi::sys::napi_value,
  ) -> napi::Result<Self> {
    Ok(SyntaxConfig(
      serde_json::from_str(<&str>::from_napi_value(env, napi_val)?).map_err(|err| {
        napi::bindgen_prelude::error!(
          napi::bindgen_prelude::Status::InvalidArg,
          "SyntaxConfig: {}",
          err,
        )
      })?,
    ))
  }
}

impl napi::bindgen_prelude::ToNapiValue for SyntaxConfig {
  unsafe fn to_napi_value(
    env: napi::sys::napi_env,
    val: Self,
  ) -> napi::Result<napi::sys::napi_value> {
    <&str>::to_napi_value(
      env,
      &serde_json::to_string(&val.0).map_err(|err| {
        napi::bindgen_prelude::error!(
          napi::bindgen_prelude::Status::InvalidArg,
          "SyntaxConfig: {}",
          err,
        )
      })?,
    )
  }
}

#[derive(Debug, PartialEq, Clone, Copy, Default)]
pub struct IsModuleConfig(IsModule);

impl From<IsModuleConfig> for IsModule {
  fn from(value: IsModuleConfig) -> Self {
    value.0
  }
}

impl napi::bindgen_prelude::FromNapiValue for IsModuleConfig {
  unsafe fn from_napi_value(
    env: napi::bindgen_prelude::sys::napi_env,
    napi_val: napi::bindgen_prelude::sys::napi_value,
  ) -> napi::bindgen_prelude::Result<Self> {
    let bool_val = <bool>::from_napi_value(env, napi_val);
    if let Ok(bool_val) = bool_val {
      return Ok(IsModuleConfig(IsModule::Bool(bool_val)));
    }

    let str_val = <&str>::from_napi_value(env, napi_val);

    if let Ok(val) = str_val {
      match val {
        "unknown" => return Ok(IsModuleConfig(IsModule::Unknown)),
        "commonjs" => return Ok(IsModuleConfig(IsModule::CommonJS)),
        _ => {
          return Err(napi::bindgen_prelude::error!(
            napi::bindgen_prelude::Status::InvalidArg,
            "Invalid variant '{}' for enum IsModuleConfig",
            val
          ));
        }
      }
    }

    Err(napi::bindgen_prelude::error!(
      napi::bindgen_prelude::Status::InvalidArg,
      "value does not match any variant of enum `{}`",
      "IsModuleConfig"
    ))
  }
}

impl napi::bindgen_prelude::ToNapiValue for IsModuleConfig {
  unsafe fn to_napi_value(
    env: napi::bindgen_prelude::sys::napi_env,
    val: Self,
  ) -> napi::bindgen_prelude::Result<napi::bindgen_prelude::sys::napi_value> {
    match val.0 {
      IsModule::Bool(v) => <bool>::to_napi_value(env, v),
      IsModule::Unknown => <&str>::to_napi_value(env, "unknown"),
      IsModule::CommonJS => <&str>::to_napi_value(env, "commonjs"),
    }
  }
}

#[napi(object)]
#[derive(Clone, Debug)]
pub struct TransformNodiffOptions {
  /// @internal
  /// This is used internally to make sure the test output is consistent.
  #[napi(ts_type = "'production' | 'development' | 'test'")]
  pub mode: Option<TransformMode>,
  pub plugin_name: String,
  pub filename: String,
  pub source_file_name: Option<String>,
  pub sourcemap: Either<bool, String>,
  pub source_map_columns: Option<bool>,
  pub inline_sources_content: Option<bool>,
  /// @public
  /// This is swc syntax config in JSON format
  #[napi(ts_type = "string")]
  pub syntax_config: Option<SyntaxConfig>,
  #[napi(ts_type = "boolean | 'unknown'")]
  pub is_module: Option<IsModuleConfig>,
  pub css_scope: Either<bool, CSSScopeVisitorConfig>,
  pub snapshot: Option<Either<bool, SnapshotJSXTransformerConfig>>,
  #[napi(js_name = "elementTemplate")]
  pub element_template: Option<Either<bool, ElementTemplateTransformerConfig>>,
  pub engine_version: Option<String>,
  pub shake: Either<bool, ShakeVisitorConfig>,
  pub compat: Either<bool, CompatVisitorConfig>,
  pub refresh: Either<bool, RefreshVisitorConfig>,
  #[napi(js_name = "defineDCE")]
  pub define_dce: Either<bool, DefineDCEVisitorConfig>,
  #[napi(js_name = "directiveDCE")]
  pub directive_dce: Either<bool, DirectiveDCEVisitorConfig>,
  pub worklet: Either<bool, WorkletVisitorConfig>,
  pub dynamic_import: Option<Either<bool, DynamicImportVisitorConfig>>,
  /**
   * Transform attribute names on Lynx builtin elements.
   *
   * `true` applies the default rule: `onClick` becomes `bindtap`,
   * `onCatchTap` becomes `catchtap`, other `onXXX` names become `bindxxx`,
   * and remaining camelCase names become dash-case. An object provides
   * serializable custom rules.
   * Explicit JSX attributes are transformed during compilation. Attributes
   * supplied through JSX spreads are transformed by the runtime with the same
   * rules.
   *
   * @experimental
   */
  #[napi(
    js_name = "experimental_transformBuiltinAttributeNames",
    ts_type = "boolean | TransformBuiltinAttributeNamesOptions"
  )]
  pub experimental_transform_builtin_attribute_names:
    Option<Either<bool, TransformBuiltinAttributeNamesOptions>>,
  /// @internal
  pub inject: Option<Either<bool, InjectVisitorConfig>>,
  pub input_source_map: Option<String>,
}

impl Default for TransformNodiffOptions {
  fn default() -> Self {
    Self {
      mode: Some(TransformMode::Production),
      plugin_name: Default::default(),
      filename: Default::default(),
      source_file_name: Default::default(),
      sourcemap: Either::A(false),
      source_map_columns: None,
      inline_sources_content: None,
      syntax_config: None,
      is_module: Default::default(),
      css_scope: Either::B(Default::default()),
      snapshot: Default::default(),
      element_template: Default::default(),
      engine_version: None,
      shake: Either::A(false),
      compat: Either::A(false),
      refresh: Either::A(false),
      define_dce: Either::A(false),
      directive_dce: Either::A(false),
      worklet: Either::A(false),
      dynamic_import: Some(Either::B(Default::default())),
      experimental_transform_builtin_attribute_names: None,
      inject: Some(Either::A(false)),
      input_source_map: None,
    }
  }
}

#[napi(object)]
pub struct UiSourceMapRecord {
  pub ui_source_map: i32,
  pub filename: String,
  pub line_number: u32,
  pub column_number: u32,
  #[napi(js_name = "snapshotId")]
  pub snapshot_id: Option<String>,
}

/// @internal
#[napi(object)]
pub struct Define {
  /// @internal
  pub id: String,
  /// @internal
  pub code: String,
  /// @internal
  pub unmergeable: Option<bool>,
}

#[napi(object)]
pub struct TransformNodiffOutput {
  pub code: String,
  pub map: Option<String>,

  // #[napi(ts_type = "Array<import('esbuild').PartialMessage>")]
  pub errors: Vec<esbuild::PartialMessage>,
  // #[napi(ts_type = "Array<import('esbuild').PartialMessage>")]
  pub warnings: Vec<esbuild::PartialMessage>,
  pub ui_source_map_records: Vec<UiSourceMapRecord>,
  /// @internal
  #[napi(js_name = "elementTemplates")]
  pub element_templates: Option<Vec<ElementTemplateAsset>>,
  /// @internal
  #[napi(js_name = "definesForSnapshot")]
  pub defines_for_snapshot: Option<Vec<Define>>,
  /// @internal
  #[napi(js_name = "definesForWorklet")]
  pub defines_for_worklet: Option<Vec<Define>>,
}

fn print_define(
  c: &Compiler,
  items: Vec<ModuleItem>,
  top_level_mark: Mark,
  comments: &SingleThreadedComments,
) -> Result<String, String> {
  let module = match Program::Module(Module {
    span: DUMMY_SP,
    body: items,
    shebang: None,
  })
  .apply(&mut (
    hygiene_with_config(Config {
      top_level_mark,
      ..Default::default()
    }),
    fixer(Some(comments)),
  )) {
    Program::Module(m) => m,
    _ => return Err("hygiene produced a non-module program".into()),
  };

  c.print(
    &Program::Module(module),
    PrintArgs {
      output: None,
      source_root: "".into(),
      source_file_name: None,
      source_map_url: None,
      source_map_ignore_list: None,
      output_path: None,
      inline_sources_content: true,
      source_map: SourceMapsConfig::Bool(false),
      source_map_names: &Default::default(),
      orig: None,
      comments: Some(comments),
      emit_source_map_columns: false,
      emit_source_map_scopes: false,
      preamble: "",
      codegen_config: codegen::Config::default()
        .with_target(EsVersion::latest())
        .with_minify(false)
        .with_ascii_only(false),
    },
  )
  .map(|r| r.code)
  .map_err(|err| err.to_string())
}

type ElementTemplateCollector = Rc<RefCell<Vec<CoreElementTemplateAsset>>>;

fn take_element_templates(
  collector: Option<ElementTemplateCollector>,
) -> Option<Vec<ElementTemplateAsset>> {
  collector.map(|collector| {
    collector
      .borrow_mut()
      .drain(..)
      .map(|template| template.into())
      .collect()
  })
}

/// A multi emitter that forwards to multiple emitters.
pub struct MultiEmitter {
  emitters: Vec<Box<dyn Emitter>>,
}

impl MultiEmitter {
  pub fn new(emitters: Vec<Box<dyn Emitter>>) -> Self {
    Self { emitters }
  }
}

impl Emitter for MultiEmitter {
  fn emit(&mut self, db: &mut DiagnosticBuilder<'_>) {
    for emitter in &mut self.emitters {
      emitter.emit(db);
    }
  }
}

fn clone_snapshot_ui_source_map_records(
  ui_source_map_records: &Rc<RefCell<Vec<SnapshotCoreUISourceMapRecord>>>,
  filename: &str,
) -> Vec<UiSourceMapRecord> {
  ui_source_map_records
    .borrow()
    .iter()
    .cloned()
    .map(|record| UiSourceMapRecord {
      ui_source_map: record.ui_source_map,
      filename: filename.to_string(),
      line_number: record.line_number,
      column_number: record.column_number,
      snapshot_id: Some(record.snapshot_id),
    })
    .collect()
}

pub struct TransformTask {
  pub code: String,
  pub options: TransformNodiffOptions,
}

fn transform_react_lynx_inner(
  code: String,
  options: TransformNodiffOptions,
) -> TransformNodiffOutput {
  let content_hash = match options.mode {
    Some(TransformMode::Test) => "test".into(),
    _ => calc_hash(code.as_str()),
  };
  let comments = SingleThreadedComments::default();
  let cm = Lrc::new(SourceMap::new(FilePathMapping::empty()));
  let fm = cm.new_source_file(FileName::Real(options.filename.clone().into()).into(), code);

  let c = Compiler::new(cm.clone());

  let (esbuild_emitter, errors, warnings) =
    esbuild::EsbuildEmitter::new(options.plugin_name.clone(), Some(c.cm.clone()));
  let esbuild_emitter = Box::new(esbuild_emitter);
  let emitter = Box::new(MultiEmitter::new(vec![esbuild_emitter]));
  let handler = Handler::with_emitter(true, false, emitter);

  let snapshot_ui_source_map_records: Rc<RefCell<Vec<SnapshotCoreUISourceMapRecord>>> =
    Rc::new(RefCell::new(vec![]));

  let result = GLOBALS.set(&Default::default(), || {
    let program = c.parse_js(
      fm,
      &handler,
      EsVersion::latest(),
      options.syntax_config.unwrap_or_default().into(),
      options.is_module.unwrap_or_default().into(),
      Some(&comments),
    );
    let program = match program {
      Ok(program) => program,
      Err(_) => {
        return TransformNodiffOutput {
          code: "".into(),
          map: None,
          errors: vec![],
          warnings: warnings.read().unwrap().clone(),
          ui_source_map_records: vec![],
          element_templates: None,
          defines_for_snapshot: None,
          defines_for_worklet: None,
        };
      }
    };

    let unresolved_mark = Mark::new();
    let top_level_mark = Mark::new();
    let top_retain = WEBPACK_VARS.iter().map(|&s| s.into()).collect::<Vec<_>>();

    let simplify_pass_1 = Optional::new(
      simplifier(
        top_level_mark,
        simplify::Config {
          dce: simplify::dce::Config {
            preserve_imports_with_side_effects: false,
            top_retain: top_retain.clone(),
            ..Default::default()
          },
          ..Default::default()
        },
      ),
      match &options.directive_dce {
        Either::A(config) => *config,
        Either::B(_) => true,
      } || match &options.define_dce {
        Either::A(config) => *config,
        Either::B(_) => true,
      },
    );

    let directive_dce_plugin = match options.directive_dce {
      Either::A(config) => Optional::new(
        visit_mut_pass(DirectiveDCEVisitor::new(Default::default())),
        config,
      ),
      Either::B(config) => Optional::new(visit_mut_pass(DirectiveDCEVisitor::new(config)), true),
    };

    let define_dce_plugin = {
      let opts = GlobalPassOption {
        vars: match &options.define_dce {
          Either::A(_) => Default::default(),
          Either::B(config) => {
            let mut map = indexmap::IndexMap::<_, _, FxBuildHasher>::default();
            for (key, value) in &config.define {
              map.insert(key.as_str().into(), value.as_str().into());
            }
            map
          }
        },
        envs: Default::default(),
        typeofs: Default::default(),
      };

      Optional::new(
        opts.build(&cm, &handler),
        matches!(options.define_dce, Either::B(_)),
      )
    };

    let css_scope_plugin = match options.css_scope {
      Either::A(enabled) => Optional::new(
        visit_mut_pass(CSSScopeVisitor::new(
          CSSScopeVisitorConfig::default(),
          Some(&comments),
        )),
        enabled,
      ),
      Either::B(config) => Optional::new(
        visit_mut_pass(CSSScopeVisitor::new(config, Some(&comments))),
        true,
      ),
    };

    let (snapshot_plugin_config, snapshot_enabled) = match options.snapshot.as_ref() {
      Some(Either::A(config)) => (
        SnapshotJSXTransformerConfig {
          filename: options.filename.clone(),
          ..Default::default()
        },
        *config,
      ),
      Some(Either::B(config)) => (config.clone(), true),
      None => (
        SnapshotJSXTransformerConfig {
          filename: options.filename.clone(),
          ..Default::default()
        },
        true,
      ),
    };
    let (element_template_plugin_config, element_template_enabled) =
      match options.element_template.as_ref() {
        Some(Either::A(config)) => (
          ElementTemplateTransformerConfig {
            filename: options.filename.clone(),
            ..Default::default()
          },
          *config,
        ),
        Some(Either::B(config)) => (config.clone(), true),
        None => (
          ElementTemplateTransformerConfig {
            filename: options.filename.clone(),
            ..Default::default()
          },
          false,
        ),
      };
    // `elementTemplate` chooses the ET backend directly. Once it is enabled, the
    // public transform entrypoint no longer consults Snapshot-specific ET flags.
    if options.snapshot.is_some()
      && options.element_template.is_some()
      && snapshot_enabled
      && element_template_enabled
    {
      warnings.write().unwrap().push(esbuild::PartialMessage {
        id: None,
        plugin_name: Some(options.plugin_name.clone()),
        text: Some(
          "`elementTemplate` takes precedence when both `snapshot` and `elementTemplate` are enabled; `snapshot` will be ignored.".into(),
        ),
        location: None,
        notes: None,
        detail: None,
      });
    }
    let use_element_template_plugin = element_template_enabled;
    let use_snapshot_plugin = snapshot_enabled && !use_element_template_plugin;
    let jsx_backend_enabled = use_snapshot_plugin || use_element_template_plugin;
    let active_jsx_import_source = if use_element_template_plugin {
      element_template_plugin_config.jsx_import_source.clone()
    } else {
      snapshot_plugin_config.jsx_import_source.clone()
    };
    let preserve_jsx = if use_element_template_plugin {
      element_template_plugin_config.preserve_jsx
    } else {
      snapshot_plugin_config.preserve_jsx
    };
    let enable_ui_source_map =
      !use_element_template_plugin && snapshot_plugin_config.enable_ui_source_map.unwrap_or(false);

    let background_only_plugin = Optional::new(
      visit_mut_pass(BackgroundOnlyVisitor::new()),
      jsx_backend_enabled,
    );

    let react_transformer = Optional::new(
      react::react(
        cm.clone(),
        Some(&comments),
        react::Options {
          next: Some(false),
          runtime: Some(react::Runtime::Automatic),
          import_source: active_jsx_import_source.map(Atom::from),
          pragma: None,
          pragma_frag: None,
          // We may want `main-thread:foo={fooMainThreadFunc}` to work
          throw_if_namespace: Some(false),
          development: Some(matches!(options.mode, Some(TransformMode::Development))),
          refresh: None,
          ..Default::default()
        },
        top_level_mark,
        unresolved_mark,
      ),
      jsx_backend_enabled && !preserve_jsx,
    );

    let defines_collector: DefinesCollector = Rc::new(RefCell::new(vec![]));

    let snapshot_plugin = if use_snapshot_plugin {
      let transformer = SnapshotJSXTransformer::new(
        snapshot_plugin_config.clone(),
        Some(&comments),
        options.mode.unwrap_or(TransformMode::Production),
        Some(cm.clone()),
      )
      .with_content_hash(content_hash.clone());

      let transformer = if enable_ui_source_map {
        transformer.with_ui_source_map_records(snapshot_ui_source_map_records.clone())
      } else {
        transformer
      };

      let transformer =
        transformer.with_defines_collector(defines_collector.clone());

      Optional::new(visit_mut_pass(transformer), true)
    } else {
      Optional::new(
        visit_mut_pass(SnapshotJSXTransformer::new(
          snapshot_plugin_config.clone(),
          Some(&comments),
          options.mode.unwrap_or(TransformMode::Production),
          Some(cm.clone()),
        )),
        false,
      )
    };
    let element_templates_collector =
      use_element_template_plugin.then(|| Rc::new(RefCell::new(vec![])));
    let element_template_plugin = if use_element_template_plugin {
      // ET template assets are a build artifact, not runtime JS. Keep one
      // collector per transform invocation so the output contract stays stable.
      let transformer = ElementTemplateTransformer::new_with_element_templates(
        element_template_plugin_config.clone(),
        Some(&comments),
        options.mode.unwrap_or(TransformMode::Production),
        Some(cm.clone()),
        element_templates_collector.clone(),
      )
      .with_content_hash(content_hash.clone());

      Optional::new(visit_mut_pass(transformer), true)
    } else {
      Optional::new(
        visit_mut_pass(ElementTemplateTransformer::new(
          element_template_plugin_config.clone(),
          Some(&comments),
          options.mode.unwrap_or(TransformMode::Production),
          Some(cm.clone()),
        )),
        false,
      )
    };

    let legacy_slot = matches!(snapshot_plugin_config.legacy_slot, Some(true));
    let list_plugin = Optional::new(
      visit_mut_pass(swc_plugin_list::ListVisitor::new(Some(&comments))),
      jsx_backend_enabled && !legacy_slot,
    );
    let legacy_list_plugin = Optional::new(
      visit_mut_pass(swc_plugin_list::LegacyListVisitor::new(Some(&comments))),
      jsx_backend_enabled && legacy_slot,
    );

    let is_ge_3_1: bool = is_engine_version_ge(&options.engine_version, "3.1");
    let text_plugin = Optional::new(
      visit_mut_pass(swc_plugin_text::TextVisitor {}),
      jsx_backend_enabled && is_ge_3_1,
    );

    let shake_plugin = match options.shake.clone() {
      Either::A(config) => Optional::new(visit_mut_pass(ShakeVisitor::default()), config),
      Either::B(config) => Optional::new(visit_mut_pass(ShakeVisitor::new(config)), true),
    };

    let simplify_pass = simplifier(
      top_level_mark,
      simplify::Config {
        dce: simplify::dce::Config {
          preserve_imports_with_side_effects: false,
          top_retain: top_retain.clone(),
          ..Default::default()
        },
        ..Default::default()
      },
    );

    let compat_plugin = match options.compat.clone() {
      Either::A(config) => Optional::new(
        visit_mut_pass(CompatVisitor::new(
          CompatVisitorConfig::default(),
          Some(&comments),
        )),
        config,
      ),
      Either::B(config) => Optional::new(
        visit_mut_pass(CompatVisitor::new(config, Some(&comments))),
        true,
      ),
    };

    let transform_builtin_attribute_names = options
      .experimental_transform_builtin_attribute_names
      .clone();
    let enable_transform_builtin_attribute_names = !matches!(
      transform_builtin_attribute_names,
      None | Some(Either::A(false))
    );
    let transform_builtin_attribute_names_visitor = match transform_builtin_attribute_names {
      Some(Either::B(options)) => TransformBuiltinAttributeNamesVisitor::new(options),
      None | Some(Either::A(_)) => TransformBuiltinAttributeNamesVisitor::default(),
    };
    let transform_builtin_attribute_names_plugin = Optional::new(
      visit_mut_pass(transform_builtin_attribute_names_visitor),
      enable_transform_builtin_attribute_names,
    );

    let compat_post_plugin = match options.compat {
      Either::A(config) => Optional::new(
        visit_mut_pass(CompatPostVisitor::new(
          Default::default(),
          unresolved_mark,
          top_level_mark,
        )),
        config,
      ),
      Either::B(config) => Optional::new(
        visit_mut_pass(CompatPostVisitor::new(
          config,
          unresolved_mark,
          top_level_mark,
        )),
        true,
      ),
    };

    let refresh_plugin = match options.refresh {
      Either::A(config) => Optional::new(
        visit_mut_pass(RefreshVisitor::new(
          RefreshVisitorConfig::default(),
          content_hash.clone(),
        )),
        config,
      ),
      Either::B(config) => Optional::new(
        visit_mut_pass(RefreshVisitor::new(config, content_hash.clone())),
        true,
      ),
    };

    let worklet_plugin = match options.worklet {
      Either::A(config) => {
        let visitor = WorkletVisitor::default().with_content_hash(content_hash);
        let visitor =
          visitor.with_defines_collector(defines_collector.clone());
        Optional::new(visit_mut_pass(visitor), config)
      }
      Either::B(config) => {
        let visitor =
          WorkletVisitor::new(options.mode.unwrap_or(TransformMode::Production), config)
            .with_content_hash(content_hash);
        let visitor =
          visitor.with_defines_collector(defines_collector.clone());
        Optional::new(visit_mut_pass(visitor), true)
      }
    };

    let dynamic_import_plugin = match options.dynamic_import.unwrap_or(Either::A(true)) {
      Either::A(config) => Optional::new(
        visit_mut_pass(DynamicImportVisitor::new(
          Default::default(),
          Some(&comments),
        )),
        config,
      ),
      Either::B(config) => Optional::new(
        visit_mut_pass(DynamicImportVisitor::new(config, Some(&comments))),
        true,
      ),
    };

    let inject_plugin = match options.inject.unwrap_or(Either::A(false)) {
      Either::A(config) => Optional::new(
        visit_mut_pass(InjectVisitor::new(
          Default::default(),
          unresolved_mark,
          top_level_mark,
        )),
        config,
      ),
      Either::B(config) => Optional::new(
        visit_mut_pass(InjectVisitor::new(config, unresolved_mark, top_level_mark)),
        true,
      ),
    };

    let pass = (
      &mut fixer(Some(&comments)),
      resolver(unresolved_mark, top_level_mark, true),
      typescript::typescript(
        typescript::Config {
          verbatim_module_syntax: false,
          import_not_used_as_values: typescript::ImportsNotUsedAsValues::Remove,
          ..Default::default()
        },
        unresolved_mark,
        top_level_mark,
      ),
      (background_only_plugin, dynamic_import_plugin),
      refresh_plugin,
      (compat_plugin, transform_builtin_attribute_names_plugin),
      worklet_plugin,
      css_scope_plugin,
      (
        text_plugin,
        list_plugin,
        legacy_list_plugin,
        snapshot_plugin,
        element_template_plugin,
      ),
      directive_dce_plugin,
      define_dce_plugin,
      simplify_pass_1, // do simplify after DCE above to make shake below works better
      (
        shake_plugin,
        simplify_pass,
        react_transformer,
        // TODO(hongzhiyuan.hzy): if `ident` we added above is correctly marked, this pass will be unnecessary
        resolver(unresolved_mark, top_level_mark, true),
        compat_post_plugin,
        inject_plugin,
        hygiene_with_config(Config {
          top_level_mark,
          ..Default::default()
        }),
        &mut fixer(Some(&comments)),
      ),
    );

    let program = helpers::HELPERS.set(&helpers::Helpers::new(true), || {
      HANDLER.set(&handler, || program.apply(pass))
    });

    let result = c.print(
      &program,
      PrintArgs {
        output: None,
        source_root: "".into(), // TODO: add root
        source_file_name: options.source_file_name.as_deref(),
        source_map_url: None,
        source_map_ignore_list: None,
        output_path: None,
        inline_sources_content: options.inline_sources_content.unwrap_or(true),
        source_map: match options.sourcemap {
          Either::A(b) => SourceMapsConfig::Bool(b),
          Either::B(s) => SourceMapsConfig::Str(s),
        },
        source_map_names: &Default::default(),
        orig: match &options.input_source_map {
          Some(s) => {
            let bytes = s.as_bytes();
            swc_sourcemap::SourceMap::from_reader(bytes).ok()
          }
          None => None,
        },
        comments: Some(&comments),
        emit_source_map_columns: options.source_map_columns.unwrap_or(true),
        emit_source_map_scopes: false,
        preamble: "",
        codegen_config: codegen::Config::default()
          .with_target(EsVersion::latest())
          .with_minify(false)
          .with_ascii_only(false),
      },
    );

    match result {
      Ok(result) => {
        // Drain after the whole SWC pass finishes: dynamic-component transforms
        // can discover multiple template assets while walking one module, and
        // the caller expects one stable array per transform invocation.
        let element_templates = take_element_templates(element_templates_collector);

        let mut define_errors: Vec<esbuild::PartialMessage> = vec![];
        let mut defines_for_snapshot: Vec<Define> = vec![];
        let mut defines_for_worklet: Vec<Define> = vec![];
        helpers::HELPERS.set(&helpers::Helpers::new(false), || {
          for define in defines_collector.borrow().iter() {
            let printed = Define {
              id: define.id.clone(),
              unmergeable: define.unmergeable.then_some(true),
              code: match print_define(&c, define.items.clone(), top_level_mark, &comments) {
                Ok(code) => code,
                Err(err) => {
                  define_errors.push(esbuild::PartialMessage {
                    id: None,
                    plugin_name: Some(options.plugin_name.clone()),
                    text: Some(format!(
                      "failed to print the collected definition `{}`: {}",
                      define.id, err
                    )),
                    location: None,
                    notes: None,
                    detail: None,
                  });
                  "".into()
                }
              },
            };
            match define.kind {
              DefineKind::Snapshot => defines_for_snapshot.push(printed),
              DefineKind::Worklet => defines_for_worklet.push(printed),
            }
          }
        });

        TransformNodiffOutput {
          code: result.code,
          map: result.map,
          errors: define_errors,
          warnings: vec![],
          ui_source_map_records: if use_element_template_plugin {
            vec![]
          } else {
            clone_snapshot_ui_source_map_records(&snapshot_ui_source_map_records, &options.filename)
          },
          element_templates,
          defines_for_snapshot: Some(defines_for_snapshot),
          defines_for_worklet: Some(defines_for_worklet),
        }
      }
      Err(_) => {
        let element_templates = take_element_templates(element_templates_collector);
        return TransformNodiffOutput {
          code: "".into(),
          map: None,
          errors: vec![],
          warnings: warnings.read().unwrap().clone(),
          ui_source_map_records: if use_element_template_plugin {
            vec![]
          } else {
            clone_snapshot_ui_source_map_records(&snapshot_ui_source_map_records, &options.filename)
          },
          element_templates,
          defines_for_snapshot: None,
          defines_for_worklet: None,
        };
      }
    }
  });

  let mut transform_errors = errors.read().unwrap().clone();
  transform_errors.extend(result.errors);

  let r = TransformNodiffOutput {
    code: result.code,
    map: result.map,
    errors: transform_errors,
    warnings: warnings.read().unwrap().clone(),
    ui_source_map_records: result.ui_source_map_records,
    // Preserve the element-template assets collected in the successful transform
    // path instead of dropping them in the final wrapper object.
    element_templates: result.element_templates,
    defines_for_snapshot: result.defines_for_snapshot,
    defines_for_worklet: result.defines_for_worklet,
  };

  r
}

#[napi]
pub fn transform_react_lynx_sync(
  _env: Env,
  code: String,
  options: Option<TransformNodiffOptions>,
) -> napi::Result<TransformNodiffOutput> {
  let out = transform_react_lynx_inner(code, options.unwrap_or_default());
  napi::Result::Ok(out)
}

#[napi]
impl Task for TransformTask {
  type Output = TransformNodiffOutput;
  type JsValue = TransformNodiffOutput;
  fn compute(&mut self) -> napi::Result<Self::Output> {
    let out = transform_react_lynx_inner(self.code.clone(), self.options.clone());
    Ok(out)
  }
  fn resolve(&mut self, _: napi::Env, output: Self::Output) -> napi::Result<Self::JsValue> {
    napi::Result::Ok(output)
  }
}

#[napi]
pub fn transform_react_lynx(
  _env: Env,
  code: String,
  options: Option<TransformNodiffOptions>,
) -> napi::Result<AsyncTask<TransformTask>> {
  Ok(AsyncTask::new(TransformTask {
    code,
    options: options.unwrap_or_default(),
  }))
}

pub struct BundleTransformTask {
  pub code: String,
  pub options: bundle::TransformNodiffBundleOptions,
}

#[napi]
impl Task for BundleTransformTask {
  type Output = bundle::TransformNodiffBundleOutput;
  type JsValue = bundle::TransformNodiffBundleOutput;
  fn compute(&mut self) -> napi::Result<Self::Output> {
    let out = bundle::transform_bundle_result_inner(self.code.clone(), self.options.clone());
    Ok(out)
  }
  fn resolve(&mut self, _: napi::Env, output: Self::Output) -> napi::Result<Self::JsValue> {
    napi::Result::Ok(output)
  }
}

#[napi]
pub fn transform_bundle_result_sync(
  _env: Env,
  code: String,
  options: Option<bundle::TransformNodiffBundleOptions>,
) -> napi::Result<bundle::TransformNodiffBundleOutput> {
  let out = bundle::transform_bundle_result_inner(code, options.unwrap_or_default());
  napi::Result::Ok(out)
}

#[napi]
pub fn transform_bundle_result(
  _env: Env,
  code: String,
  options: Option<bundle::TransformNodiffBundleOptions>,
) -> napi::Result<AsyncTask<BundleTransformTask>> {
  Ok(AsyncTask::new(BundleTransformTask {
    code,
    options: options.unwrap_or_default(),
  }))
}

#[cfg(all(target_arch = "wasm32", target_os = "unknown"))]
mod wasm {
  use ::napi::{JsObject, NapiValue};

  const fn max(a: usize, b: usize) -> usize {
    [a, b][(a < b) as usize]
  }

  const ALIGN: usize = max(
    8, // wasm32 max_align_t
    max(std::mem::size_of::<usize>(), std::mem::align_of::<usize>()),
  );

  #[no_mangle]
  pub unsafe extern "C" fn malloc(size: usize) -> *mut u8 {
    let layout = match std::alloc::Layout::from_size_align(size + ALIGN, ALIGN) {
      Ok(layout) => layout,
      Err(_) => return core::ptr::null_mut(),
    };

    let ptr = std::alloc::alloc(layout);
    if ptr.is_null() {
      return core::ptr::null_mut();
    }

    *(ptr as *mut usize) = size;
    ptr.offset(ALIGN as isize)
  }

  #[no_mangle]
  pub unsafe extern "C" fn free(ptr: *mut u8) {
    let ptr = ptr.offset(-(ALIGN as isize));
    let size = *(ptr as *mut usize);
    let layout = std::alloc::Layout::from_size_align_unchecked(size + ALIGN, ALIGN);

    std::alloc::dealloc(ptr, layout);
  }

  #[no_mangle]
  pub unsafe extern "C" fn napi_register_wasm_v1(
    raw_env: napi::sys::napi_env,
    raw_exports: napi::sys::napi_value,
  ) {
    // let env = Env::from_raw(raw_env);
    let mut exports = JsObject::from_raw_unchecked(raw_env, raw_exports);

    #[cfg_attr(rustfmt, rustfmt_skip)]
    {
      let _ = exports.create_named_method("transformReactLynxSync", crate::__napi__transform_react_lynx_sync);
      let _ = exports.create_named_method("transformBundleResultSync", crate::__napi__transform_bundle_result_sync);
      let _ = exports.create_named_method("transformReactLynx", crate::__napi__transform_react_lynx);
      let _ = exports.create_named_method("transformBundleResult", crate::__napi__transform_bundle_result);
    }
  }
}

#[cfg(test)]
mod tests {
  use super::*;

  #[test]
  fn test_syntax_serialize_and_deserialize() {
    use serde_json::json;

    let json = json!({
      "syntax": "typescript",
      "tsx": true,
    });
    let s: Syntax = serde_json::from_value(json).unwrap();

    // println!("{:?}", serde_json::to_string(&s));

    assert!(s.typescript());
    assert!(!s.decorators()); // default to false
  }

  #[test]
  fn should_preserve_active_empty_element_template_collector() {
    let collector = Rc::new(RefCell::new(vec![]));

    assert_eq!(
      take_element_templates(Some(collector)).unwrap().len(),
      0,
      "an active ET transform must return Some([]), not None"
    );
  }

  #[test]
  fn should_drain_partial_element_templates() {
    let collector = Rc::new(RefCell::new(vec![CoreElementTemplateAsset {
      template_id: "_et_test".into(),
      compiled_template: serde_json::json!({ "kind": "element", "type": "view" }),
      source_file: "test.js".into(),
    }]));

    let templates = take_element_templates(Some(collector.clone())).unwrap();

    assert_eq!(templates.len(), 1);
    assert_eq!(templates[0].template_id, "_et_test");
    assert!(
      collector.borrow().is_empty(),
      "collector should be drained exactly once"
    );
  }
}
