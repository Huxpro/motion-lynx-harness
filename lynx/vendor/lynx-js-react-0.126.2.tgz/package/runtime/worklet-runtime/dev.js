(()=>{
    function _define_property(obj, key, value) {
        if (key in obj) Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
        else obj[key] = value;
        return obj;
    }
    class Animation {
        cancel() {
            return __ElementAnimate(this.effect.target.element, [
                3,
                this.id
            ]);
        }
        pause() {
            return __ElementAnimate(this.effect.target.element, [
                2,
                this.id
            ]);
        }
        play() {
            return __ElementAnimate(this.effect.target.element, [
                1,
                this.id
            ]);
        }
        start() {
            return __ElementAnimate(this.effect.target.element, [
                0,
                this.id,
                this.effect.keyframes,
                this.effect.options
            ]);
        }
        constructor(effect){
            _define_property(this, "effect", void 0);
            _define_property(this, "id", void 0);
            this.effect = effect;
            this.id = '__lynx-inner-js-animation-' + Animation.count++;
            this.start();
        }
    }
    _define_property(Animation, "count", 0);
    function effect_define_property(obj, key, value) {
        if (key in obj) Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
        else obj[key] = value;
        return obj;
    }
    class KeyframeEffect {
        constructor(target, keyframes, options){
            effect_define_property(this, "target", void 0);
            effect_define_property(this, "keyframes", void 0);
            effect_define_property(this, "options", void 0);
            this.target = target;
            this.keyframes = keyframes;
            this.options = options;
        }
    }
    const TRACE_LIMIT = 256;
    const DEFAULT_FLUSH_LIMIT = 256;
    let trace = [];
    let flushCountInWindow = 0;
    let resetScheduled = false;
    let trippedError = null;
    function pushTrace(marker) {
        trace.push(marker);
        if (trace.length > TRACE_LIMIT) trace = trace.slice(trace.length - TRACE_LIMIT);
    }
    function compressTrace(markers) {
        if (0 === markers.length) return '';
        const out = [];
        let prev = markers[markers.length - 1];
        let count = 1;
        for(let i = markers.length - 2; i >= 0; i--){
            const cur = markers[i];
            if (cur === prev) {
                count++;
                continue;
            }
            out.push(1 === count ? prev : `${prev} x${count}`);
            prev = cur;
            count = 1;
        }
        out.push(1 === count ? prev : `${prev} x${count}`);
        return out.join(' <- ');
    }
    function mainThreadFlushLoopMark(marker) {
        pushTrace(marker);
    }
    function mainThreadFlushLoopOnFlushMicrotask() {
        if (trippedError) return trippedError;
        if (!resetScheduled) {
            resetScheduled = true;
            setTimeout(()=>{
                mainThreadFlushLoopReset();
            }, 0);
        }
        flushCountInWindow++;
        const limit = DEFAULT_FLUSH_LIMIT;
        if (flushCountInWindow > limit) {
            const traceText = compressTrace(trace);
            trippedError = new Error(`[ReactLynx][DEV] MainThread flush loop detected: render executed ${flushCountInWindow} times without yielding (limit=${limit}). Trace: ${traceText}`);
            return trippedError;
        }
        return null;
    }
    function mainThreadFlushLoopReport(error) {
        setTimeout(()=>{
            throw error;
        }, 0);
    }
    function mainThreadFlushLoopReset() {
        trace = [];
        flushCountInWindow = 0;
        resetScheduled = false;
        trippedError = null;
    }
    function isSdkVersionGt(major, minor) {
        var _SystemInfo_lynxSdkVersion;
        const lynxSdkVersion = null != (_SystemInfo_lynxSdkVersion = SystemInfo.lynxSdkVersion) ? _SystemInfo_lynxSdkVersion : '1.0';
        const version = lynxSdkVersion.split('.');
        return Number(version[0]) > major || Number(version[0]) == major && Number(version[1]) > minor;
    }
    function element_define_property(obj, key, value) {
        if (key in obj) Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
        else obj[key] = value;
        return obj;
    }
    let willFlush = false;
    let shouldFlush = true;
    function setShouldFlush(value) {
        shouldFlush = value;
    }
    class Element {
        setAttribute(name, value) {
            mainThreadFlushLoopMark(`element:setAttribute ${name}`);
            __SetAttribute(this.element, name, value);
            this.flushElementTree();
        }
        setStyleProperty(name, value) {
            mainThreadFlushLoopMark(`element:setStyleProperty ${name}`);
            __AddInlineStyle(this.element, name, value);
            this.flushElementTree();
        }
        setStyleProperties(styles) {
            mainThreadFlushLoopMark(`element:setStyleProperties keys=${Object.keys(styles).length}`);
            for(const key in styles)__AddInlineStyle(this.element, key, styles[key]);
            this.flushElementTree();
        }
        getAttribute(attributeName) {
            return __GetAttributeByName(this.element, attributeName);
        }
        getAttributeNames() {
            return __GetAttributeNames(this.element);
        }
        querySelector(selector) {
            const ref = __QuerySelector(this.element, selector, {});
            return ref ? new Element(ref) : null;
        }
        querySelectorAll(selector) {
            return __QuerySelectorAll(this.element, selector, {}).map((element)=>new Element(element));
        }
        getComputedStyleProperty(key) {
            if (!isSdkVersionGt(3, 4)) throw new Error('getComputedStyleProperty requires Lynx sdk version 3.5');
            if (!key) throw new Error('getComputedStyleProperty: key is required');
            return __GetComputedStyleByKey(this.element, key);
        }
        animate(keyframes, options) {
            const normalizedOptions = 'number' == typeof options ? {
                duration: options
            } : null != options ? options : {};
            return new Animation(new KeyframeEffect(this, keyframes, normalizedOptions));
        }
        invoke(methodName, params) {
            mainThreadFlushLoopMark(`element:invoke ${methodName}`);
            return new Promise((resolve, reject)=>{
                __InvokeUIMethod(this.element, methodName, null != params ? params : {}, (res)=>{
                    if (0 === res.code) resolve(res.data);
                    else reject(new Error('UI method invoke: ' + JSON.stringify(res)));
                });
                this.flushElementTree();
            });
        }
        flushElementTree() {
            if (willFlush || !shouldFlush) return;
            willFlush = true;
            Promise.resolve().then(()=>{
                willFlush = false;
                {
                    mainThreadFlushLoopMark('render');
                    const error = mainThreadFlushLoopOnFlushMicrotask();
                    if (error) {
                        shouldFlush = false;
                        mainThreadFlushLoopReport(error);
                        return;
                    }
                }
                __FlushElementTree();
            });
        }
        constructor(element){
            element_define_property(this, "element", void 0);
            Object.defineProperty(this, 'element', {
                get () {
                    return element;
                }
            });
        }
    }
    function lepusQuerySelector_define_property(obj, key, value) {
        if (key in obj) Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
        else obj[key] = value;
        return obj;
    }
    class PageElement {
        static get() {
            var _PageElement;
            null != (_PageElement = PageElement).pageElement || (_PageElement.pageElement = __GetPageElement());
            return PageElement.pageElement;
        }
    }
    lepusQuerySelector_define_property(PageElement, "pageElement", void 0);
    function querySelector(cssSelector) {
        const pageElement = PageElement.get();
        if (!pageElement) return null;
        const element = __QuerySelector(pageElement, cssSelector, {});
        return element ? new Element(element) : null;
    }
    function querySelectorAll(cssSelector) {
        const pageElement = PageElement.get();
        if (!pageElement) return [];
        return __QuerySelectorAll(pageElement, cssSelector, {}).map((element)=>new Element(element));
    }
    function initApiEnv() {
        var _lynx_clearInterval;
        lynx.querySelector = querySelector;
        lynx.querySelectorAll = querySelectorAll;
        globalThis.setTimeout = lynx.setTimeout;
        globalThis.setInterval = lynx.setInterval;
        globalThis.clearTimeout = lynx.clearTimeout;
        globalThis.clearInterval = null != (_lynx_clearInterval = lynx.clearInterval) ? _lynx_clearInterval : lynx.clearTimeInterval;
        {
            const requestAnimationFrame = lynx.requestAnimationFrame;
            lynx.requestAnimationFrame = globalThis.requestAnimationFrame = (callback)=>{
                if (!isSdkVersionGt(2, 15)) throw new Error("requestAnimationFrame in main thread script requires Lynx sdk version 2.16");
                return requestAnimationFrame(callback);
            };
        }
        globalThis.cancelAnimationFrame = lynx.cancelAnimationFrame;
    }
    function runRunOnMainThreadTask(task, params, resolveId) {
        let returnValue;
        try {
            returnValue = runWorklet(task, params);
        } finally{
            lynx.getJSContext().dispatchEvent({
                type: "Lynx.Worklet.FunctionCallRet",
                data: JSON.stringify({
                    resolveId,
                    returnValue
                })
            });
        }
    }
    const mainThreadObjectDefinitions = new Map();
    let realizedMainThreadObjectTypes = new WeakMap();
    function registerMainThreadObjectType(type, create) {
        if ('main-thread' === type) throw new Error('MainThreadObject type "main-thread" is reserved for MainThreadRef.');
        const registered = mainThreadObjectDefinitions.get(type);
        if (registered) {
            if (getFactoryRegistrationIdentity(registered.create) !== getFactoryRegistrationIdentity(create)) throw new Error(`Conflicting MainThreadObject registration for type "${type}". A type key must always use the same create function.`);
            return;
        }
        mainThreadObjectDefinitions.set(type, {
            create
        });
    }
    function getFactoryRegistrationIdentity(factory) {
        if ('function' == typeof factory) return Function.prototype.toString.call(factory);
        return `worklet:${factory._wkltId}`;
    }
    function resolveFactoryFunction(factory) {
        if ('function' == typeof factory) return factory;
        if (!('_wkltId' in factory) || '_lepusWorkletHash' in factory) throw new Error('Cannot resolve an invalid Main Thread Function.');
        return lynxWorkletImpl._workletMap[factory._wkltId];
    }
    function getMainThreadObjectFactory(definition) {
        var _definition, _resolvedCreate;
        return null != (_resolvedCreate = (_definition = definition).resolvedCreate) ? _resolvedCreate : _definition.resolvedCreate = resolveFactoryFunction(definition.create);
    }
    function createMainThreadObject(refImpl) {
        const type = refImpl._type;
        const definition = mainThreadObjectDefinitions.get(type);
        if (!definition) throw new Error(`MainThreadObject type is not registered: "${type}". Define the type in a module evaluated on the main thread before initializing its handle.`);
        const value = getMainThreadObjectFactory(definition)(refImpl._initValue);
        if ('object' != typeof value || null === value) throw new Error(`MainThreadObject type "${type}" created a non-object value.`);
        realizedMainThreadObjectTypes.set(value, type);
        return value;
    }
    function isRealizedMainThreadObject(value) {
        return realizedMainThreadObjectTypes.has(value);
    }
    function assertCompatibleMainThreadObject(handle, value, operation) {
        const actualType = realizedMainThreadObjectTypes.get(value);
        const expectedType = handle._type;
        if (actualType !== expectedType) throw new Error(`MainThreadObject type mismatch during ${operation} for handle ${handle._wvid}: background handle expects type "${expectedType}", but the main-thread target is type "${actualType}".`);
    }
    function initMainThreadObjects() {
        mainThreadObjectDefinitions.clear();
        realizedMainThreadObjectTypes = new WeakMap();
    }
    function profile(sliceName, f) {
        var _console_profile, _console;
        null == (_console_profile = (_console = console).profile) || _console_profile.call(_console, sliceName);
        try {
            return f();
        } finally{
            var _console_profileEnd, _console1;
            null == (_console_profileEnd = (_console1 = console).profileEnd) || _console_profileEnd.call(_console1);
        }
    }
    let impl;
    function initWorkletRef() {
        initMainThreadObjects();
        return impl = {
            _workletRefMap: {},
            _firstScreenWorkletRefMap: {},
            updateWorkletRef,
            updateWorkletRefInitValueChanges,
            registerMainThreadObjectType: registerMainThreadObjectType,
            clearFirstScreenWorkletRefMap
        };
    }
    const createWorkletRef = (id, value)=>{
        const ref = {
            current: value,
            _wvid: id
        };
        return ref;
    };
    function createWorkletValue(refImpl) {
        return refImpl._type && 'main-thread' !== refImpl._type ? createMainThreadObject(refImpl) : createWorkletRef(refImpl._wvid, refImpl._initValue);
    }
    function isMutableCell(value) {
        return 'object' == typeof value && null !== value && 'number' == typeof value._wvid && Object.prototype.hasOwnProperty.call(value, 'current');
    }
    function isHydratedWorkletValue(value) {
        return 'object' == typeof value && null !== value && (isRealizedMainThreadObject(value) || isMutableCell(value));
    }
    function assertCompatibleWorkletValue(handle, value, operation) {
        let actualKind;
        if (isRealizedMainThreadObject(value)) actualKind = 'typed-object';
        else if (isMutableCell(value)) actualKind = 'mutable-cell';
        if (!actualKind) throw new Error(`Cannot apply MainThreadObject ${operation} for handle ${handle._wvid}: the existing target has no worklet-value metadata.`);
        const expectedType = handle._type;
        const expectedKind = expectedType && 'main-thread' !== expectedType ? 'typed-object' : 'mutable-cell';
        if (actualKind !== expectedKind) throw new Error(`Worklet value kind mismatch during ${operation} for handle ${handle._wvid}: background handle expects ${expectedKind}, but the main-thread target is ${actualKind}.`);
        if ('typed-object' === actualKind) assertCompatibleMainThreadObject(handle, value, operation);
    }
    const getFromWorkletRefMap = (refImpl)=>{
        const id = refImpl._wvid;
        mainThreadFlushLoopMark(`MainThreadRef:get id=${id}`);
        let value;
        if (id < 0) {
            var _impl__firstScreenWorkletRefMap, _id, _;
            value = null != (_ = (_impl__firstScreenWorkletRefMap = impl._firstScreenWorkletRefMap)[_id = id]) ? _ : _impl__firstScreenWorkletRefMap[_id] = createWorkletValue(refImpl);
        } else value = impl._workletRefMap[id];
        if (void 0 === value) throw new Error('MainThreadRef is not initialized: ' + id);
        return value;
    };
    function removeValueFromWorkletRefMap(id) {
        delete impl._workletRefMap[id];
    }
    function hydrateWorkletValue(handle, value) {
        assertCompatibleWorkletValue(handle, value, 'hydration');
        impl._workletRefMap[handle._wvid] = value;
    }
    function updateWorkletRef(handle, element) {
        getFromWorkletRefMap(handle).current = element ? new Element(element) : null;
    }
    function updateWorkletRefInitValueChanges(patch) {
        profile('updateWorkletRefInitValueChanges', ()=>{
            let firstError;
            let hasError = false;
            patch.forEach(([id, value, type])=>{
                try {
                    const handle = {
                        _wvid: id,
                        _initValue: value,
                        _type: type
                    };
                    const existing = impl._workletRefMap[id];
                    if (existing) assertCompatibleWorkletValue(handle, existing, 'initialization patch');
                    else impl._workletRefMap[id] = createWorkletValue(handle);
                } catch (error) {
                    if (!hasError) {
                        firstError = error;
                        hasError = true;
                    }
                }
            });
            if (hasError) throw firstError;
        });
    }
    function clearFirstScreenWorkletRefMap() {
        impl._firstScreenWorkletRefMap = {};
    }
    function initEventListeners() {
        const jsContext = lynx.getJSContext();
        jsContext.addEventListener("Lynx.Worklet.runWorkletCtx", (event)=>{
            const data = JSON.parse(event.data);
            runRunOnMainThreadTask(data.worklet, data.params, data.resolveId);
        });
        jsContext.addEventListener("Lynx.Worklet.releaseWorkletRef", (event)=>{
            removeValueFromWorkletRefMap(event.data.id);
        });
    }
    let delayRunOnBackground_impl;
    function initRunOnBackgroundDelay() {
        return delayRunOnBackground_impl = {
            delayedBackgroundFunctionArray: [],
            clearDelayedBackgroundFunctions,
            delayRunOnBackground,
            runDelayedBackgroundFunctions
        };
    }
    function delayRunOnBackground(fnObj, task) {
        var _fnObj, __delayIndices;
        delayRunOnBackground_impl.delayedBackgroundFunctionArray.push({
            task
        });
        const delayIndices = null != (__delayIndices = (_fnObj = fnObj)._delayIndices) ? __delayIndices : _fnObj._delayIndices = [];
        delayIndices.push(delayRunOnBackground_impl.delayedBackgroundFunctionArray.length - 1);
    }
    function clearDelayedBackgroundFunctions() {
        delayRunOnBackground_impl.delayedBackgroundFunctionArray.length = 0;
    }
    function runDelayedBackgroundFunctions() {
        for (const details of delayRunOnBackground_impl.delayedBackgroundFunctionArray)if (null == details ? void 0 : details.jsFnHandle) details.task(details.jsFnHandle._jsFnId, details.jsFnHandle._execId);
        clearDelayedBackgroundFunctions();
    }
    let delayWorkletEvent_impl;
    function initEventDelay() {
        return delayWorkletEvent_impl = {
            _delayedWorkletParamsMap: new Map(),
            runDelayedWorklet,
            clearDelayedWorklets
        };
    }
    function delayExecUntilJsReady(hash, params) {
        profile('delayExecUntilJsReady: ' + hash, ()=>{
            const map = delayWorkletEvent_impl._delayedWorkletParamsMap;
            const paramVec = map.get(hash);
            if (paramVec) paramVec.push(params);
            else map.set(hash, [
                params
            ]);
        });
    }
    function runDelayedWorklet(worklet, element) {
        profile('commitDelayedWorklet', ()=>{
            const paramsVec = delayWorkletEvent_impl._delayedWorkletParamsMap.get(worklet._wkltId);
            if (void 0 === paramsVec) return;
            const leftParamsVec = [];
            paramsVec.forEach((params)=>{
                var _firstParam_currentTarget;
                const firstParam = params[0];
                if ((null == firstParam ? void 0 : null == (_firstParam_currentTarget = firstParam.currentTarget) ? void 0 : _firstParam_currentTarget.elementRefptr) === element) setTimeout(()=>{
                    profile('runDelayedWorklet', ()=>{
                        runWorklet(worklet, params);
                    });
                }, 0);
                else leftParamsVec.push(params);
            });
            delayWorkletEvent_impl._delayedWorkletParamsMap.set(worklet._wkltId, leftParamsVec);
        });
    }
    function clearDelayedWorklets() {
        delayWorkletEvent_impl._delayedWorkletParamsMap.clear();
    }
    function initEomImpl() {
        return {
            setShouldFlush: setShouldFlush
        };
    }
    const EventResult = {
        kDefault: 0x0,
        kStopPropagationMask: 0x1,
        kStopImmediatePropagationMask: 0x2
    };
    function isEventObject(ctx, options) {
        if (!Array.isArray(ctx) || 'object' != typeof ctx[0] || null === ctx[0]) return false;
        if (options && 1 === options.source) return true;
        return false;
    }
    function addEventMethodsIfNeeded(ctx, options) {
        if (!isEventObject(ctx, options)) return [
            false,
            {}
        ];
        const eventCtx = {};
        const eventObj = ctx[0];
        eventObj['stopPropagation'] = function() {
            var _eventCtx__eventReturnResult;
            eventCtx._eventReturnResult = (null != (_eventCtx__eventReturnResult = eventCtx._eventReturnResult) ? _eventCtx__eventReturnResult : EventResult.kDefault) | EventResult.kStopPropagationMask;
        };
        eventObj['stopImmediatePropagation'] = function() {
            var _eventCtx__eventReturnResult;
            eventCtx._eventReturnResult = (null != (_eventCtx__eventReturnResult = eventCtx._eventReturnResult) ? _eventCtx__eventReturnResult : EventResult.kDefault) | EventResult.kStopImmediatePropagationMask;
        };
        return [
            true,
            eventCtx
        ];
    }
    function hydrateCtx(ctx, firstScreenCtx) {
        profile('hydrateCtx', ()=>{
            hydrateCtxImpl(ctx, firstScreenCtx, ctx._execId);
        });
    }
    function hydrateCtxImpl(ctx, firstScreenCtx, execId) {
        if (!ctx || 'object' != typeof ctx || !firstScreenCtx || 'object' != typeof firstScreenCtx) return;
        const ctxObj = ctx;
        const firstScreenCtxObj = firstScreenCtx;
        if (ctxObj['_wkltId'] && ctxObj['_wkltId'] !== firstScreenCtxObj['_wkltId']) return;
        if (isTypedWorkletRefDescriptor(ctxObj)) return void hydrateWorkletValueHandle(ctxObj, firstScreenCtxObj);
        for(const key in ctx)if ('_wvid' === key) hydrateMainThreadRef(ctxObj[key], firstScreenCtxObj);
        else if ('_jsFn' === key) hydrateDelayRunOnBackgroundTasks(ctxObj[key], firstScreenCtxObj[key], execId);
        else {
            const firstScreenValue = 'function' == typeof firstScreenCtxObj[key] ? firstScreenCtxObj[key].boundCtx : firstScreenCtxObj[key];
            hydrateCtxImpl(ctxObj[key], firstScreenValue, execId);
        }
    }
    function isTypedWorkletRefDescriptor(value) {
        const descriptor = value;
        return 'number' == typeof descriptor._wvid && 'string' == typeof descriptor._type;
    }
    function hydrateMainThreadRef(refId, value) {
        if ('_initValue' in value) return;
        lynxWorkletImpl._refImpl._workletRefMap[refId] = value;
    }
    function hydrateWorkletValueHandle(handle, value) {
        if (!isHydratedWorkletValue(value)) return;
        hydrateWorkletValue(handle, value);
    }
    function hydrateDelayRunOnBackgroundTasks(fnObjs, firstScreenFnObjs, execId) {
        for(const fnName in fnObjs){
            const fnObj = fnObjs[fnName];
            const firstScreenFnObj = firstScreenFnObjs[fnName];
            if (!(null == firstScreenFnObj ? void 0 : firstScreenFnObj._delayIndices)) {
                if (firstScreenFnObj) {
                    firstScreenFnObj._isFirstScreen = false;
                    firstScreenFnObj._execId = execId;
                    Object.assign(firstScreenFnObj, fnObj);
                }
                continue;
            }
            for (const index of firstScreenFnObj._delayIndices){
                const details = lynxWorkletImpl._runOnBackgroundDelayImpl.delayedBackgroundFunctionArray[index];
                if (details) {
                    fnObj._execId = execId;
                    details.jsFnHandle = fnObj;
                }
            }
        }
    }
    function jsFunctionLifecycle_define_property(obj, key, value) {
        if (key in obj) Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
        else obj[key] = value;
        return obj;
    }
    class JsFunctionLifecycleManager {
        addRef(execId, objToRef) {
            var _this_execIdRefCount_get;
            if (this.retainedObjects.has(objToRef)) return;
            this.retainedObjects.add(objToRef);
            this.execIdRefCount.set(execId, (null != (_this_execIdRefCount_get = this.execIdRefCount.get(execId)) ? _this_execIdRefCount_get : 0) + 1);
            this.registry.register(objToRef, execId);
        }
        removeRef(execId) {
            const rc = this.execIdRefCount.get(execId);
            if (rc > 1) return void this.execIdRefCount.set(execId, rc - 1);
            this.execIdRefCount.delete(execId);
            this.execIdSetToFire.add(execId);
            if (!this.willFire) {
                this.willFire = true;
                Promise.resolve().then(()=>{
                    this.fire();
                });
            }
        }
        fire() {
            profile('JsFunctionLifecycleManager.fire', ()=>{
                lynx.getJSContext().dispatchEvent({
                    type: "Lynx.Worklet.releaseBackgroundWorkletCtx",
                    data: Array.from(this.execIdSetToFire)
                });
                this.execIdSetToFire.clear();
                this.willFire = false;
            });
        }
        constructor(){
            jsFunctionLifecycle_define_property(this, "execIdRefCount", new Map());
            jsFunctionLifecycle_define_property(this, "execIdSetToFire", new Set());
            jsFunctionLifecycle_define_property(this, "retainedObjects", new WeakSet());
            jsFunctionLifecycle_define_property(this, "willFire", false);
            jsFunctionLifecycle_define_property(this, "registry", void 0);
            this.registry = new FinalizationRegistry(this.removeRef.bind(this));
        }
    }
    function isRunOnBackgroundEnabled() {
        return isSdkVersionGt(2, 15);
    }
    function initWorklet() {
        globalThis.lynxWorkletImpl = {
            _workletMap: {},
            _refImpl: initWorkletRef(),
            _runOnBackgroundDelayImpl: initRunOnBackgroundDelay(),
            _hydrateCtx: hydrateCtx,
            _eventDelayImpl: initEventDelay(),
            _eomImpl: initEomImpl(),
            _runRunOnMainThreadTask: runRunOnMainThreadTask
        };
        if (isRunOnBackgroundEnabled()) globalThis.lynxWorkletImpl._jsFunctionLifecycleManager = new JsFunctionLifecycleManager();
        globalThis.registerWorklet = registerWorklet;
        globalThis.registerWorkletInternal = registerWorklet;
        globalThis.runWorklet = workletRuntime_runWorklet;
    }
    function registerWorklet(_type, id, worklet) {
        lynxWorkletImpl._workletMap[id] = worklet;
    }
    function workletRuntime_runWorklet(ctx, params, options) {
        if (!validateWorklet(ctx)) return;
        if ((null == options ? void 0 : options.source) === 1 && Array.isArray(params)) {
            const first = params[0];
            const t = first.type;
            if ('string' == typeof t) mainThreadFlushLoopMark(`event:${t}`);
        }
        mainThreadFlushLoopMark(`MainThreadFunction id=${String(ctx._wkltId)}`);
        if ('_lepusWorkletHash' in ctx) return void delayExecUntilJsReady(ctx._lepusWorkletHash, params);
        return runWorkletImpl(ctx, params, options);
    }
    function runWorkletImpl(ctx, params, options) {
        const worklet = profile('transformWorkletCtx ' + ctx._wkltId, ()=>transformWorklet(ctx, true));
        const params_ = profile('transformWorkletParams', ()=>transformWorklet(params || [], false));
        const [hasEventMethods, eventCtx] = addEventMethodsIfNeeded(params_, options);
        const result = profile('runWorklet', ()=>worklet(...params_));
        if (hasEventMethods) return {
            returnValue: result,
            eventReturnResult: eventCtx._eventReturnResult
        };
        return result;
    }
    function validateWorklet(ctx) {
        return 'object' == typeof ctx && null !== ctx && ('_wkltId' in ctx || '_lepusWorkletHash' in ctx);
    }
    const workletCache = /*#__PURE__*/ new WeakMap();
    function transformWorklet(ctx, isWorklet) {
        if ('object' != typeof ctx || null === ctx) return ctx;
        if (isWorklet) {
            const res = workletCache.get(ctx);
            if (res) return res;
        }
        const worklet = transformWorkletInner({
            main: ctx
        }, 0, ctx);
        if (isWorklet) workletCache.set(ctx, worklet.main);
        return worklet.main;
    }
    const transformWorkletInner = (value, depth, ctx)=>{
        const limit = 1000;
        if (++depth >= limit) throw new Error('Depth of value exceeds limit of ' + limit + '.');
        if ('object' != typeof value || null === value) return value;
        let obj = value;
        for(const key in obj){
            const subObj = obj[key];
            if ('object' != typeof subObj || null === subObj) continue;
            if (isRealizedMainThreadObject(subObj)) continue;
            if (isMainThreadObjectDescriptor(subObj)) {
                obj = replaceCapturedProperty(obj, value, key, getFromWorkletRefMap(subObj));
                continue;
            }
            if ('elementRefptr' in subObj) {
                obj[key] = new Element(subObj.elementRefptr);
                continue;
            } else if (subObj instanceof Element) continue;
            const transformedSubObj = transformWorkletInner(subObj, depth, ctx);
            const isWorkletRef = '_wvid' in subObj;
            if (isWorkletRef) {
                obj[key] = getFromWorkletRefMap(subObj);
                continue;
            }
            const isWorklet = '_wkltId' in subObj;
            if (isWorklet) {
                const isRootWorklet = subObj === ctx;
                const boundCtx = {
                    ...transformedSubObj
                };
                const boundWorklet = lynxWorkletImpl._workletMap[subObj._wkltId].bind(boundCtx);
                if (transformedSubObj !== subObj && obj === value && obj !== ctx) obj = copyAccessorCapture(obj);
                obj = replaceCapturedProperty(obj, value, key, boundWorklet);
                if (!isRootWorklet) boundWorklet.boundCtx = boundCtx;
                continue;
            }
            if (transformedSubObj !== subObj) {
                if (obj === value && obj !== ctx) obj = copyAccessorCapture(obj);
                obj = replaceCapturedProperty(obj, value, key, transformedSubObj);
            }
            const isJsFn = '_jsFnId' in subObj;
            if (isJsFn) {
                var _lynxWorkletImpl__jsFunctionLifecycleManager;
                subObj['_execId'] = ctx._execId;
                null == (_lynxWorkletImpl__jsFunctionLifecycleManager = lynxWorkletImpl._jsFunctionLifecycleManager) || _lynxWorkletImpl__jsFunctionLifecycleManager.addRef(ctx._execId, subObj);
                continue;
            }
        }
        return obj;
    };
    function replaceCapturedProperty(obj, source, key, value) {
        const descriptor = Object.getOwnPropertyDescriptor(obj, key);
        if (null == descriptor ? void 0 : descriptor.get) {
            const capturedDescriptor = {
                value,
                writable: true,
                enumerable: descriptor.enumerable,
                configurable: descriptor.configurable
            };
            if (obj === source || !descriptor.configurable) {
                const descriptors = Object.getOwnPropertyDescriptors(obj);
                descriptors[key] = capturedDescriptor;
                return copyAccessorCapture(obj, descriptors);
            }
            Object.defineProperty(obj, key, capturedDescriptor);
        } else obj[key] = value;
        return obj;
    }
    function copyAccessorCapture(obj, descriptors = Object.getOwnPropertyDescriptors(obj)) {
        return Object.defineProperties(Array.isArray(obj) ? [] : Object.create(Object.getPrototypeOf(obj)), descriptors);
    }
    function isMainThreadObjectDescriptor(value) {
        const descriptor = value;
        return 'number' == typeof descriptor._wvid && 'string' == typeof descriptor._type && 'main-thread' !== descriptor._type;
    }
    if (void 0 === globalThis.lynxWorkletImpl) {
        initWorklet();
        initApiEnv();
        initEventListeners();
    }
})();

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGV2LmpzIiwic291cmNlcyI6WyIuLi9zcmMvd29ya2xldC1ydW50aW1lL2FwaS9hbmltYXRpb24vYW5pbWF0aW9uLnRzIiwiLi4vc3JjL3dvcmtsZXQtcnVudGltZS9hcGkvYW5pbWF0aW9uL2VmZmVjdC50cyIsIi4uL3NyYy93b3JrbGV0LXJ1bnRpbWUvdXRpbHMvbWFpblRocmVhZEZsdXNoTG9vcEd1YXJkLnRzIiwiLi4vc3JjL3dvcmtsZXQtcnVudGltZS91dGlscy92ZXJzaW9uLnRzIiwiLi4vc3JjL3dvcmtsZXQtcnVudGltZS9hcGkvZWxlbWVudC50cyIsIi4uL3NyYy93b3JrbGV0LXJ1bnRpbWUvYXBpL2xlcHVzUXVlcnlTZWxlY3Rvci50cyIsIi4uL3NyYy93b3JrbGV0LXJ1bnRpbWUvYXBpL2x5bnhBcGkudHMiLCIuLi9zcmMvd29ya2xldC1ydW50aW1lL3J1bk9uTWFpblRocmVhZC50cyIsIi4uL3NyYy93b3JrbGV0LXJ1bnRpbWUvbWFpblRocmVhZE9iamVjdC50cyIsIi4uL3NyYy93b3JrbGV0LXJ1bnRpbWUvdXRpbHMvcHJvZmlsZS50cyIsIi4uL3NyYy93b3JrbGV0LXJ1bnRpbWUvd29ya2xldFJlZi50cyIsIi4uL3NyYy93b3JrbGV0LXJ1bnRpbWUvbGlzdGVuZXJzLnRzIiwiLi4vc3JjL3dvcmtsZXQtcnVudGltZS9kZWxheVJ1bk9uQmFja2dyb3VuZC50cyIsIi4uL3NyYy93b3JrbGV0LXJ1bnRpbWUvZGVsYXlXb3JrbGV0RXZlbnQudHMiLCIuLi9zcmMvd29ya2xldC1ydW50aW1lL2VvbUltcGwudHMiLCIuLi9zcmMvd29ya2xldC1ydW50aW1lL2V2ZW50UHJvcGFnYXRpb24udHMiLCIuLi9zcmMvd29ya2xldC1ydW50aW1lL2h5ZHJhdGUudHMiLCIuLi9zcmMvd29ya2xldC1ydW50aW1lL2pzRnVuY3Rpb25MaWZlY3ljbGUudHMiLCIuLi9zcmMvd29ya2xldC1ydW50aW1lL3dvcmtsZXRSdW50aW1lLnRzIiwiLi4vc3JjL3dvcmtsZXQtcnVudGltZS9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb3B5cmlnaHQgMjAyNSBUaGUgTHlueCBBdXRob3JzLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuLy8gTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlIFZlcnNpb24gMi4wIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZVxuLy8gTElDRU5TRSBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuaW1wb3J0IHR5cGUgeyBLZXlmcmFtZUVmZmVjdCB9IGZyb20gJy4vZWZmZWN0LmpzJztcblxuZXhwb3J0IGVudW0gQW5pbWF0aW9uT3BlcmF0aW9uIHtcbiAgU1RBUlQgPSAwLCAvLyBTdGFydCBhIG5ldyBhbmltYXRpb25cbiAgUExBWSA9IDEsIC8vIFBsYXkvcmVzdW1lIGEgcGF1c2VkIGFuaW1hdGlvblxuICBQQVVTRSA9IDIsIC8vIFBhdXNlIGFuIGV4aXN0aW5nIGFuaW1hdGlvblxuICBDQU5DRUwgPSAzLCAvLyBDYW5jZWwgYW4gYW5pbWF0aW9uXG59XG5cbmV4cG9ydCBjbGFzcyBBbmltYXRpb24ge1xuICBzdGF0aWMgY291bnQgPSAwO1xuICBwdWJsaWMgcmVhZG9ubHkgZWZmZWN0OiBLZXlmcmFtZUVmZmVjdDtcbiAgcHVibGljIHJlYWRvbmx5IGlkOiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3IoZWZmZWN0OiBLZXlmcmFtZUVmZmVjdCkge1xuICAgIHRoaXMuZWZmZWN0ID0gZWZmZWN0O1xuICAgIHRoaXMuaWQgPSAnX19seW54LWlubmVyLWpzLWFuaW1hdGlvbi0nICsgQW5pbWF0aW9uLmNvdW50Kys7XG4gICAgdGhpcy5zdGFydCgpO1xuICB9XG5cbiAgcHVibGljIGNhbmNlbCgpOiB2b2lkIHtcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIGFjY2Vzc2luZyBwcml2YXRlIG1lbWJlciAnZWxlbWVudCdcbiAgICByZXR1cm4gX19FbGVtZW50QW5pbWF0ZSh0aGlzLmVmZmVjdC50YXJnZXQuZWxlbWVudCwgW0FuaW1hdGlvbk9wZXJhdGlvbi5DQU5DRUwsIHRoaXMuaWRdKTtcbiAgfVxuXG4gIHB1YmxpYyBwYXVzZSgpOiB2b2lkIHtcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIGFjY2Vzc2luZyBwcml2YXRlIG1lbWJlciAnZWxlbWVudCdcbiAgICByZXR1cm4gX19FbGVtZW50QW5pbWF0ZSh0aGlzLmVmZmVjdC50YXJnZXQuZWxlbWVudCwgW0FuaW1hdGlvbk9wZXJhdGlvbi5QQVVTRSwgdGhpcy5pZF0pO1xuICB9XG5cbiAgcHVibGljIHBsYXkoKTogdm9pZCB7XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciBhY2Nlc3NpbmcgcHJpdmF0ZSBtZW1iZXIgJ2VsZW1lbnQnXG4gICAgcmV0dXJuIF9fRWxlbWVudEFuaW1hdGUodGhpcy5lZmZlY3QudGFyZ2V0LmVsZW1lbnQsIFtBbmltYXRpb25PcGVyYXRpb24uUExBWSwgdGhpcy5pZF0pO1xuICB9XG5cbiAgcHJpdmF0ZSBzdGFydCgpOiB2b2lkIHtcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIGFjY2Vzc2luZyBwcml2YXRlIG1lbWJlciAnZWxlbWVudCdcbiAgICByZXR1cm4gX19FbGVtZW50QW5pbWF0ZSh0aGlzLmVmZmVjdC50YXJnZXQuZWxlbWVudCwgW1xuICAgICAgQW5pbWF0aW9uT3BlcmF0aW9uLlNUQVJULFxuICAgICAgdGhpcy5pZCxcbiAgICAgIHRoaXMuZWZmZWN0LmtleWZyYW1lcyxcbiAgICAgIHRoaXMuZWZmZWN0Lm9wdGlvbnMsXG4gICAgXSk7XG4gIH1cbn1cbiIsIi8vIENvcHlyaWdodCAyMDI1IFRoZSBMeW54IEF1dGhvcnMuIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4vLyBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UgVmVyc2lvbiAyLjAgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlXG4vLyBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3QgZGlyZWN0b3J5IG9mIHRoaXMgc291cmNlIHRyZWUuXG5pbXBvcnQgdHlwZSB7IEVsZW1lbnQgfSBmcm9tICcuLi9lbGVtZW50LmpzJztcblxuZXhwb3J0IGNsYXNzIEtleWZyYW1lRWZmZWN0IHtcbiAgcHVibGljIHJlYWRvbmx5IHRhcmdldDogRWxlbWVudDtcbiAgcHVibGljIHJlYWRvbmx5IGtleWZyYW1lczogUmVjb3JkPHN0cmluZywgbnVtYmVyIHwgc3RyaW5nPltdO1xuICBwdWJsaWMgcmVhZG9ubHkgb3B0aW9uczogUmVjb3JkPHN0cmluZywgbnVtYmVyIHwgc3RyaW5nPjtcblxuICBjb25zdHJ1Y3RvcihcbiAgICB0YXJnZXQ6IEVsZW1lbnQsXG4gICAga2V5ZnJhbWVzOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXIgfCBzdHJpbmc+W10sXG4gICAgb3B0aW9uczogUmVjb3JkPHN0cmluZywgbnVtYmVyIHwgc3RyaW5nPixcbiAgKSB7XG4gICAgdGhpcy50YXJnZXQgPSB0YXJnZXQ7XG4gICAgdGhpcy5rZXlmcmFtZXMgPSBrZXlmcmFtZXM7XG4gICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgfVxufVxuIiwiLy8gQ29weXJpZ2h0IDIwMjYgVGhlIEx5bnggQXV0aG9ycy4gQWxsIHJpZ2h0cyByZXNlcnZlZC5cbi8vIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSBWZXJzaW9uIDIuMCB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGVcbi8vIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cblxuY29uc3QgVFJBQ0VfTElNSVQgPSAyNTY7XG5jb25zdCBERUZBVUxUX0ZMVVNIX0xJTUlUID0gMjU2O1xuXG5sZXQgdHJhY2U6IHN0cmluZ1tdID0gW107XG5cbmxldCBmbHVzaENvdW50SW5XaW5kb3cgPSAwO1xubGV0IHJlc2V0U2NoZWR1bGVkID0gZmFsc2U7XG5sZXQgdHJpcHBlZEVycm9yOiBFcnJvciB8IG51bGwgPSBudWxsO1xuXG5mdW5jdGlvbiBwdXNoVHJhY2UobWFya2VyOiBzdHJpbmcpOiB2b2lkIHtcbiAgdHJhY2UucHVzaChtYXJrZXIpO1xuICBpZiAodHJhY2UubGVuZ3RoID4gVFJBQ0VfTElNSVQpIHtcbiAgICB0cmFjZSA9IHRyYWNlLnNsaWNlKHRyYWNlLmxlbmd0aCAtIFRSQUNFX0xJTUlUKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBjb21wcmVzc1RyYWNlKG1hcmtlcnM6IHN0cmluZ1tdKTogc3RyaW5nIHtcbiAgaWYgKG1hcmtlcnMubGVuZ3RoID09PSAwKSByZXR1cm4gJyc7XG4gIGNvbnN0IG91dDogc3RyaW5nW10gPSBbXTtcbiAgLy8gRGlzcGxheSBtb3N0LXJlY2VudC1maXJzdCB0byBtYWtlIGxvb3BzIGVhc2llciB0byByZWFkLlxuICBsZXQgcHJldiA9IG1hcmtlcnNbbWFya2Vycy5sZW5ndGggLSAxXSE7XG4gIGxldCBjb3VudCA9IDE7XG5cbiAgZm9yIChsZXQgaSA9IG1hcmtlcnMubGVuZ3RoIC0gMjsgaSA+PSAwOyBpLS0pIHtcbiAgICBjb25zdCBjdXIgPSBtYXJrZXJzW2ldITtcbiAgICBpZiAoY3VyID09PSBwcmV2KSB7XG4gICAgICBjb3VudCsrO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIG91dC5wdXNoKGNvdW50ID09PSAxID8gcHJldiA6IGAke3ByZXZ9IHgke2NvdW50fWApO1xuICAgIHByZXYgPSBjdXI7XG4gICAgY291bnQgPSAxO1xuICB9XG4gIG91dC5wdXNoKGNvdW50ID09PSAxID8gcHJldiA6IGAke3ByZXZ9IHgke2NvdW50fWApO1xuICByZXR1cm4gb3V0LmpvaW4oJyA8LSAnKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG1haW5UaHJlYWRGbHVzaExvb3BNYXJrKG1hcmtlcjogc3RyaW5nKTogdm9pZCB7XG4gIGlmIChfX0RFVl9fKSB7XG4gICAgcHVzaFRyYWNlKG1hcmtlcik7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG1haW5UaHJlYWRGbHVzaExvb3BPbkZsdXNoTWljcm90YXNrKCk6IEVycm9yIHwgbnVsbCB7XG4gIC8qIHY4IGlnbm9yZSBuZXh0IDEgKi9cbiAgaWYgKCFfX0RFVl9fKSByZXR1cm4gbnVsbDtcbiAgaWYgKHRyaXBwZWRFcnJvcikgcmV0dXJuIHRyaXBwZWRFcnJvcjtcblxuICBpZiAoIXJlc2V0U2NoZWR1bGVkKSB7XG4gICAgcmVzZXRTY2hlZHVsZWQgPSB0cnVlO1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgbWFpblRocmVhZEZsdXNoTG9vcFJlc2V0KCk7XG4gICAgfSwgMCk7XG4gIH1cblxuICBmbHVzaENvdW50SW5XaW5kb3crKztcbiAgY29uc3QgbGltaXQgPSBERUZBVUxUX0ZMVVNIX0xJTUlUO1xuICBpZiAoZmx1c2hDb3VudEluV2luZG93ID4gbGltaXQpIHtcbiAgICBjb25zdCB0cmFjZVRleHQgPSBjb21wcmVzc1RyYWNlKHRyYWNlKTtcbiAgICB0cmlwcGVkRXJyb3IgPSBuZXcgRXJyb3IoXG4gICAgICBgW1JlYWN0THlueF1bREVWXSBNYWluVGhyZWFkIGZsdXNoIGxvb3AgZGV0ZWN0ZWQ6IHJlbmRlciBleGVjdXRlZCAke2ZsdXNoQ291bnRJbldpbmRvd30gdGltZXMgd2l0aG91dCB5aWVsZGluZyAobGltaXQ9JHtsaW1pdH0pLiBUcmFjZTogJHt0cmFjZVRleHR9YCxcbiAgICApO1xuICAgIHJldHVybiB0cmlwcGVkRXJyb3I7XG4gIH1cblxuICByZXR1cm4gbnVsbDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG1haW5UaHJlYWRGbHVzaExvb3BSZXBvcnQoZXJyb3I6IEVycm9yKTogdm9pZCB7XG4gIGlmIChfX0RFVl9fKSB7XG4gICAgLy8gVGhyb3cgb24gbWFjcm90YXNrIHRvIGF2b2lkIFByb21pc2UtdW5oYW5kbGVkLXJlamVjdGlvbiBub2lzZS5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRocm93IGVycm9yO1xuICAgIH0sIDApO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWluVGhyZWFkRmx1c2hMb29wUmVzZXQoKTogdm9pZCB7XG4gIHRyYWNlID0gW107XG4gIGZsdXNoQ291bnRJbldpbmRvdyA9IDA7XG4gIHJlc2V0U2NoZWR1bGVkID0gZmFsc2U7XG4gIHRyaXBwZWRFcnJvciA9IG51bGw7XG59XG4iLCIvLyBDb3B5cmlnaHQgMjAyNCBUaGUgTHlueCBBdXRob3JzLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuLy8gTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlIFZlcnNpb24gMi4wIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZVxuLy8gTElDRU5TRSBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuZXhwb3J0IGZ1bmN0aW9uIGlzU2RrVmVyc2lvbkd0KG1ham9yOiBudW1iZXIsIG1pbm9yOiBudW1iZXIpOiBib29sZWFuIHtcbiAgY29uc3QgbHlueFNka1ZlcnNpb246IHN0cmluZyA9IFN5c3RlbUluZm8ubHlueFNka1ZlcnNpb24gPz8gJzEuMCc7XG4gIGNvbnN0IHZlcnNpb24gPSBseW54U2RrVmVyc2lvbi5zcGxpdCgnLicpO1xuICByZXR1cm4gKFxuICAgIE51bWJlcih2ZXJzaW9uWzBdKSA+IG1ham9yXG4gICAgfHwgKE51bWJlcih2ZXJzaW9uWzBdKSA9PSBtYWpvciAmJiBOdW1iZXIodmVyc2lvblsxXSkgPiBtaW5vcilcbiAgKTtcbn1cbiIsIi8vIENvcHlyaWdodCAyMDI0IFRoZSBMeW54IEF1dGhvcnMuIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4vLyBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UgVmVyc2lvbiAyLjAgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlXG4vLyBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3QgZGlyZWN0b3J5IG9mIHRoaXMgc291cmNlIHRyZWUuXG5pbXBvcnQgeyBBbmltYXRpb24gfSBmcm9tICcuL2FuaW1hdGlvbi9hbmltYXRpb24uanMnO1xuaW1wb3J0IHsgS2V5ZnJhbWVFZmZlY3QgfSBmcm9tICcuL2FuaW1hdGlvbi9lZmZlY3QuanMnO1xuaW1wb3J0IHtcbiAgbWFpblRocmVhZEZsdXNoTG9vcE1hcmssXG4gIG1haW5UaHJlYWRGbHVzaExvb3BPbkZsdXNoTWljcm90YXNrLFxuICBtYWluVGhyZWFkRmx1c2hMb29wUmVwb3J0LFxufSBmcm9tICcuLi91dGlscy9tYWluVGhyZWFkRmx1c2hMb29wR3VhcmQuanMnO1xuaW1wb3J0IHsgaXNTZGtWZXJzaW9uR3QgfSBmcm9tICcuLi91dGlscy92ZXJzaW9uLmpzJztcblxubGV0IHdpbGxGbHVzaCA9IGZhbHNlO1xubGV0IHNob3VsZEZsdXNoID0gdHJ1ZTtcblxuZXhwb3J0IGZ1bmN0aW9uIHNldFNob3VsZEZsdXNoKHZhbHVlOiBib29sZWFuKTogdm9pZCB7XG4gIHNob3VsZEZsdXNoID0gdmFsdWU7XG59XG5cbmV4cG9ydCBjbGFzcyBFbGVtZW50IHtcbiAgLy8gQHRzLWV4cGVjdC1lcnJvciBzZXQgaW4gY29uc3RydWN0b3JcbiAgcHJpdmF0ZSByZWFkb25seSBlbGVtZW50OiBFbGVtZW50Tm9kZTtcblxuICBjb25zdHJ1Y3RvcihlbGVtZW50OiBFbGVtZW50Tm9kZSkge1xuICAgIC8vIEluIEx5bnggdmVyc2lvbnMgcHJpb3IgdG8gYW5kIGluY2x1ZGluZyAyLjE1LFxuICAgIC8vIGEgY3Jhc2ggb2NjdXJzIHdoZW4gcHJpbnRpbmcgb3IgdHJhbnNmZXJyaW5nIHJlZkNvdW50ZWQgYWNyb3NzIHRocmVhZHMuXG4gICAgLy8gQnlwYXNzIHRoaXMgcHJvYmxlbSBieSBoaWRpbmcgdGhlIGVsZW1lbnQgb2JqZWN0LlxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCAnZWxlbWVudCcsIHtcbiAgICAgIGdldCgpIHtcbiAgICAgICAgcmV0dXJuIGVsZW1lbnQ7XG4gICAgICB9LFxuICAgIH0pO1xuICB9XG5cbiAgcHVibGljIHNldEF0dHJpYnV0ZShuYW1lOiBzdHJpbmcsIHZhbHVlOiB1bmtub3duKTogdm9pZCB7XG4gICAgLyogdjggaWdub3JlIG5leHQgMyAqL1xuICAgIGlmIChfX0RFVl9fKSB7XG4gICAgICBtYWluVGhyZWFkRmx1c2hMb29wTWFyayhgZWxlbWVudDpzZXRBdHRyaWJ1dGUgJHtuYW1lfWApO1xuICAgIH1cbiAgICBfX1NldEF0dHJpYnV0ZSh0aGlzLmVsZW1lbnQsIG5hbWUsIHZhbHVlKTtcbiAgICB0aGlzLmZsdXNoRWxlbWVudFRyZWUoKTtcbiAgfVxuXG4gIHB1YmxpYyBzZXRTdHlsZVByb3BlcnR5KG5hbWU6IHN0cmluZywgdmFsdWU6IHN0cmluZyk6IHZvaWQge1xuICAgIC8qIHY4IGlnbm9yZSBuZXh0IDMgKi9cbiAgICBpZiAoX19ERVZfXykge1xuICAgICAgbWFpblRocmVhZEZsdXNoTG9vcE1hcmsoYGVsZW1lbnQ6c2V0U3R5bGVQcm9wZXJ0eSAke25hbWV9YCk7XG4gICAgfVxuICAgIF9fQWRkSW5saW5lU3R5bGUodGhpcy5lbGVtZW50LCBuYW1lLCB2YWx1ZSk7XG4gICAgdGhpcy5mbHVzaEVsZW1lbnRUcmVlKCk7XG4gIH1cblxuICBwdWJsaWMgc2V0U3R5bGVQcm9wZXJ0aWVzKHN0eWxlczogUmVjb3JkPHN0cmluZywgc3RyaW5nPik6IHZvaWQge1xuICAgIC8qIHY4IGlnbm9yZSBuZXh0IDUgKi9cbiAgICBpZiAoX19ERVZfXykge1xuICAgICAgbWFpblRocmVhZEZsdXNoTG9vcE1hcmsoXG4gICAgICAgIGBlbGVtZW50OnNldFN0eWxlUHJvcGVydGllcyBrZXlzPSR7T2JqZWN0LmtleXMoc3R5bGVzKS5sZW5ndGh9YCxcbiAgICAgICk7XG4gICAgfVxuICAgIGZvciAoY29uc3Qga2V5IGluIHN0eWxlcykge1xuICAgICAgX19BZGRJbmxpbmVTdHlsZSh0aGlzLmVsZW1lbnQsIGtleSwgc3R5bGVzW2tleV0hKTtcbiAgICB9XG4gICAgdGhpcy5mbHVzaEVsZW1lbnRUcmVlKCk7XG4gIH1cblxuICBwdWJsaWMgZ2V0QXR0cmlidXRlKGF0dHJpYnV0ZU5hbWU6IHN0cmluZyk6IHVua25vd24ge1xuICAgIHJldHVybiBfX0dldEF0dHJpYnV0ZUJ5TmFtZSh0aGlzLmVsZW1lbnQsIGF0dHJpYnV0ZU5hbWUpO1xuICB9XG5cbiAgcHVibGljIGdldEF0dHJpYnV0ZU5hbWVzKCk6IHN0cmluZ1tdIHtcbiAgICByZXR1cm4gX19HZXRBdHRyaWJ1dGVOYW1lcyh0aGlzLmVsZW1lbnQpO1xuICB9XG5cbiAgcHVibGljIHF1ZXJ5U2VsZWN0b3Ioc2VsZWN0b3I6IHN0cmluZyk6IEVsZW1lbnQgfCBudWxsIHtcbiAgICBjb25zdCByZWYgPSBfX1F1ZXJ5U2VsZWN0b3IodGhpcy5lbGVtZW50LCBzZWxlY3Rvciwge30pO1xuICAgIHJldHVybiByZWYgPyBuZXcgRWxlbWVudChyZWYpIDogbnVsbDtcbiAgfVxuXG4gIHB1YmxpYyBxdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9yOiBzdHJpbmcpOiBFbGVtZW50W10ge1xuICAgIHJldHVybiBfX1F1ZXJ5U2VsZWN0b3JBbGwodGhpcy5lbGVtZW50LCBzZWxlY3Rvciwge30pLm1hcCgoZWxlbWVudCkgPT4ge1xuICAgICAgcmV0dXJuIG5ldyBFbGVtZW50KGVsZW1lbnQpO1xuICAgIH0pO1xuICB9XG5cbiAgcHVibGljIGdldENvbXB1dGVkU3R5bGVQcm9wZXJ0eShrZXk6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgaWYgKCFpc1Nka1ZlcnNpb25HdCgzLCA0KSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAnZ2V0Q29tcHV0ZWRTdHlsZVByb3BlcnR5IHJlcXVpcmVzIEx5bnggc2RrIHZlcnNpb24gMy41JyxcbiAgICAgICk7XG4gICAgfVxuXG4gICAgaWYgKCFrZXkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignZ2V0Q29tcHV0ZWRTdHlsZVByb3BlcnR5OiBrZXkgaXMgcmVxdWlyZWQnKTtcbiAgICB9XG4gICAgcmV0dXJuIF9fR2V0Q29tcHV0ZWRTdHlsZUJ5S2V5KHRoaXMuZWxlbWVudCwga2V5KTtcbiAgfVxuXG4gIHB1YmxpYyBhbmltYXRlKFxuICAgIGtleWZyYW1lczogUmVjb3JkPHN0cmluZywgbnVtYmVyIHwgc3RyaW5nPltdLFxuICAgIG9wdGlvbnM/OiBudW1iZXIgfCBSZWNvcmQ8c3RyaW5nLCBudW1iZXIgfCBzdHJpbmc+LFxuICApOiBBbmltYXRpb24ge1xuICAgIGNvbnN0IG5vcm1hbGl6ZWRPcHRpb25zID0gdHlwZW9mIG9wdGlvbnMgPT09ICdudW1iZXInID8geyBkdXJhdGlvbjogb3B0aW9ucyB9IDogb3B0aW9ucyA/PyB7fTtcbiAgICByZXR1cm4gbmV3IEFuaW1hdGlvbihuZXcgS2V5ZnJhbWVFZmZlY3QodGhpcywga2V5ZnJhbWVzLCBub3JtYWxpemVkT3B0aW9ucykpO1xuICB9XG5cbiAgcHVibGljIGludm9rZShcbiAgICBtZXRob2ROYW1lOiBzdHJpbmcsXG4gICAgcGFyYW1zPzogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXG4gICk6IFByb21pc2U8dW5rbm93bj4ge1xuICAgIC8qIHY4IGlnbm9yZSBuZXh0IDMgKi9cbiAgICBpZiAoX19ERVZfXykge1xuICAgICAgbWFpblRocmVhZEZsdXNoTG9vcE1hcmsoYGVsZW1lbnQ6aW52b2tlICR7bWV0aG9kTmFtZX1gKTtcbiAgICB9XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIF9fSW52b2tlVUlNZXRob2QoXG4gICAgICAgIHRoaXMuZWxlbWVudCxcbiAgICAgICAgbWV0aG9kTmFtZSxcbiAgICAgICAgcGFyYW1zID8/IHt9LFxuICAgICAgICAocmVzOiB7IGNvZGU6IG51bWJlcjsgZGF0YTogdW5rbm93biB9KSA9PiB7XG4gICAgICAgICAgaWYgKHJlcy5jb2RlID09PSAwKSB7XG4gICAgICAgICAgICByZXNvbHZlKHJlcy5kYXRhKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcignVUkgbWV0aG9kIGludm9rZTogJyArIEpTT04uc3RyaW5naWZ5KHJlcykpKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICApO1xuICAgICAgdGhpcy5mbHVzaEVsZW1lbnRUcmVlKCk7XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGZsdXNoRWxlbWVudFRyZWUoKSB7XG4gICAgaWYgKHdpbGxGbHVzaCB8fCAhc2hvdWxkRmx1c2gpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgd2lsbEZsdXNoID0gdHJ1ZTtcbiAgICB2b2lkIFByb21pc2UucmVzb2x2ZSgpLnRoZW4oKCkgPT4ge1xuICAgICAgd2lsbEZsdXNoID0gZmFsc2U7XG4gICAgICBpZiAoX19ERVZfXykge1xuICAgICAgICBtYWluVGhyZWFkRmx1c2hMb29wTWFyaygncmVuZGVyJyk7XG4gICAgICAgIGNvbnN0IGVycm9yID0gbWFpblRocmVhZEZsdXNoTG9vcE9uRmx1c2hNaWNyb3Rhc2soKTtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgLy8gU3RvcCBzY2hlZHVsaW5nIGZ1cnRoZXIgZmx1c2hlcyBzbyB3ZSBjYW4gc3VyZmFjZSB0aGUgZXJyb3IuXG4gICAgICAgICAgLy8gVGhpcyBpcyBERVYtb25seSBiZWhhdmlvciBndWFyZGVkIGludGVybmFsbHkgYnkgdGhlIGRldiBndWFyZC5cbiAgICAgICAgICBzaG91bGRGbHVzaCA9IGZhbHNlO1xuICAgICAgICAgIG1haW5UaHJlYWRGbHVzaExvb3BSZXBvcnQoZXJyb3IpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgX19GbHVzaEVsZW1lbnRUcmVlKCk7XG4gICAgfSk7XG4gIH1cbn1cbiIsIi8vIENvcHlyaWdodCAyMDI0IFRoZSBMeW54IEF1dGhvcnMuIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4vLyBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UgVmVyc2lvbiAyLjAgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlXG4vLyBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3QgZGlyZWN0b3J5IG9mIHRoaXMgc291cmNlIHRyZWUuXG5pbXBvcnQgeyBFbGVtZW50IH0gZnJvbSAnLi9lbGVtZW50LmpzJztcblxuY2xhc3MgUGFnZUVsZW1lbnQge1xuICBwcml2YXRlIHN0YXRpYyBwYWdlRWxlbWVudDogRWxlbWVudE5vZGUgfCB1bmRlZmluZWQ7XG5cbiAgc3RhdGljIGdldCgpIHtcbiAgICBQYWdlRWxlbWVudC5wYWdlRWxlbWVudCA/Pz0gX19HZXRQYWdlRWxlbWVudCgpO1xuICAgIHJldHVybiBQYWdlRWxlbWVudC5wYWdlRWxlbWVudDtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcXVlcnlTZWxlY3Rvcihjc3NTZWxlY3Rvcjogc3RyaW5nKTogRWxlbWVudCB8IG51bGwge1xuICBjb25zdCBwYWdlRWxlbWVudCA9IFBhZ2VFbGVtZW50LmdldCgpO1xuICBpZiAoIXBhZ2VFbGVtZW50KSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3QgZWxlbWVudCA9IF9fUXVlcnlTZWxlY3RvcihwYWdlRWxlbWVudCwgY3NzU2VsZWN0b3IsIHt9KTtcbiAgcmV0dXJuIGVsZW1lbnQgPyBuZXcgRWxlbWVudChlbGVtZW50KSA6IG51bGw7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBxdWVyeVNlbGVjdG9yQWxsKGNzc1NlbGVjdG9yOiBzdHJpbmcpOiBFbGVtZW50W10ge1xuICBjb25zdCBwYWdlRWxlbWVudCA9IFBhZ2VFbGVtZW50LmdldCgpO1xuICBpZiAoIXBhZ2VFbGVtZW50KSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIHJldHVybiBfX1F1ZXJ5U2VsZWN0b3JBbGwocGFnZUVsZW1lbnQsIGNzc1NlbGVjdG9yLCB7fSkubWFwKFxuICAgIChlbGVtZW50KSA9PiB7XG4gICAgICByZXR1cm4gbmV3IEVsZW1lbnQoZWxlbWVudCk7XG4gICAgfSxcbiAgKTtcbn1cbiIsIi8vIENvcHlyaWdodCAyMDI0IFRoZSBMeW54IEF1dGhvcnMuIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4vLyBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UgVmVyc2lvbiAyLjAgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlXG4vLyBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3QgZGlyZWN0b3J5IG9mIHRoaXMgc291cmNlIHRyZWUuXG5pbXBvcnQgeyBxdWVyeVNlbGVjdG9yLCBxdWVyeVNlbGVjdG9yQWxsIH0gZnJvbSAnLi9sZXB1c1F1ZXJ5U2VsZWN0b3IuanMnO1xuaW1wb3J0IHsgaXNTZGtWZXJzaW9uR3QgfSBmcm9tICcuLi91dGlscy92ZXJzaW9uLmpzJztcblxuZnVuY3Rpb24gaW5pdEFwaUVudigpOiB2b2lkIHtcbiAgLy8gQHRzLWV4cGVjdC1lcnJvciB0eXBlXG4gIGx5bngucXVlcnlTZWxlY3RvciA9IHF1ZXJ5U2VsZWN0b3I7XG4gIC8vIEB0cy1leHBlY3QtZXJyb3IgdHlwZVxuICBseW54LnF1ZXJ5U2VsZWN0b3JBbGwgPSBxdWVyeVNlbGVjdG9yQWxsO1xuICAvLyBAdHMtZXhwZWN0LWVycm9yIHR5cGVcbiAgZ2xvYmFsVGhpcy5zZXRUaW1lb3V0ID0gbHlueC5zZXRUaW1lb3V0IGFzIChjYjogKCkgPT4gdm9pZCwgdGltZW91dDogbnVtYmVyKSA9PiBudW1iZXI7XG4gIC8vIEB0cy1leHBlY3QtZXJyb3IgdHlwZVxuICBnbG9iYWxUaGlzLnNldEludGVydmFsID0gbHlueC5zZXRJbnRlcnZhbCBhcyAoY2I6ICgpID0+IHZvaWQsIHRpbWVvdXQ6IG51bWJlcikgPT4gbnVtYmVyO1xuICAvLyBAdHMtZXhwZWN0LWVycm9yIHR5cGVcbiAgZ2xvYmFsVGhpcy5jbGVhclRpbWVvdXQgPSBseW54LmNsZWFyVGltZW91dCBhcyAodGltZW91dDogbnVtYmVyKSA9PiB2b2lkO1xuICAvLyBJbiBseW54IDIuMTQgYGNsZWFySW50ZXJ2YWxgIGlzIG1pc3Rha2VubHkgc3BlbGxlZCBhcyBgY2xlYXJUaW1lSW50ZXJ2YWxgLiBUaGlzIGlzIGZpeGVkIGluIGx5bnggMi4xNS5cbiAgLy8gQHRzLWV4cGVjdC1lcnJvciB0eXBlXG4gIGdsb2JhbFRoaXMuY2xlYXJJbnRlcnZhbCA9IChseW54LmNsZWFySW50ZXJ2YWwgPz8gbHlueC5jbGVhclRpbWVJbnRlcnZhbCkgYXMgKHRpbWVvdXQ6IG51bWJlcikgPT4gdm9pZDtcblxuICB7XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciB0eXBlXG4gICAgY29uc3QgcmVxdWVzdEFuaW1hdGlvbkZyYW1lID0gbHlueC5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUgYXMgKGNhbGxiYWNrOiAoKSA9PiB2b2lkKSA9PiBudW1iZXI7XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciB0eXBlXG4gICAgbHlueC5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUgPSBnbG9iYWxUaGlzLnJlcXVlc3RBbmltYXRpb25GcmFtZSA9IChcbiAgICAgIGNhbGxiYWNrOiAoKSA9PiB2b2lkLFxuICAgICkgPT4ge1xuICAgICAgaWYgKCFpc1Nka1ZlcnNpb25HdCgyLCAxNSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICdyZXF1ZXN0QW5pbWF0aW9uRnJhbWUgaW4gbWFpbiB0aHJlYWQgc2NyaXB0IHJlcXVpcmVzIEx5bnggc2RrIHZlcnNpb24gMi4xNicsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKGNhbGxiYWNrKTtcbiAgICB9O1xuICB9XG5cbiAgLy8gQHRzLWV4cGVjdC1lcnJvciB0eXBlXG4gIGdsb2JhbFRoaXMuY2FuY2VsQW5pbWF0aW9uRnJhbWUgPSBseW54LmNhbmNlbEFuaW1hdGlvbkZyYW1lIGFzIChyZXF1ZXN0SWQ6IG51bWJlcikgPT4gdm9pZDtcbn1cblxuZXhwb3J0IHsgaW5pdEFwaUVudiB9O1xuIiwiLy8gQ29weXJpZ2h0IDIwMjUgVGhlIEx5bnggQXV0aG9ycy4gQWxsIHJpZ2h0cyByZXNlcnZlZC5cbi8vIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSBWZXJzaW9uIDIuMCB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGVcbi8vIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbmltcG9ydCB7IFdvcmtsZXRFdmVudHMgfSBmcm9tICcuL2JpbmRpbmdzL2luZGV4LmpzJztcbmltcG9ydCB0eXBlIHsgQ2xvc3VyZVZhbHVlVHlwZSwgUnVuV29ya2xldEN0eFJldERhdGEsIFdvcmtsZXQgfSBmcm9tICcuL2JpbmRpbmdzL2luZGV4LmpzJztcblxuZXhwb3J0IGZ1bmN0aW9uIHJ1blJ1bk9uTWFpblRocmVhZFRhc2sodGFzazogV29ya2xldCwgcGFyYW1zOiBDbG9zdXJlVmFsdWVUeXBlW10sIHJlc29sdmVJZDogbnVtYmVyKTogdm9pZCB7XG4gIGxldCByZXR1cm5WYWx1ZTtcbiAgdHJ5IHtcbiAgICByZXR1cm5WYWx1ZSA9IHJ1bldvcmtsZXQodGFzaywgcGFyYW1zKTtcbiAgfSBmaW5hbGx5IHtcbiAgICAvLyBUT0RPOiBTaG91bGQgYmUgbW9yZSBwcm9wZXIgdG8gcmVqZWN0IHRoZSBwcm9taXNlIGlmIHRoZXJlIGlzIGFuIGVycm9yLlxuICAgIGx5bnguZ2V0SlNDb250ZXh0KCkuZGlzcGF0Y2hFdmVudCh7XG4gICAgICB0eXBlOiBXb3JrbGV0RXZlbnRzLkZ1bmN0aW9uQ2FsbFJldCxcbiAgICAgIGRhdGE6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgcmVzb2x2ZUlkLFxuICAgICAgICByZXR1cm5WYWx1ZSxcbiAgICAgIH0gYXMgUnVuV29ya2xldEN0eFJldERhdGEpLFxuICAgIH0pO1xuICB9XG59XG4iLCIvLyBDb3B5cmlnaHQgMjAyNCBUaGUgTHlueCBBdXRob3JzLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuLy8gTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlIFZlcnNpb24gMi4wIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZVxuLy8gTElDRU5TRSBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuaW1wb3J0IHR5cGUgeyBXb3JrbGV0LCBXb3JrbGV0UmVmSW1wbCB9IGZyb20gJy4vYmluZGluZ3MvdHlwZXMuanMnO1xuXG50eXBlIE1haW5UaHJlYWRPYmplY3RGYWN0b3J5ID0gKGluaXRpYWxWYWx1ZTogdW5rbm93bikgPT4gb2JqZWN0O1xuaW50ZXJmYWNlIE1haW5UaHJlYWRPYmplY3REZWZpbml0aW9uIHtcbiAgY3JlYXRlOiBNYWluVGhyZWFkT2JqZWN0RmFjdG9yeSB8IFdvcmtsZXQ7XG4gIHJlc29sdmVkQ3JlYXRlPzogTWFpblRocmVhZE9iamVjdEZhY3Rvcnk7XG59XG5cbmNvbnN0IG1haW5UaHJlYWRPYmplY3REZWZpbml0aW9ucyA9IG5ldyBNYXA8c3RyaW5nLCBNYWluVGhyZWFkT2JqZWN0RGVmaW5pdGlvbj4oKTtcbi8vIFRoZSBicmFuZCBiZWxvbmdzIHRvIHRoZSB0YXJnZXQsIG5vdCBhbiBpbmRpdmlkdWFsIGhhbmRsZS4gT3RoZXIgaGFuZGxlcyBvclxuLy8gY2FwdHVyZWQgY29udGV4dHMgbWF5IHN0aWxsIG93biB0aGUgdGFyZ2V0IGFmdGVyIG9uZSByZWYtbWFwIGVudHJ5IGlzIHJlbW92ZWQuXG5sZXQgcmVhbGl6ZWRNYWluVGhyZWFkT2JqZWN0VHlwZXMgPSBuZXcgV2Vha01hcDxvYmplY3QsIHN0cmluZz4oKTtcblxuZnVuY3Rpb24gcmVnaXN0ZXJNYWluVGhyZWFkT2JqZWN0VHlwZShcbiAgdHlwZTogc3RyaW5nLFxuICBjcmVhdGU6IE1haW5UaHJlYWRPYmplY3RGYWN0b3J5IHwgV29ya2xldCxcbik6IHZvaWQge1xuICBpZiAodHlwZSA9PT0gJ21haW4tdGhyZWFkJykge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICdNYWluVGhyZWFkT2JqZWN0IHR5cGUgXCJtYWluLXRocmVhZFwiIGlzIHJlc2VydmVkIGZvciBNYWluVGhyZWFkUmVmLicsXG4gICAgKTtcbiAgfVxuICBjb25zdCByZWdpc3RlcmVkID0gbWFpblRocmVhZE9iamVjdERlZmluaXRpb25zLmdldCh0eXBlKTtcbiAgaWYgKHJlZ2lzdGVyZWQpIHtcbiAgICBpZiAoXG4gICAgICBnZXRGYWN0b3J5UmVnaXN0cmF0aW9uSWRlbnRpdHkocmVnaXN0ZXJlZC5jcmVhdGUpXG4gICAgICAgICE9PSBnZXRGYWN0b3J5UmVnaXN0cmF0aW9uSWRlbnRpdHkoY3JlYXRlKVxuICAgICkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgQ29uZmxpY3RpbmcgTWFpblRocmVhZE9iamVjdCByZWdpc3RyYXRpb24gZm9yIHR5cGUgXCIke3R5cGV9XCIuIEEgdHlwZSBrZXkgbXVzdCBhbHdheXMgdXNlIHRoZSBzYW1lIGNyZWF0ZSBmdW5jdGlvbi5gLFxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuO1xuICB9XG4gIG1haW5UaHJlYWRPYmplY3REZWZpbml0aW9ucy5zZXQodHlwZSwgeyBjcmVhdGUgfSk7XG59XG5cbmZ1bmN0aW9uIGdldEZhY3RvcnlSZWdpc3RyYXRpb25JZGVudGl0eShcbiAgZmFjdG9yeTogTWFpblRocmVhZE9iamVjdEZhY3RvcnkgfCBXb3JrbGV0LFxuKTogc3RyaW5nIHtcbiAgaWYgKHR5cGVvZiBmYWN0b3J5ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgcmV0dXJuIEZ1bmN0aW9uLnByb3RvdHlwZS50b1N0cmluZy5jYWxsKGZhY3RvcnkpO1xuICB9XG4gIHJldHVybiBgd29ya2xldDoke2ZhY3RvcnkuX3drbHRJZH1gO1xufVxuXG5mdW5jdGlvbiByZXNvbHZlRmFjdG9yeUZ1bmN0aW9uKFxuICBmYWN0b3J5OiBNYWluVGhyZWFkT2JqZWN0RmFjdG9yeSB8IFdvcmtsZXQsXG4pOiBNYWluVGhyZWFkT2JqZWN0RmFjdG9yeSB7XG4gIGlmICh0eXBlb2YgZmFjdG9yeSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIHJldHVybiBmYWN0b3J5O1xuICB9XG4gIGlmICghKCdfd2tsdElkJyBpbiBmYWN0b3J5KSB8fCAnX2xlcHVzV29ya2xldEhhc2gnIGluIGZhY3RvcnkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCByZXNvbHZlIGFuIGludmFsaWQgTWFpbiBUaHJlYWQgRnVuY3Rpb24uJyk7XG4gIH1cbiAgLy8gRmFjdG9yaWVzIGFyZSBjYXB0dXJlLWZyZWUsIHNvIHRoZXkgbmVlZCBuZWl0aGVyIGNvbnRleHQgdHJhdmVyc2FsIG5vciBiaW5kaW5nLlxuICAvLyBSZXNvbHZlIG9uIGZpcnN0IHVzZTogdGhlIGNvbXBpbGVyIHJlZ2lzdGVycyB3b3JrbGV0cyBhZnRlciBtb2R1bGUgZXZhbHVhdGlvbi5cbiAgcmV0dXJuIGx5bnhXb3JrbGV0SW1wbC5fd29ya2xldE1hcFtmYWN0b3J5Ll93a2x0SWRdIGFzIE1haW5UaHJlYWRPYmplY3RGYWN0b3J5O1xufVxuXG5mdW5jdGlvbiBnZXRNYWluVGhyZWFkT2JqZWN0RmFjdG9yeShcbiAgZGVmaW5pdGlvbjogTWFpblRocmVhZE9iamVjdERlZmluaXRpb24sXG4pOiBNYWluVGhyZWFkT2JqZWN0RmFjdG9yeSB7XG4gIHJldHVybiBkZWZpbml0aW9uLnJlc29sdmVkQ3JlYXRlID8/PSByZXNvbHZlRmFjdG9yeUZ1bmN0aW9uKGRlZmluaXRpb24uY3JlYXRlKTtcbn1cblxuZnVuY3Rpb24gY3JlYXRlTWFpblRocmVhZE9iamVjdChyZWZJbXBsOiBXb3JrbGV0UmVmSW1wbDx1bmtub3duPik6IG9iamVjdCB7XG4gIGNvbnN0IHR5cGUgPSByZWZJbXBsLl90eXBlITtcbiAgY29uc3QgZGVmaW5pdGlvbiA9IG1haW5UaHJlYWRPYmplY3REZWZpbml0aW9ucy5nZXQodHlwZSk7XG4gIGlmICghZGVmaW5pdGlvbikge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgIGBNYWluVGhyZWFkT2JqZWN0IHR5cGUgaXMgbm90IHJlZ2lzdGVyZWQ6IFwiJHt0eXBlfVwiLiBEZWZpbmUgdGhlIHR5cGUgaW4gYSBtb2R1bGUgZXZhbHVhdGVkIG9uIHRoZSBtYWluIHRocmVhZCBiZWZvcmUgaW5pdGlhbGl6aW5nIGl0cyBoYW5kbGUuYCxcbiAgICApO1xuICB9XG5cbiAgY29uc3QgdmFsdWUgPSBnZXRNYWluVGhyZWFkT2JqZWN0RmFjdG9yeShkZWZpbml0aW9uKShyZWZJbXBsLl9pbml0VmFsdWUpO1xuICBpZiAodHlwZW9mIHZhbHVlICE9PSAnb2JqZWN0JyB8fCB2YWx1ZSA9PT0gbnVsbCkge1xuICAgIHRocm93IG5ldyBFcnJvcihgTWFpblRocmVhZE9iamVjdCB0eXBlIFwiJHt0eXBlfVwiIGNyZWF0ZWQgYSBub24tb2JqZWN0IHZhbHVlLmApO1xuICB9XG4gIHJlYWxpemVkTWFpblRocmVhZE9iamVjdFR5cGVzLnNldCh2YWx1ZSwgdHlwZSk7XG4gIHJldHVybiB2YWx1ZTtcbn1cblxuZnVuY3Rpb24gaXNSZWFsaXplZE1haW5UaHJlYWRPYmplY3QodmFsdWU6IG9iamVjdCk6IGJvb2xlYW4ge1xuICByZXR1cm4gcmVhbGl6ZWRNYWluVGhyZWFkT2JqZWN0VHlwZXMuaGFzKHZhbHVlKTtcbn1cblxuZnVuY3Rpb24gYXNzZXJ0Q29tcGF0aWJsZU1haW5UaHJlYWRPYmplY3QoXG4gIGhhbmRsZTogV29ya2xldFJlZkltcGw8dW5rbm93bj4sXG4gIHZhbHVlOiBvYmplY3QsXG4gIG9wZXJhdGlvbjogJ2h5ZHJhdGlvbicgfCAnaW5pdGlhbGl6YXRpb24gcGF0Y2gnLFxuKTogdm9pZCB7XG4gIGNvbnN0IGFjdHVhbFR5cGUgPSByZWFsaXplZE1haW5UaHJlYWRPYmplY3RUeXBlcy5nZXQodmFsdWUpO1xuICBjb25zdCBleHBlY3RlZFR5cGUgPSBoYW5kbGUuX3R5cGUhO1xuICBpZiAoYWN0dWFsVHlwZSAhPT0gZXhwZWN0ZWRUeXBlKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgYE1haW5UaHJlYWRPYmplY3QgdHlwZSBtaXNtYXRjaCBkdXJpbmcgJHtvcGVyYXRpb259IGZvciBoYW5kbGUgJHtoYW5kbGUuX3d2aWR9OiBiYWNrZ3JvdW5kIGhhbmRsZSBleHBlY3RzIHR5cGUgXCIke2V4cGVjdGVkVHlwZX1cIiwgYnV0IHRoZSBtYWluLXRocmVhZCB0YXJnZXQgaXMgdHlwZSBcIiR7YWN0dWFsVHlwZX1cIi5gLFxuICAgICk7XG4gIH1cbn1cblxuZnVuY3Rpb24gaW5pdE1haW5UaHJlYWRPYmplY3RzKCk6IHZvaWQge1xuICBtYWluVGhyZWFkT2JqZWN0RGVmaW5pdGlvbnMuY2xlYXIoKTtcbiAgcmVhbGl6ZWRNYWluVGhyZWFkT2JqZWN0VHlwZXMgPSBuZXcgV2Vha01hcCgpO1xufVxuXG5leHBvcnQge1xuICB0eXBlIE1haW5UaHJlYWRPYmplY3RGYWN0b3J5LFxuICBpbml0TWFpblRocmVhZE9iamVjdHMsXG4gIHJlZ2lzdGVyTWFpblRocmVhZE9iamVjdFR5cGUsXG4gIGNyZWF0ZU1haW5UaHJlYWRPYmplY3QsXG4gIGFzc2VydENvbXBhdGlibGVNYWluVGhyZWFkT2JqZWN0LFxuICBpc1JlYWxpemVkTWFpblRocmVhZE9iamVjdCxcbn07XG4iLCIvLyBDb3B5cmlnaHQgMjAyNCBUaGUgTHlueCBBdXRob3JzLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuLy8gTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlIFZlcnNpb24gMi4wIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZVxuLy8gTElDRU5TRSBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuZXhwb3J0IGZ1bmN0aW9uIHByb2ZpbGU8UmV0LCBGbiBleHRlbmRzICguLi5hcmdzOiB1bmtub3duW10pID0+IFJldD4oXG4gIHNsaWNlTmFtZTogc3RyaW5nLFxuICBmOiBGbixcbik6IFJldCB7XG4gIC8qIHY4IGlnbm9yZSBuZXh0IDkgKi9cbiAgLy8gVE9ETzogY2hhbmdlIGl0IHRvIF9fUFJPRklMRV9fXG4gIGlmIChfX0RFVl9fKSB7XG4gICAgY29uc29sZS5wcm9maWxlPy4oc2xpY2VOYW1lKTtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIGYoKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgY29uc29sZS5wcm9maWxlRW5kPy4oKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIGYoKTtcbiAgfVxufVxuIiwiLy8gQ29weXJpZ2h0IDIwMjQgVGhlIEx5bnggQXV0aG9ycy4gQWxsIHJpZ2h0cyByZXNlcnZlZC5cbi8vIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSBWZXJzaW9uIDIuMCB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGVcbi8vIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbmltcG9ydCB7IEVsZW1lbnQgfSBmcm9tICcuL2FwaS9lbGVtZW50LmpzJztcbmltcG9ydCB0eXBlIHtcbiAgTWFpblRocmVhZFJlZkluaXRWYWx1ZVBhdGNoLFxuICBXb3JrbGV0LFxuICBXb3JrbGV0UmVmLFxuICBXb3JrbGV0UmVmSWQsXG4gIFdvcmtsZXRSZWZJbXBsLFxufSBmcm9tICcuL2JpbmRpbmdzL3R5cGVzLmpzJztcbmltcG9ydCB7XG4gIGFzc2VydENvbXBhdGlibGVNYWluVGhyZWFkT2JqZWN0LFxuICBjcmVhdGVNYWluVGhyZWFkT2JqZWN0LFxuICBpbml0TWFpblRocmVhZE9iamVjdHMsXG4gIGlzUmVhbGl6ZWRNYWluVGhyZWFkT2JqZWN0LFxuICByZWdpc3Rlck1haW5UaHJlYWRPYmplY3RUeXBlLFxufSBmcm9tICcuL21haW5UaHJlYWRPYmplY3QuanMnO1xuaW1wb3J0IHR5cGUgeyBNYWluVGhyZWFkT2JqZWN0RmFjdG9yeSB9IGZyb20gJy4vbWFpblRocmVhZE9iamVjdC5qcyc7XG5pbXBvcnQgeyBtYWluVGhyZWFkRmx1c2hMb29wTWFyayB9IGZyb20gJy4vdXRpbHMvbWFpblRocmVhZEZsdXNoTG9vcEd1YXJkLmpzJztcbmltcG9ydCB7IHByb2ZpbGUgfSBmcm9tICcuL3V0aWxzL3Byb2ZpbGUuanMnO1xuXG5pbnRlcmZhY2UgUmVmSW1wbCB7XG4gIF93b3JrbGV0UmVmTWFwOiBSZWNvcmQ8V29ya2xldFJlZklkLCBvYmplY3Q+O1xuICBfZmlyc3RTY3JlZW5Xb3JrbGV0UmVmTWFwOiBSZWNvcmQ8V29ya2xldFJlZklkLCBvYmplY3Q+O1xuICB1cGRhdGVXb3JrbGV0UmVmKFxuICAgIHJlZkltcGw6IFdvcmtsZXRSZWZJbXBsPEVsZW1lbnQgfCBudWxsPixcbiAgICBlbGVtZW50OiBFbGVtZW50Tm9kZSB8IG51bGwsXG4gICk6IHZvaWQ7XG4gIHVwZGF0ZVdvcmtsZXRSZWZJbml0VmFsdWVDaGFuZ2VzKFxuICAgIHBhdGNoOiBNYWluVGhyZWFkUmVmSW5pdFZhbHVlUGF0Y2gsXG4gICk6IHZvaWQ7XG4gIHJlZ2lzdGVyTWFpblRocmVhZE9iamVjdFR5cGUoXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIGNyZWF0ZTogTWFpblRocmVhZE9iamVjdEZhY3RvcnkgfCBXb3JrbGV0LFxuICApOiB2b2lkO1xuICBjbGVhckZpcnN0U2NyZWVuV29ya2xldFJlZk1hcCgpOiB2b2lkO1xufVxuXG5sZXQgaW1wbDogUmVmSW1wbCB8IHVuZGVmaW5lZDtcbmZ1bmN0aW9uIGluaXRXb3JrbGV0UmVmKCk6IFJlZkltcGwge1xuICBpbml0TWFpblRocmVhZE9iamVjdHMoKTtcbiAgcmV0dXJuIChpbXBsID0ge1xuICAgIF93b3JrbGV0UmVmTWFwOiB7fSxcbiAgICAvKipcbiAgICAgKiBNYXAgb2Ygd29ya2xldCByZWZzIHRoYXQgYXJlIGNyZWF0ZWQgZHVyaW5nIGZpcnN0IHNjcmVlbiByZW5kZXJpbmcuXG4gICAgICogVGhlc2UgcmVmcyBhcmUgY3JlYXRlZCB3aXRoIG5lZ2F0aXZlIElEcyBhbmQgbmVlZCB0byBiZSBoeWRyYXRlZFxuICAgICAqIHdoZW4gdGhlIGFwcCBzdGFydHMuIFRoZSBtYXAgaXMgY2xlYXJlZCBhZnRlciBoeWRyYXRpb24gaXMgY29tcGxldGVcbiAgICAgKiB0byBmcmVlIHVwIG1lbW9yeS5cbiAgICAgKi9cbiAgICBfZmlyc3RTY3JlZW5Xb3JrbGV0UmVmTWFwOiB7fSxcbiAgICB1cGRhdGVXb3JrbGV0UmVmLFxuICAgIHVwZGF0ZVdvcmtsZXRSZWZJbml0VmFsdWVDaGFuZ2VzLFxuICAgIHJlZ2lzdGVyTWFpblRocmVhZE9iamVjdFR5cGUsXG4gICAgY2xlYXJGaXJzdFNjcmVlbldvcmtsZXRSZWZNYXAsXG4gIH0pO1xufVxuXG5jb25zdCBjcmVhdGVXb3JrbGV0UmVmID0gPFQ+KFxuICBpZDogV29ya2xldFJlZklkLFxuICB2YWx1ZTogVCxcbik6IFdvcmtsZXRSZWY8VD4gPT4ge1xuICBjb25zdCByZWYgPSB7XG4gICAgY3VycmVudDogdmFsdWUsXG4gICAgX3d2aWQ6IGlkLFxuICB9O1xuICByZXR1cm4gcmVmO1xufTtcblxuZnVuY3Rpb24gY3JlYXRlV29ya2xldFZhbHVlKHJlZkltcGw6IFdvcmtsZXRSZWZJbXBsPHVua25vd24+KTogb2JqZWN0IHtcbiAgcmV0dXJuICFyZWZJbXBsLl90eXBlIHx8IHJlZkltcGwuX3R5cGUgPT09ICdtYWluLXRocmVhZCdcbiAgICA/IGNyZWF0ZVdvcmtsZXRSZWYocmVmSW1wbC5fd3ZpZCwgcmVmSW1wbC5faW5pdFZhbHVlKVxuICAgIDogY3JlYXRlTWFpblRocmVhZE9iamVjdChyZWZJbXBsKTtcbn1cblxuZnVuY3Rpb24gaXNNdXRhYmxlQ2VsbCh2YWx1ZTogdW5rbm93bik6IHZhbHVlIGlzIFdvcmtsZXRSZWY8dW5rbm93bj4ge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAhPT0gbnVsbFxuICAgICYmIHR5cGVvZiAodmFsdWUgYXMgUGFydGlhbDxXb3JrbGV0UmVmPHVua25vd24+PikuX3d2aWQgPT09ICdudW1iZXInXG4gICAgJiYgT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHZhbHVlLCAnY3VycmVudCcpO1xufVxuXG5mdW5jdGlvbiBpc0h5ZHJhdGVkV29ya2xldFZhbHVlKHZhbHVlOiB1bmtub3duKTogdmFsdWUgaXMgb2JqZWN0IHtcbiAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgIT09IG51bGxcbiAgICAmJiAoaXNSZWFsaXplZE1haW5UaHJlYWRPYmplY3QodmFsdWUpIHx8IGlzTXV0YWJsZUNlbGwodmFsdWUpKTtcbn1cblxuZnVuY3Rpb24gYXNzZXJ0Q29tcGF0aWJsZVdvcmtsZXRWYWx1ZShcbiAgaGFuZGxlOiBXb3JrbGV0UmVmSW1wbDx1bmtub3duPixcbiAgdmFsdWU6IG9iamVjdCxcbiAgb3BlcmF0aW9uOiAnaHlkcmF0aW9uJyB8ICdpbml0aWFsaXphdGlvbiBwYXRjaCcsXG4pOiB2b2lkIHtcbiAgbGV0IGFjdHVhbEtpbmQ6ICd0eXBlZC1vYmplY3QnIHwgJ211dGFibGUtY2VsbCcgfCB1bmRlZmluZWQ7XG4gIGlmIChpc1JlYWxpemVkTWFpblRocmVhZE9iamVjdCh2YWx1ZSkpIHtcbiAgICBhY3R1YWxLaW5kID0gJ3R5cGVkLW9iamVjdCc7XG4gIH0gZWxzZSBpZiAoaXNNdXRhYmxlQ2VsbCh2YWx1ZSkpIHtcbiAgICBhY3R1YWxLaW5kID0gJ211dGFibGUtY2VsbCc7XG4gIH1cbiAgaWYgKCFhY3R1YWxLaW5kKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgYENhbm5vdCBhcHBseSBNYWluVGhyZWFkT2JqZWN0ICR7b3BlcmF0aW9ufSBmb3IgaGFuZGxlICR7aGFuZGxlLl93dmlkfTogdGhlIGV4aXN0aW5nIHRhcmdldCBoYXMgbm8gd29ya2xldC12YWx1ZSBtZXRhZGF0YS5gLFxuICAgICk7XG4gIH1cblxuICBjb25zdCBleHBlY3RlZFR5cGUgPSBoYW5kbGUuX3R5cGU7XG4gIGNvbnN0IGV4cGVjdGVkS2luZCA9ICFleHBlY3RlZFR5cGUgfHwgZXhwZWN0ZWRUeXBlID09PSAnbWFpbi10aHJlYWQnXG4gICAgPyAnbXV0YWJsZS1jZWxsJ1xuICAgIDogJ3R5cGVkLW9iamVjdCc7XG4gIGlmIChhY3R1YWxLaW5kICE9PSBleHBlY3RlZEtpbmQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICBgV29ya2xldCB2YWx1ZSBraW5kIG1pc21hdGNoIGR1cmluZyAke29wZXJhdGlvbn0gZm9yIGhhbmRsZSAke2hhbmRsZS5fd3ZpZH06IGJhY2tncm91bmQgaGFuZGxlIGV4cGVjdHMgJHtleHBlY3RlZEtpbmR9LCBidXQgdGhlIG1haW4tdGhyZWFkIHRhcmdldCBpcyAke2FjdHVhbEtpbmR9LmAsXG4gICAgKTtcbiAgfVxuICBpZiAoYWN0dWFsS2luZCA9PT0gJ3R5cGVkLW9iamVjdCcpIHtcbiAgICBhc3NlcnRDb21wYXRpYmxlTWFpblRocmVhZE9iamVjdChoYW5kbGUsIHZhbHVlLCBvcGVyYXRpb24pO1xuICB9XG59XG5cbmNvbnN0IGdldEZyb21Xb3JrbGV0UmVmTWFwID0gKFxuICByZWZJbXBsOiBXb3JrbGV0UmVmSW1wbDx1bmtub3duPixcbik6IG9iamVjdCB8IHVuZGVmaW5lZCA9PiB7XG4gIGNvbnN0IGlkID0gcmVmSW1wbC5fd3ZpZDtcbiAgLyogdjggaWdub3JlIG5leHQgMyAqL1xuICBpZiAoX19ERVZfXykge1xuICAgIG1haW5UaHJlYWRGbHVzaExvb3BNYXJrKGBNYWluVGhyZWFkUmVmOmdldCBpZD0ke2lkfWApO1xuICB9XG4gIGxldCB2YWx1ZTtcbiAgaWYgKGlkIDwgMCkge1xuICAgIC8vIEF0IHRoZSBmaXJzdCBzY3JlZW4gcmVuZGVyaW5nLCB0aGUgd29ya2xldCByZWYgaXMgY3JlYXRlZCB3aXRoIGEgbmVnYXRpdmUgSUQuXG4gICAgLy8gTWlnaHQgYmUgY2FsbGVkIGluIHR3byBzY2VuYXJpb3M6XG4gICAgLy8gMS4gSW4gTVRTIGV2ZW50c1xuICAgIC8vIDIuIEluIGBtYWluLXRocmVhZDpyZWZgXG4gICAgdmFsdWUgPSBpbXBsIS5fZmlyc3RTY3JlZW5Xb3JrbGV0UmVmTWFwW2lkXSA/Pz0gY3JlYXRlV29ya2xldFZhbHVlKHJlZkltcGwpO1xuICB9IGVsc2Uge1xuICAgIHZhbHVlID0gaW1wbCEuX3dvcmtsZXRSZWZNYXBbaWRdO1xuICB9XG5cbiAgLyogdjggaWdub3JlIG5leHQgMyAqL1xuICBpZiAoX19ERVZfXyAmJiB2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdNYWluVGhyZWFkUmVmIGlzIG5vdCBpbml0aWFsaXplZDogJyArIGlkKTtcbiAgfVxuICByZXR1cm4gdmFsdWU7XG59O1xuXG5mdW5jdGlvbiByZW1vdmVWYWx1ZUZyb21Xb3JrbGV0UmVmTWFwKGlkOiBXb3JrbGV0UmVmSWQpOiB2b2lkIHtcbiAgZGVsZXRlIGltcGwhLl93b3JrbGV0UmVmTWFwW2lkXTtcbn1cblxuZnVuY3Rpb24gaHlkcmF0ZVdvcmtsZXRWYWx1ZShcbiAgaGFuZGxlOiBXb3JrbGV0UmVmSW1wbDx1bmtub3duPixcbiAgdmFsdWU6IG9iamVjdCxcbik6IHZvaWQge1xuICBhc3NlcnRDb21wYXRpYmxlV29ya2xldFZhbHVlKGhhbmRsZSwgdmFsdWUsICdoeWRyYXRpb24nKTtcbiAgaW1wbCEuX3dvcmtsZXRSZWZNYXBbaGFuZGxlLl93dmlkXSA9IHZhbHVlO1xufVxuXG4vKipcbiAqIENyZWF0ZSBhbiBlbGVtZW50IGluc3RhbmNlIG9mIHRoZSBnaXZlbiBlbGVtZW50IG5vZGUsIHRoZW4gc2V0IHRoZSB3b3JrbGV0IHZhbHVlIHRvIGl0LlxuICogVGhpcyBpcyBjYWxsZWQgaW4gYHNuYXBzaG90Q29udGV4dFVwZGF0ZVdvcmtsZXRSZWZgLlxuICogQHBhcmFtIGhhbmRsZSBoYW5kbGUgb2YgdGhlIHdvcmtsZXQgdmFsdWUuXG4gKiBAcGFyYW0gZWxlbWVudCB0aGUgZWxlbWVudCBub2RlLlxuICovXG5mdW5jdGlvbiB1cGRhdGVXb3JrbGV0UmVmKFxuICBoYW5kbGU6IFdvcmtsZXRSZWZJbXBsPEVsZW1lbnQgfCBudWxsPixcbiAgZWxlbWVudDogRWxlbWVudE5vZGUgfCBudWxsLFxuKTogdm9pZCB7XG4gIChnZXRGcm9tV29ya2xldFJlZk1hcChoYW5kbGUpIGFzIFdvcmtsZXRSZWY8RWxlbWVudCB8IG51bGw+KS5jdXJyZW50ID0gZWxlbWVudFxuICAgID8gbmV3IEVsZW1lbnQoZWxlbWVudClcbiAgICA6IG51bGw7XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZVdvcmtsZXRSZWZJbml0VmFsdWVDaGFuZ2VzKFxuICBwYXRjaDogTWFpblRocmVhZFJlZkluaXRWYWx1ZVBhdGNoLFxuKTogdm9pZCB7XG4gIHByb2ZpbGUoJ3VwZGF0ZVdvcmtsZXRSZWZJbml0VmFsdWVDaGFuZ2VzJywgKCkgPT4ge1xuICAgIGxldCBmaXJzdEVycm9yOiB1bmtub3duO1xuICAgIGxldCBoYXNFcnJvciA9IGZhbHNlO1xuICAgIHBhdGNoLmZvckVhY2goKFtpZCwgdmFsdWUsIHR5cGVdKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBoYW5kbGUgPSB7XG4gICAgICAgICAgX3d2aWQ6IGlkLFxuICAgICAgICAgIF9pbml0VmFsdWU6IHZhbHVlLFxuICAgICAgICAgIF90eXBlOiB0eXBlLFxuICAgICAgICB9IGFzIFdvcmtsZXRSZWZJbXBsPHVua25vd24+O1xuICAgICAgICBjb25zdCBleGlzdGluZyA9IGltcGwhLl93b3JrbGV0UmVmTWFwW2lkXTtcbiAgICAgICAgaWYgKGV4aXN0aW5nKSB7XG4gICAgICAgICAgYXNzZXJ0Q29tcGF0aWJsZVdvcmtsZXRWYWx1ZShcbiAgICAgICAgICAgIGhhbmRsZSxcbiAgICAgICAgICAgIGV4aXN0aW5nLFxuICAgICAgICAgICAgJ2luaXRpYWxpemF0aW9uIHBhdGNoJyxcbiAgICAgICAgICApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGltcGwhLl93b3JrbGV0UmVmTWFwW2lkXSA9IGNyZWF0ZVdvcmtsZXRWYWx1ZShoYW5kbGUpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBpZiAoIWhhc0Vycm9yKSB7XG4gICAgICAgICAgZmlyc3RFcnJvciA9IGVycm9yO1xuICAgICAgICAgIGhhc0Vycm9yID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICAgIGlmIChoYXNFcnJvcikge1xuICAgICAgdGhyb3cgZmlyc3RFcnJvcjtcbiAgICB9XG4gIH0pO1xufVxuXG5mdW5jdGlvbiBjbGVhckZpcnN0U2NyZWVuV29ya2xldFJlZk1hcCgpOiB2b2lkIHtcbiAgaW1wbCEuX2ZpcnN0U2NyZWVuV29ya2xldFJlZk1hcCA9IHt9O1xufVxuXG5leHBvcnQge1xuICB0eXBlIFJlZkltcGwsXG4gIGNyZWF0ZVdvcmtsZXRSZWYsXG4gIGluaXRXb3JrbGV0UmVmLFxuICBnZXRGcm9tV29ya2xldFJlZk1hcCxcbiAgcmVtb3ZlVmFsdWVGcm9tV29ya2xldFJlZk1hcCxcbiAgaHlkcmF0ZVdvcmtsZXRWYWx1ZSxcbiAgaXNIeWRyYXRlZFdvcmtsZXRWYWx1ZSxcbiAgdXBkYXRlV29ya2xldFJlZkluaXRWYWx1ZUNoYW5nZXMsXG59O1xuIiwiLy8gQ29weXJpZ2h0IDIwMjQgVGhlIEx5bnggQXV0aG9ycy4gQWxsIHJpZ2h0cyByZXNlcnZlZC5cbi8vIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSBWZXJzaW9uIDIuMCB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGVcbi8vIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbmltcG9ydCB7IFdvcmtsZXRFdmVudHMgfSBmcm9tICcuL2JpbmRpbmdzL2V2ZW50cy5qcyc7XG5pbXBvcnQgdHlwZSB7IFJlbGVhc2VXb3JrbGV0UmVmRGF0YSwgUnVuV29ya2xldEN0eERhdGEgfSBmcm9tICcuL2JpbmRpbmdzL2V2ZW50cy5qcyc7XG5pbXBvcnQgdHlwZSB7IENsb3N1cmVWYWx1ZVR5cGUgfSBmcm9tICcuL2JpbmRpbmdzL3R5cGVzLmpzJztcbmltcG9ydCB7IHJ1blJ1bk9uTWFpblRocmVhZFRhc2sgfSBmcm9tICcuL3J1bk9uTWFpblRocmVhZC5qcyc7XG5pbXBvcnQgdHlwZSB7IEV2ZW50IH0gZnJvbSAnLi90eXBlcy9ydW50aW1lUHJveHkuanMnO1xuaW1wb3J0IHsgcmVtb3ZlVmFsdWVGcm9tV29ya2xldFJlZk1hcCB9IGZyb20gJy4vd29ya2xldFJlZi5qcyc7XG5cbmZ1bmN0aW9uIGluaXRFdmVudExpc3RlbmVycygpOiB2b2lkIHtcbiAgY29uc3QganNDb250ZXh0ID0gbHlueC5nZXRKU0NvbnRleHQoKTtcbiAganNDb250ZXh0LmFkZEV2ZW50TGlzdGVuZXIoXG4gICAgV29ya2xldEV2ZW50cy5ydW5Xb3JrbGV0Q3R4LFxuICAgIChldmVudDogRXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBKU09OLnBhcnNlKGV2ZW50LmRhdGEgYXMgc3RyaW5nKSBhcyBSdW5Xb3JrbGV0Q3R4RGF0YTtcbiAgICAgIHJ1blJ1bk9uTWFpblRocmVhZFRhc2soZGF0YS53b3JrbGV0LCBkYXRhLnBhcmFtcyBhcyBDbG9zdXJlVmFsdWVUeXBlW10sIGRhdGEucmVzb2x2ZUlkKTtcbiAgICB9LFxuICApO1xuICBqc0NvbnRleHQuYWRkRXZlbnRMaXN0ZW5lcihcbiAgICBXb3JrbGV0RXZlbnRzLnJlbGVhc2VXb3JrbGV0UmVmLFxuICAgIChldmVudDogRXZlbnQpID0+IHtcbiAgICAgIHJlbW92ZVZhbHVlRnJvbVdvcmtsZXRSZWZNYXAoKGV2ZW50LmRhdGEgYXMgUmVsZWFzZVdvcmtsZXRSZWZEYXRhKS5pZCk7XG4gICAgfSxcbiAgKTtcbn1cblxuZXhwb3J0IHsgaW5pdEV2ZW50TGlzdGVuZXJzIH07XG4iLCIvLyBDb3B5cmlnaHQgMjAyNCBUaGUgTHlueCBBdXRob3JzLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuLy8gTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlIFZlcnNpb24gMi4wIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZVxuLy8gTElDRU5TRSBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuaW1wb3J0IHR5cGUgeyBKc0ZuSGFuZGxlIH0gZnJvbSAnLi9iaW5kaW5ncy90eXBlcy5qcyc7XG5cbmludGVyZmFjZSBEZXRhaWxzIHtcbiAgdGFzazogKGZuSWQ6IG51bWJlciwgZXhlY0lkOiBudW1iZXIpID0+IHZvaWQ7XG5cbiAgLy8gVGhpcyBjb21lcyBmcm9tIHRoZSBiYWNrZ3JvdW5kIHRocmVhZCwgaW5zZXJ0ZWQgaGVyZSBkdXJpbmcgY3R4IGh5ZHJhdGlvbi5cbiAganNGbkhhbmRsZT86IEpzRm5IYW5kbGU7XG59XG5cbmludGVyZmFjZSBSdW5PbkJhY2tncm91bmREZWxheUltcGwge1xuICAvLyBFbGVtZW50cyBzaG91bGQga2VlcCB0aGUgb3JkZXIgYmVpbmcgY2FsbGVkIGJ5IHRoZSB1c2VyLlxuICBkZWxheWVkQmFja2dyb3VuZEZ1bmN0aW9uQXJyYXk6IEFycmF5PERldGFpbHMgfCB1bmRlZmluZWQ+O1xuICBjbGVhckRlbGF5ZWRCYWNrZ3JvdW5kRnVuY3Rpb25zKCk6IHZvaWQ7XG4gIGRlbGF5UnVuT25CYWNrZ3JvdW5kKGZuT2JqOiBKc0ZuSGFuZGxlLCBmbjogKGZuSWQ6IG51bWJlciwgZXhlY0lkOiBudW1iZXIpID0+IHZvaWQpOiB2b2lkO1xuICBydW5EZWxheWVkQmFja2dyb3VuZEZ1bmN0aW9ucygpOiB2b2lkO1xufVxuXG5sZXQgaW1wbDogUnVuT25CYWNrZ3JvdW5kRGVsYXlJbXBsIHwgdW5kZWZpbmVkO1xuXG5mdW5jdGlvbiBpbml0UnVuT25CYWNrZ3JvdW5kRGVsYXkoKTogUnVuT25CYWNrZ3JvdW5kRGVsYXlJbXBsIHtcbiAgcmV0dXJuIChpbXBsID0ge1xuICAgIGRlbGF5ZWRCYWNrZ3JvdW5kRnVuY3Rpb25BcnJheTogW10sXG4gICAgY2xlYXJEZWxheWVkQmFja2dyb3VuZEZ1bmN0aW9ucyxcbiAgICBkZWxheVJ1bk9uQmFja2dyb3VuZCxcbiAgICBydW5EZWxheWVkQmFja2dyb3VuZEZ1bmN0aW9ucyxcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIGRlbGF5UnVuT25CYWNrZ3JvdW5kKGZuT2JqOiBKc0ZuSGFuZGxlLCB0YXNrOiAoZm5JZDogbnVtYmVyLCBleGVjSWQ6IG51bWJlcikgPT4gdm9pZCkge1xuICBpbXBsIS5kZWxheWVkQmFja2dyb3VuZEZ1bmN0aW9uQXJyYXkucHVzaCh7IHRhc2sgfSk7XG4gIGNvbnN0IGRlbGF5SW5kaWNlcyA9IGZuT2JqLl9kZWxheUluZGljZXMgPz89IFtdO1xuICBkZWxheUluZGljZXMucHVzaChpbXBsIS5kZWxheWVkQmFja2dyb3VuZEZ1bmN0aW9uQXJyYXkubGVuZ3RoIC0gMSk7XG59XG5cbmZ1bmN0aW9uIGNsZWFyRGVsYXllZEJhY2tncm91bmRGdW5jdGlvbnMoKTogdm9pZCB7XG4gIGltcGwhLmRlbGF5ZWRCYWNrZ3JvdW5kRnVuY3Rpb25BcnJheS5sZW5ndGggPSAwO1xufVxuXG5mdW5jdGlvbiBydW5EZWxheWVkQmFja2dyb3VuZEZ1bmN0aW9ucygpOiB2b2lkIHtcbiAgZm9yIChjb25zdCBkZXRhaWxzIG9mIGltcGwhLmRlbGF5ZWRCYWNrZ3JvdW5kRnVuY3Rpb25BcnJheSkge1xuICAgIGlmIChkZXRhaWxzPy5qc0ZuSGFuZGxlKSB7XG4gICAgICBkZXRhaWxzLnRhc2soZGV0YWlscy5qc0ZuSGFuZGxlLl9qc0ZuSWQhLCBkZXRhaWxzLmpzRm5IYW5kbGUuX2V4ZWNJZCEpO1xuICAgIH1cbiAgfVxuICBjbGVhckRlbGF5ZWRCYWNrZ3JvdW5kRnVuY3Rpb25zKCk7XG59XG5cbmV4cG9ydCB7IHR5cGUgUnVuT25CYWNrZ3JvdW5kRGVsYXlJbXBsLCBpbml0UnVuT25CYWNrZ3JvdW5kRGVsYXkgfTtcbiIsIi8vIENvcHlyaWdodCAyMDI0IFRoZSBMeW54IEF1dGhvcnMuIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4vLyBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UgVmVyc2lvbiAyLjAgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlXG4vLyBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3QgZGlyZWN0b3J5IG9mIHRoaXMgc291cmNlIHRyZWUuXG5pbXBvcnQgdHlwZSB7IENsb3N1cmVWYWx1ZVR5cGUsIFdvcmtsZXQgfSBmcm9tICcuL2JpbmRpbmdzL3R5cGVzLmpzJztcbmltcG9ydCB7IHByb2ZpbGUgfSBmcm9tICcuL3V0aWxzL3Byb2ZpbGUuanMnO1xuXG5pbnRlcmZhY2UgRXZlbnREZWxheUltcGwge1xuICBfZGVsYXllZFdvcmtsZXRQYXJhbXNNYXA6IE1hcDxzdHJpbmcsIENsb3N1cmVWYWx1ZVR5cGVbXVtdPjtcbiAgcnVuRGVsYXllZFdvcmtsZXQod29ya2xldDogV29ya2xldCwgZWxlbWVudDogRWxlbWVudE5vZGUpOiB2b2lkO1xuICBjbGVhckRlbGF5ZWRXb3JrbGV0cygpOiB2b2lkO1xufVxuXG5sZXQgaW1wbDogRXZlbnREZWxheUltcGwgfCB1bmRlZmluZWQ7XG5cbmZ1bmN0aW9uIGluaXRFdmVudERlbGF5KCk6IEV2ZW50RGVsYXlJbXBsIHtcbiAgcmV0dXJuIChpbXBsID0ge1xuICAgIF9kZWxheWVkV29ya2xldFBhcmFtc01hcDogbmV3IE1hcCgpLFxuICAgIHJ1bkRlbGF5ZWRXb3JrbGV0LFxuICAgIGNsZWFyRGVsYXllZFdvcmtsZXRzLFxuICB9KTtcbn1cblxuZnVuY3Rpb24gZGVsYXlFeGVjVW50aWxKc1JlYWR5KFxuICBoYXNoOiBzdHJpbmcsXG4gIHBhcmFtczogQ2xvc3VyZVZhbHVlVHlwZVtdLFxuKTogdm9pZCB7XG4gIHByb2ZpbGUoJ2RlbGF5RXhlY1VudGlsSnNSZWFkeTogJyArIGhhc2gsICgpID0+IHtcbiAgICBjb25zdCBtYXAgPSBpbXBsIS5fZGVsYXllZFdvcmtsZXRQYXJhbXNNYXA7XG4gICAgY29uc3QgcGFyYW1WZWMgPSBtYXAuZ2V0KGhhc2gpO1xuICAgIGlmIChwYXJhbVZlYykge1xuICAgICAgcGFyYW1WZWMucHVzaChwYXJhbXMpO1xuICAgIH0gZWxzZSB7XG4gICAgICBtYXAuc2V0KGhhc2gsIFtwYXJhbXNdKTtcbiAgICB9XG4gIH0pO1xufVxuXG5mdW5jdGlvbiBydW5EZWxheWVkV29ya2xldCh3b3JrbGV0OiBXb3JrbGV0LCBlbGVtZW50OiBFbGVtZW50Tm9kZSk6IHZvaWQge1xuICBwcm9maWxlKCdjb21taXREZWxheWVkV29ya2xldCcsICgpID0+IHtcbiAgICBjb25zdCBwYXJhbXNWZWMgPSBpbXBsIS5fZGVsYXllZFdvcmtsZXRQYXJhbXNNYXAuZ2V0KFxuICAgICAgd29ya2xldC5fd2tsdElkLFxuICAgICk7XG4gICAgaWYgKHBhcmFtc1ZlYyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGxlZnRQYXJhbXNWZWM6IENsb3N1cmVWYWx1ZVR5cGVbXVtdID0gW107XG4gICAgcGFyYW1zVmVjLmZvckVhY2goKHBhcmFtcykgPT4ge1xuICAgICAgY29uc3QgZmlyc3RQYXJhbSA9IHBhcmFtc1swXSBhcyB7IGN1cnJlbnRUYXJnZXQ/OiB7IGVsZW1lbnRSZWZwdHI/OiBFbGVtZW50Tm9kZSB9IH0gfCB1bmRlZmluZWQ7XG4gICAgICBpZiAoZmlyc3RQYXJhbT8uY3VycmVudFRhcmdldD8uZWxlbWVudFJlZnB0ciA9PT0gZWxlbWVudCkge1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICBwcm9maWxlKCdydW5EZWxheWVkV29ya2xldCcsICgpID0+IHtcbiAgICAgICAgICAgIHJ1bldvcmtsZXQod29ya2xldCwgcGFyYW1zKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSwgMCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBsZWZ0UGFyYW1zVmVjLnB1c2gocGFyYW1zKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBpbXBsIS5fZGVsYXllZFdvcmtsZXRQYXJhbXNNYXAuc2V0KFxuICAgICAgd29ya2xldC5fd2tsdElkLFxuICAgICAgbGVmdFBhcmFtc1ZlYyxcbiAgICApO1xuICB9KTtcbn1cblxuZnVuY3Rpb24gY2xlYXJEZWxheWVkV29ya2xldHMoKTogdm9pZCB7XG4gIGltcGwhLl9kZWxheWVkV29ya2xldFBhcmFtc01hcC5jbGVhcigpO1xufVxuXG5leHBvcnQgeyB0eXBlIEV2ZW50RGVsYXlJbXBsLCBpbml0RXZlbnREZWxheSwgZGVsYXlFeGVjVW50aWxKc1JlYWR5LCBydW5EZWxheWVkV29ya2xldCwgY2xlYXJEZWxheWVkV29ya2xldHMgfTtcbiIsIi8vIENvcHlyaWdodCAyMDI1IFRoZSBMeW54IEF1dGhvcnMuIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4vLyBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UgVmVyc2lvbiAyLjAgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlXG4vLyBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3QgZGlyZWN0b3J5IG9mIHRoaXMgc291cmNlIHRyZWUuXG5pbXBvcnQgeyBzZXRTaG91bGRGbHVzaCB9IGZyb20gJy4vYXBpL2VsZW1lbnQuanMnO1xuXG5leHBvcnQgaW50ZXJmYWNlIEVvbUltcGwge1xuICBzZXRTaG91bGRGbHVzaCh2YWx1ZTogYm9vbGVhbik6IHZvaWQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpbml0RW9tSW1wbCgpOiBFb21JbXBsIHtcbiAgcmV0dXJuIHtcbiAgICBzZXRTaG91bGRGbHVzaCxcbiAgfTtcbn1cbiIsIi8vIENvcHlyaWdodCAyMDI0IFRoZSBMeW54IEF1dGhvcnMuIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4vLyBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UgVmVyc2lvbiAyLjAgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlXG4vLyBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3QgZGlyZWN0b3J5IG9mIHRoaXMgc291cmNlIHRyZWUuXG5cbmltcG9ydCB0eXBlIHsgQ2xvc3VyZVZhbHVlVHlwZSwgRXZlbnRDdHgsIFJ1bldvcmtsZXRPcHRpb25zIH0gZnJvbSAnLi9iaW5kaW5ncy90eXBlcy5qcyc7XG5pbXBvcnQgeyBSdW5Xb3JrbGV0U291cmNlIH0gZnJvbSAnLi9iaW5kaW5ncy90eXBlcy5qcyc7XG5cbi8vIEV2ZW50UmVzdWx0IGVudW0gdmFsdWVzXG5leHBvcnQgY29uc3QgRXZlbnRSZXN1bHQgPSB7XG4gIGtEZWZhdWx0OiAweDAsXG4gIGtTdG9wUHJvcGFnYXRpb25NYXNrOiAweDEsXG4gIGtTdG9wSW1tZWRpYXRlUHJvcGFnYXRpb25NYXNrOiAweDIsXG59IGFzIGNvbnN0O1xuXG50eXBlIEV2ZW50TGlrZSA9IFJlY29yZDxzdHJpbmcsIENsb3N1cmVWYWx1ZVR5cGU+O1xuXG5leHBvcnQgZnVuY3Rpb24gaXNFdmVudE9iamVjdChcbiAgY3R4OiBDbG9zdXJlVmFsdWVUeXBlW10sXG4gIG9wdGlvbnM/OiBSdW5Xb3JrbGV0T3B0aW9ucyxcbik6IGN0eCBpcyBbRXZlbnRMaWtlLCAuLi5DbG9zdXJlVmFsdWVUeXBlW11dIHtcbiAgaWYgKCFBcnJheS5pc0FycmF5KGN0eCkgfHwgdHlwZW9mIGN0eFswXSAhPT0gJ29iamVjdCcgfHwgY3R4WzBdID09PSBudWxsKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmIChvcHRpb25zICYmIG9wdGlvbnMuc291cmNlID09PSBSdW5Xb3JrbGV0U291cmNlLkVWRU5UKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vKipcbiAqIEFkZCBldmVudCBtZXRob2RzIHRvIGFuIGV2ZW50IG9iamVjdCBpZiBuZWVkZWRcbiAqIEBwYXJhbSBjdHggVGhlIGV2ZW50IG9iamVjdCB0byBlbmhhbmNlXG4gKiBAcGFyYW0gb3B0aW9ucyBUaGUgcnVuIHdvcmtsZXQgb3B0aW9uc1xuICogQHJldHVybnMgQSB0dXBsZSBvZiBib29sZWFuIGFuZCB0aGUgZXZlbnQgcmV0dXJuIHJlc3VsdFxuICovXG5leHBvcnQgZnVuY3Rpb24gYWRkRXZlbnRNZXRob2RzSWZOZWVkZWQoY3R4OiBDbG9zdXJlVmFsdWVUeXBlW10sIG9wdGlvbnM/OiBSdW5Xb3JrbGV0T3B0aW9ucyk6IFtib29sZWFuLCBFdmVudEN0eF0ge1xuICBpZiAoIWlzRXZlbnRPYmplY3QoY3R4LCBvcHRpb25zKSkge1xuICAgIHJldHVybiBbZmFsc2UsIHt9XTtcbiAgfVxuICBjb25zdCBldmVudEN0eDogRXZlbnRDdHggPSB7fTtcbiAgY29uc3QgZXZlbnRPYmogPSBjdHhbMF07XG5cbiAgLy8gQWRkIHN0b3BQcm9wYWdhdGlvbiBtZXRob2RcbiAgZXZlbnRPYmpbJ3N0b3BQcm9wYWdhdGlvbiddID0gZnVuY3Rpb24oKSB7XG4gICAgZXZlbnRDdHguX2V2ZW50UmV0dXJuUmVzdWx0ID0gKGV2ZW50Q3R4Ll9ldmVudFJldHVyblJlc3VsdCA/PyBFdmVudFJlc3VsdC5rRGVmYXVsdClcbiAgICAgIHwgRXZlbnRSZXN1bHQua1N0b3BQcm9wYWdhdGlvbk1hc2s7XG4gIH07XG5cbiAgLy8gQWRkIHN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbiBtZXRob2RcbiAgZXZlbnRPYmpbJ3N0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbiddID0gZnVuY3Rpb24oKSB7XG4gICAgZXZlbnRDdHguX2V2ZW50UmV0dXJuUmVzdWx0ID0gKGV2ZW50Q3R4Ll9ldmVudFJldHVyblJlc3VsdCA/PyBFdmVudFJlc3VsdC5rRGVmYXVsdClcbiAgICAgIHwgRXZlbnRSZXN1bHQua1N0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbk1hc2s7XG4gIH07XG5cbiAgcmV0dXJuIFt0cnVlLCBldmVudEN0eF07XG59XG4iLCIvLyBDb3B5cmlnaHQgMjAyNCBUaGUgTHlueCBBdXRob3JzLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuLy8gTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlIFZlcnNpb24gMi4wIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZVxuLy8gTElDRU5TRSBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuXG5pbXBvcnQgdHlwZSB7XG4gIENsb3N1cmVWYWx1ZVR5cGUsXG4gIEpzRm5IYW5kbGUsXG4gIFdvcmtsZXQsXG4gIFdvcmtsZXRSZWYsXG4gIFdvcmtsZXRSZWZJZCxcbiAgV29ya2xldFJlZkltcGwsXG59IGZyb20gJy4vYmluZGluZ3MvaW5kZXguanMnO1xuaW1wb3J0IHsgcHJvZmlsZSB9IGZyb20gJy4vdXRpbHMvcHJvZmlsZS5qcyc7XG5pbXBvcnQgeyBoeWRyYXRlV29ya2xldFZhbHVlLCBpc0h5ZHJhdGVkV29ya2xldFZhbHVlIH0gZnJvbSAnLi93b3JrbGV0UmVmLmpzJztcblxuLyoqXG4gKiBIeWRyYXRlcyBhIFdvcmtsZXQgY29udGV4dCB3aXRoIGRhdGEgZnJvbSBhIGZpcnN0LXNjcmVlbiBXb3JrbGV0IGNvbnRleHQuXG4gKiBUaGlzIHByb2Nlc3MgaXMgdHlwaWNhbGx5IHVzZWQgdG8gcnVuIGFsbCBkZWxheWVkIGBydW5PbkJhY2tncm91bmRgIGZ1bmN0aW9uc1xuICogYW5kIGluaXRpYWxpemUgYFdvcmtsZXRSZWZgIHZhbHVlcyBtb2RpZmllZCBiZWZvcmUgaHlkcmF0aW9uLlxuICpcbiAqIEBwYXJhbSBjdHggVGhlIHRhcmdldCBXb3JrbGV0IGNvbnRleHQgdG8gYmUgaHlkcmF0ZWQuXG4gKiBAcGFyYW0gZmlyc3RTY3JlZW5DdHggVGhlIFdvcmtsZXQgY29udGV4dCBmcm9tIHRoZSBmaXJzdCBzY3JlZW4gcmVuZGVyaW5nLFxuICogICAgICAgICAgICAgICAgICAgICAgIGNvbnRhaW5pbmcgdGhlIGRhdGEgdG8gaHlkcmF0ZSB3aXRoLlxuICovXG5leHBvcnQgZnVuY3Rpb24gaHlkcmF0ZUN0eChjdHg6IFdvcmtsZXQsIGZpcnN0U2NyZWVuQ3R4OiBXb3JrbGV0KTogdm9pZCB7XG4gIHByb2ZpbGUoJ2h5ZHJhdGVDdHgnLCAoKSA9PiB7XG4gICAgaHlkcmF0ZUN0eEltcGwoY3R4LCBmaXJzdFNjcmVlbkN0eCwgY3R4Ll9leGVjSWQhKTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIGh5ZHJhdGVDdHhJbXBsKFxuICBjdHg6IENsb3N1cmVWYWx1ZVR5cGUsXG4gIGZpcnN0U2NyZWVuQ3R4OiBDbG9zdXJlVmFsdWVUeXBlLFxuICBleGVjSWQ6IG51bWJlcixcbik6IHZvaWQge1xuICBpZiAoXG4gICAgIWN0eCB8fCB0eXBlb2YgY3R4ICE9PSAnb2JqZWN0JyB8fCAhZmlyc3RTY3JlZW5DdHhcbiAgICB8fCB0eXBlb2YgZmlyc3RTY3JlZW5DdHggIT09ICdvYmplY3QnXG4gICkgcmV0dXJuO1xuXG4gIGNvbnN0IGN0eE9iaiA9IGN0eCBhcyBSZWNvcmQ8c3RyaW5nLCBDbG9zdXJlVmFsdWVUeXBlPjtcbiAgY29uc3QgZmlyc3RTY3JlZW5DdHhPYmogPSBmaXJzdFNjcmVlbkN0eCBhcyBSZWNvcmQ8c3RyaW5nLCBDbG9zdXJlVmFsdWVUeXBlPjtcblxuICBpZiAoY3R4T2JqWydfd2tsdElkJ10gJiYgY3R4T2JqWydfd2tsdElkJ10gIT09IGZpcnN0U2NyZWVuQ3R4T2JqWydfd2tsdElkJ10pIHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBUeXBlZCBoYW5kbGVzIChpbmNsdWRpbmcgYF90eXBlOiAnbWFpbi10aHJlYWQnYCBtdXRhYmxlIGNlbGxzKSBoeWRyYXRlXG4gIC8vIGF0b21pY2FsbHkgd2l0aG91dCB3YWxraW5nIHRoZWlyIGluaXRpYWxpemF0aW9uIHBheWxvYWQuIFVudHlwZWQgbGVnYWN5XG4gIC8vIHJlZnMgY29udGludWUgdGhyb3VnaCB0aGUgZXhpc3RpbmcgYF93dmlkYCBwYXRoIGJlbG93LlxuICBpZiAoaXNUeXBlZFdvcmtsZXRSZWZEZXNjcmlwdG9yKGN0eE9iaikpIHtcbiAgICBoeWRyYXRlV29ya2xldFZhbHVlSGFuZGxlKGN0eE9iaiwgZmlyc3RTY3JlZW5DdHhPYmopO1xuICAgIHJldHVybjtcbiAgfVxuICBmb3IgKGNvbnN0IGtleSBpbiBjdHgpIHtcbiAgICBpZiAoa2V5ID09PSAnX3d2aWQnKSB7XG4gICAgICBoeWRyYXRlTWFpblRocmVhZFJlZihcbiAgICAgICAgY3R4T2JqW2tleV0gYXMgV29ya2xldFJlZklkLFxuICAgICAgICBmaXJzdFNjcmVlbkN0eE9iaiBhcyB1bmtub3duIGFzIFdvcmtsZXRSZWZJbXBsPHVua25vd24+LFxuICAgICAgKTtcbiAgICB9IGVsc2UgaWYgKGtleSA9PT0gJ19qc0ZuJykge1xuICAgICAgaHlkcmF0ZURlbGF5UnVuT25CYWNrZ3JvdW5kVGFza3MoXG4gICAgICAgIGN0eE9ialtrZXldIGFzIFJlY29yZDxzdHJpbmcsIEpzRm5IYW5kbGU+LFxuICAgICAgICBmaXJzdFNjcmVlbkN0eE9ialtrZXldIGFzIFJlY29yZDxzdHJpbmcsIEpzRm5IYW5kbGU+LFxuICAgICAgICBleGVjSWQsXG4gICAgICApO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBmaXJzdFNjcmVlblZhbHVlID0gdHlwZW9mIGZpcnN0U2NyZWVuQ3R4T2JqW2tleV0gPT09ICdmdW5jdGlvbidcbiAgICAgICAgPyAoZmlyc3RTY3JlZW5DdHhPYmpba2V5XSBhcyB7IGJvdW5kQ3R4Pzogb2JqZWN0IH0pLmJvdW5kQ3R4IGFzIENsb3N1cmVWYWx1ZVR5cGVcbiAgICAgICAgOiBmaXJzdFNjcmVlbkN0eE9ialtrZXldO1xuICAgICAgaHlkcmF0ZUN0eEltcGwoY3R4T2JqW2tleV0sIGZpcnN0U2NyZWVuVmFsdWUsIGV4ZWNJZCk7XG4gICAgfVxuICB9XG59XG5cbmZ1bmN0aW9uIGlzVHlwZWRXb3JrbGV0UmVmRGVzY3JpcHRvcihcbiAgdmFsdWU6IG9iamVjdCxcbik6IHZhbHVlIGlzIFdvcmtsZXRSZWZJbXBsPHVua25vd24+IHtcbiAgY29uc3QgZGVzY3JpcHRvciA9IHZhbHVlIGFzIFBhcnRpYWw8V29ya2xldFJlZkltcGw8dW5rbm93bj4+O1xuICByZXR1cm4gdHlwZW9mIGRlc2NyaXB0b3IuX3d2aWQgPT09ICdudW1iZXInXG4gICAgJiYgdHlwZW9mIGRlc2NyaXB0b3IuX3R5cGUgPT09ICdzdHJpbmcnO1xufVxuXG4vKipcbiAqIEh5ZHJhdGVzIGEgV29ya2xldFJlZiBvbiB0aGUgbWFpbiB0aHJlYWQuXG4gKiBUaGlzIG1hcHMgdGhlIHBvc2l0aXZlLUlEIGJhY2tncm91bmQgaGFuZGxlIHRvIHRoZSB0YXJnZXQgcmVhbGl6ZWQgZHVyaW5nXG4gKiBmaXJzdC1zY3JlZW4gcmVuZGVyaW5nLCB3aGlsZSBsZWF2aW5nIGFuIHVudXNlZCBmaXJzdC1zY3JlZW4gaGFuZGxlIGFsb25lLlxuICovXG5mdW5jdGlvbiBoeWRyYXRlTWFpblRocmVhZFJlZihcbiAgcmVmSWQ6IFdvcmtsZXRSZWZJZCxcbiAgdmFsdWU6IFdvcmtsZXRSZWZJbXBsPHVua25vd24+LFxuKTogdm9pZCB7XG4gIGlmICgnX2luaXRWYWx1ZScgaW4gdmFsdWUpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgbHlueFdvcmtsZXRJbXBsIS5fcmVmSW1wbC5fd29ya2xldFJlZk1hcFtyZWZJZF0gPSB2YWx1ZSBhcyBXb3JrbGV0UmVmPHVua25vd24+O1xufVxuXG4vKipcbiAqIEh5ZHJhdGVzIGEgdHlwZWQgd29ya2xldCBoYW5kbGUgb24gdGhlIG1haW4gdGhyZWFkLlxuICogVGhlIHRhcmdldCBpcyB0aGUgb2JqZWN0IG9yIG11dGFibGUgY2VsbCByZWFsaXplZCBmcm9tIHRoZSBtYXRjaGluZyBmaXJzdC1zY3JlZW4gaGFuZGxlLlxuICovXG5mdW5jdGlvbiBoeWRyYXRlV29ya2xldFZhbHVlSGFuZGxlKFxuICBoYW5kbGU6IFdvcmtsZXRSZWZJbXBsPHVua25vd24+LFxuICB2YWx1ZTogQ2xvc3VyZVZhbHVlVHlwZSxcbik6IHZvaWQge1xuICBpZiAoIWlzSHlkcmF0ZWRXb3JrbGV0VmFsdWUodmFsdWUpKSB7XG4gICAgLy8gVGhlIGhhbmRsZSB3YXMgbm90IGFjY2Vzc2VkIGR1cmluZyBmaXJzdC1zY3JlZW4gcmVuZGVyaW5nLlxuICAgIHJldHVybjtcbiAgfVxuICBoeWRyYXRlV29ya2xldFZhbHVlKGhhbmRsZSwgdmFsdWUpO1xufVxuXG4vKipcbiAqIEh5ZHJhdGVzIGRlbGF5ZWQgYHJ1bk9uQmFja2dyb3VuZGAgdGFza3MuXG4gKiBUaGlzIGZ1bmN0aW9uIGVuc3VyZXMgdGhhdCBhbnkgYHJ1bk9uQmFja2dyb3VuZGAgY2FsbHMgdGhhdCB3ZXJlIGRlbGF5ZWRcbiAqIGR1cmluZyB0aGUgZmlyc3Qtc2NyZWVuIHJlbmRlcmluZyBhcmUgY29ycmVjdGx5IGFzc29jaWF0ZWQgd2l0aCB0aGVpclxuICogcmVzcGVjdGl2ZSBKYXZhU2NyaXB0IGZ1bmN0aW9uIGhhbmRsZXMgaW4gdGhlIGh5ZHJhdGVkIFdvcmtsZXQgY29udGV4dC5cbiAqL1xuZnVuY3Rpb24gaHlkcmF0ZURlbGF5UnVuT25CYWNrZ3JvdW5kVGFza3MoXG4gIGZuT2JqczogUmVjb3JkPHN0cmluZywgSnNGbkhhbmRsZT4sIC8vIGV4YW1wbGU6IHtcIl9qc0ZuMVwiOntcIl9qc0ZuSWRcIjoxfX1cbiAgZmlyc3RTY3JlZW5Gbk9ianM6IFJlY29yZDxzdHJpbmcsIEpzRm5IYW5kbGU+LCAvLyBleGFtcGxlOiB7XCJfanNGbjFcIjp7XCJfaXNGaXJzdFNjcmVlblwiOnRydWUsXCJfZGVsYXlJbmRpY2VzXCI6WzBdfX1cbiAgZXhlY0lkOiBudW1iZXIsXG4pIHtcbiAgZm9yIChjb25zdCBmbk5hbWUgaW4gZm5PYmpzKSB7XG4gICAgY29uc3QgZm5PYmogPSBmbk9ianNbZm5OYW1lXSE7XG4gICAgY29uc3QgZmlyc3RTY3JlZW5Gbk9iajogSnNGbkhhbmRsZSB8IHVuZGVmaW5lZCA9IGZpcnN0U2NyZWVuRm5PYmpzW2ZuTmFtZV07XG4gICAgaWYgKCFmaXJzdFNjcmVlbkZuT2JqPy5fZGVsYXlJbmRpY2VzKSB7XG4gICAgICBpZiAoZmlyc3RTY3JlZW5Gbk9iaikge1xuICAgICAgICBmaXJzdFNjcmVlbkZuT2JqLl9pc0ZpcnN0U2NyZWVuID0gZmFsc2U7XG4gICAgICAgIGZpcnN0U2NyZWVuRm5PYmouX2V4ZWNJZCA9IGV4ZWNJZDtcbiAgICAgICAgT2JqZWN0LmFzc2lnbihmaXJzdFNjcmVlbkZuT2JqLCBmbk9iaik7XG4gICAgICB9XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBpbmRleCBvZiBmaXJzdFNjcmVlbkZuT2JqLl9kZWxheUluZGljZXMpIHtcbiAgICAgIGNvbnN0IGRldGFpbHMgPSBseW54V29ya2xldEltcGwhLl9ydW5PbkJhY2tncm91bmREZWxheUltcGxcbiAgICAgICAgLmRlbGF5ZWRCYWNrZ3JvdW5kRnVuY3Rpb25BcnJheVtpbmRleF07XG4gICAgICBpZiAoIWRldGFpbHMpIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBmbk9iai5fZXhlY0lkID0gZXhlY0lkO1xuICAgICAgZGV0YWlscy5qc0ZuSGFuZGxlID0gZm5PYmo7XG4gICAgfVxuICB9XG59XG4iLCIvLyBDb3B5cmlnaHQgMjAyNCBUaGUgTHlueCBBdXRob3JzLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuLy8gTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlIFZlcnNpb24gMi4wIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZVxuLy8gTElDRU5TRSBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuaW1wb3J0IHsgV29ya2xldEV2ZW50cyB9IGZyb20gJy4vYmluZGluZ3MvZXZlbnRzLmpzJztcbmltcG9ydCB7IHByb2ZpbGUgfSBmcm9tICcuL3V0aWxzL3Byb2ZpbGUuanMnO1xuaW1wb3J0IHsgaXNTZGtWZXJzaW9uR3QgfSBmcm9tICcuL3V0aWxzL3ZlcnNpb24uanMnO1xuXG4vKipcbiAqIGBKc0Z1bmN0aW9uTGlmZWN5Y2xlTWFuYWdlcmAgbW9uaXRvcnMgcmVmZXJlbmNlcyB0byBKUyBmdW5jdGlvbiBoYW5kbGVzIHRvIGJlIGNhbGxlZCBieSBgcnVuT25CYWNrZ3JvdW5kKClgLlxuICogSW4gSlMgY29udGV4dCwgZnVuY3Rpb25zIHRvIGJlIGNhbGxlZCBieSBgcnVuT25CYWNrZ3JvdW5kKClgIGlzIHJlZmVyZW5jZWQgYnkgYEpzRm5IYW5kbGVgcyBhbmQgZmluYWxseSBieSBgZXhlY0lkYC5cbiAqIFdoZW4gYWxsIGBKc0ZuSGFuZGxlYHMgaW4gbGVwdXMgYXJlIHJlbGVhc2VkLCBhbiBldmVudCB3aWxsIGJlIHNlbnQgdG8gSlMgY29udGV4dCB0byBkZS1yZWYgdGhlIGBleGVjSWRgLFxuICogcmVzdWx0aW5nIGEgZGUtcmVmIHRvIHRoZSBqcyBmdW5jdGlvbiBpbiBKUyBjb250ZXh0LlxuICovXG5jbGFzcyBKc0Z1bmN0aW9uTGlmZWN5Y2xlTWFuYWdlciB7XG4gIHByaXZhdGUgZXhlY0lkUmVmQ291bnQgPSBuZXcgTWFwPG51bWJlciwgbnVtYmVyPigpO1xuICBwcml2YXRlIGV4ZWNJZFNldFRvRmlyZSA9IG5ldyBTZXQ8bnVtYmVyPigpO1xuICBwcml2YXRlIHJldGFpbmVkT2JqZWN0cyA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgcHJpdmF0ZSB3aWxsRmlyZSA9IGZhbHNlO1xuICBwcml2YXRlIHJlZ2lzdHJ5OiBGaW5hbGl6YXRpb25SZWdpc3RyeTxudW1iZXI+O1xuXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMucmVnaXN0cnkgPSBuZXcgRmluYWxpemF0aW9uUmVnaXN0cnk8bnVtYmVyPih0aGlzLnJlbW92ZVJlZi5iaW5kKHRoaXMpKTtcbiAgfVxuXG4gIGFkZFJlZihleGVjSWQ6IG51bWJlciwgb2JqVG9SZWY6IG9iamVjdCk6IHZvaWQge1xuICAgIGlmICh0aGlzLnJldGFpbmVkT2JqZWN0cy5oYXMob2JqVG9SZWYpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMucmV0YWluZWRPYmplY3RzLmFkZChvYmpUb1JlZik7XG4gICAgdGhpcy5leGVjSWRSZWZDb3VudC5zZXQoXG4gICAgICBleGVjSWQsXG4gICAgICAodGhpcy5leGVjSWRSZWZDb3VudC5nZXQoZXhlY0lkKSA/PyAwKSArIDEsXG4gICAgKTtcbiAgICB0aGlzLnJlZ2lzdHJ5LnJlZ2lzdGVyKG9ialRvUmVmLCBleGVjSWQpO1xuICB9XG5cbiAgcmVtb3ZlUmVmKGV4ZWNJZDogbnVtYmVyKTogdm9pZCB7XG4gICAgY29uc3QgcmMgPSB0aGlzLmV4ZWNJZFJlZkNvdW50LmdldChleGVjSWQpITtcbiAgICBpZiAocmMgPiAxKSB7XG4gICAgICB0aGlzLmV4ZWNJZFJlZkNvdW50LnNldChleGVjSWQsIHJjIC0gMSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMuZXhlY0lkUmVmQ291bnQuZGVsZXRlKGV4ZWNJZCk7XG4gICAgdGhpcy5leGVjSWRTZXRUb0ZpcmUuYWRkKGV4ZWNJZCk7XG4gICAgaWYgKCF0aGlzLndpbGxGaXJlKSB7XG4gICAgICB0aGlzLndpbGxGaXJlID0gdHJ1ZTtcbiAgICAgIHZvaWQgUHJvbWlzZS5yZXNvbHZlKCkudGhlbigoKSA9PiB7XG4gICAgICAgIHRoaXMuZmlyZSgpO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgZmlyZSgpOiB2b2lkIHtcbiAgICBwcm9maWxlKCdKc0Z1bmN0aW9uTGlmZWN5Y2xlTWFuYWdlci5maXJlJywgKCkgPT4ge1xuICAgICAgbHlueC5nZXRKU0NvbnRleHQoKS5kaXNwYXRjaEV2ZW50KHtcbiAgICAgICAgdHlwZTogV29ya2xldEV2ZW50cy5yZWxlYXNlQmFja2dyb3VuZFdvcmtsZXRDdHgsXG4gICAgICAgIGRhdGE6IEFycmF5LmZyb20odGhpcy5leGVjSWRTZXRUb0ZpcmUpLFxuICAgICAgfSk7XG4gICAgICB0aGlzLmV4ZWNJZFNldFRvRmlyZS5jbGVhcigpO1xuICAgICAgdGhpcy53aWxsRmlyZSA9IGZhbHNlO1xuICAgIH0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIGlzUnVuT25CYWNrZ3JvdW5kRW5hYmxlZCgpOiBib29sZWFuIHtcbiAgcmV0dXJuIGlzU2RrVmVyc2lvbkd0KDIsIDE1KTtcbn1cblxuZXhwb3J0IHsgSnNGdW5jdGlvbkxpZmVjeWNsZU1hbmFnZXIsIGlzUnVuT25CYWNrZ3JvdW5kRW5hYmxlZCB9O1xuIiwiLy8gQ29weXJpZ2h0IDIwMjQgVGhlIEx5bnggQXV0aG9ycy4gQWxsIHJpZ2h0cyByZXNlcnZlZC5cbi8vIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSBWZXJzaW9uIDIuMCB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGVcbi8vIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbmltcG9ydCB7IEVsZW1lbnQgfSBmcm9tICcuL2FwaS9lbGVtZW50LmpzJztcbmltcG9ydCB0eXBlIHsgQ2xvc3VyZVZhbHVlVHlwZSwgUnVuV29ya2xldE9wdGlvbnMsIFdvcmtsZXQsIFdvcmtsZXRSZWZJbXBsIH0gZnJvbSAnLi9iaW5kaW5ncy90eXBlcy5qcyc7XG5pbXBvcnQgeyBSdW5Xb3JrbGV0U291cmNlIH0gZnJvbSAnLi9iaW5kaW5ncy90eXBlcy5qcyc7XG5pbXBvcnQgeyBpbml0UnVuT25CYWNrZ3JvdW5kRGVsYXkgfSBmcm9tICcuL2RlbGF5UnVuT25CYWNrZ3JvdW5kLmpzJztcbmltcG9ydCB7IGRlbGF5RXhlY1VudGlsSnNSZWFkeSwgaW5pdEV2ZW50RGVsYXkgfSBmcm9tICcuL2RlbGF5V29ya2xldEV2ZW50LmpzJztcbmltcG9ydCB7IGluaXRFb21JbXBsIH0gZnJvbSAnLi9lb21JbXBsLmpzJztcbmltcG9ydCB7IGFkZEV2ZW50TWV0aG9kc0lmTmVlZGVkIH0gZnJvbSAnLi9ldmVudFByb3BhZ2F0aW9uLmpzJztcbmltcG9ydCB7IGh5ZHJhdGVDdHggfSBmcm9tICcuL2h5ZHJhdGUuanMnO1xuaW1wb3J0IHsgSnNGdW5jdGlvbkxpZmVjeWNsZU1hbmFnZXIsIGlzUnVuT25CYWNrZ3JvdW5kRW5hYmxlZCB9IGZyb20gJy4vanNGdW5jdGlvbkxpZmVjeWNsZS5qcyc7XG5pbXBvcnQgeyBpc1JlYWxpemVkTWFpblRocmVhZE9iamVjdCB9IGZyb20gJy4vbWFpblRocmVhZE9iamVjdC5qcyc7XG5pbXBvcnQgeyBydW5SdW5Pbk1haW5UaHJlYWRUYXNrIH0gZnJvbSAnLi9ydW5Pbk1haW5UaHJlYWQuanMnO1xuaW1wb3J0IHsgbWFpblRocmVhZEZsdXNoTG9vcE1hcmsgfSBmcm9tICcuL3V0aWxzL21haW5UaHJlYWRGbHVzaExvb3BHdWFyZC5qcyc7XG5pbXBvcnQgeyBwcm9maWxlIH0gZnJvbSAnLi91dGlscy9wcm9maWxlLmpzJztcbmltcG9ydCB7IGdldEZyb21Xb3JrbGV0UmVmTWFwLCBpbml0V29ya2xldFJlZiB9IGZyb20gJy4vd29ya2xldFJlZi5qcyc7XG5cbmZ1bmN0aW9uIGluaXRXb3JrbGV0KCk6IHZvaWQge1xuICBnbG9iYWxUaGlzLmx5bnhXb3JrbGV0SW1wbCA9IHtcbiAgICBfd29ya2xldE1hcDoge30sXG4gICAgX3JlZkltcGw6IGluaXRXb3JrbGV0UmVmKCksXG4gICAgX3J1bk9uQmFja2dyb3VuZERlbGF5SW1wbDogaW5pdFJ1bk9uQmFja2dyb3VuZERlbGF5KCksXG4gICAgX2h5ZHJhdGVDdHg6IGh5ZHJhdGVDdHgsXG4gICAgX2V2ZW50RGVsYXlJbXBsOiBpbml0RXZlbnREZWxheSgpLFxuICAgIF9lb21JbXBsOiBpbml0RW9tSW1wbCgpLFxuICAgIF9ydW5SdW5Pbk1haW5UaHJlYWRUYXNrOiBydW5SdW5Pbk1haW5UaHJlYWRUYXNrLFxuICB9O1xuXG4gIGlmIChpc1J1bk9uQmFja2dyb3VuZEVuYWJsZWQoKSkge1xuICAgIGdsb2JhbFRoaXMubHlueFdvcmtsZXRJbXBsLl9qc0Z1bmN0aW9uTGlmZWN5Y2xlTWFuYWdlciA9IG5ldyBKc0Z1bmN0aW9uTGlmZWN5Y2xlTWFuYWdlcigpO1xuICB9XG5cbiAgZ2xvYmFsVGhpcy5yZWdpc3RlcldvcmtsZXQgPSByZWdpc3RlcldvcmtsZXQ7XG4gIGdsb2JhbFRoaXMucmVnaXN0ZXJXb3JrbGV0SW50ZXJuYWwgPSByZWdpc3RlcldvcmtsZXQ7XG4gIGdsb2JhbFRoaXMucnVuV29ya2xldCA9IHJ1bldvcmtsZXQ7XG59XG5cbi8qKlxuICogUmVnaXN0ZXIgYSB3b3JrbGV0IGZ1bmN0aW9uLCBhbGxvd2luZyBpdCB0byBiZSBleGVjdXRlZCBieSBgcnVuV29ya2xldCgpYC5cbiAqIFRoaXMgaXMgY2FsbGVkIGluIGxlcHVzLmpzLlxuICogQHBhcmFtIF90eXBlIHdvcmtsZXQgdHlwZSwgJ21haW4tdGhyZWFkJyBvciAndWknXG4gKiBAcGFyYW0gaWQgd29ya2xldCBoYXNoXG4gKiBAcGFyYW0gd29ya2xldCB3b3JrbGV0IGZ1bmN0aW9uXG4gKi9cbmZ1bmN0aW9uIHJlZ2lzdGVyV29ya2xldChfdHlwZTogc3RyaW5nLCBpZDogc3RyaW5nLCB3b3JrbGV0OiAoLi4uYXJnczogdW5rbm93bltdKSA9PiB1bmtub3duKTogdm9pZCB7XG4gIGx5bnhXb3JrbGV0SW1wbC5fd29ya2xldE1hcFtpZF0gPSB3b3JrbGV0O1xufVxuXG4vKipcbiAqIEVudHJhbmNlIG9mIGFsbCB3b3JrbGV0IGNhbGxzLlxuICogTmF0aXZlIGV2ZW50IHRvdWNoIGhhbmRsZXIgd2lsbCBjYWxsIHRoaXMgZnVuY3Rpb24uXG4gKiBAcGFyYW0gY3R4IHdvcmtsZXQgb2JqZWN0LlxuICogQHBhcmFtIHBhcmFtcyB3b3JrbGV0IHBhcmFtcy5cbiAqIEBwYXJhbSBvcHRpb25zIHJ1biB3b3JrbGV0IG9wdGlvbnMuXG4gKi9cbmZ1bmN0aW9uIHJ1bldvcmtsZXQoY3R4OiBXb3JrbGV0LCBwYXJhbXM6IENsb3N1cmVWYWx1ZVR5cGVbXSwgb3B0aW9ucz86IFJ1bldvcmtsZXRPcHRpb25zKTogdW5rbm93biB7XG4gIGlmICghdmFsaWRhdGVXb3JrbGV0KGN0eCkpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAoX19ERVZfXykge1xuICAgIGlmIChvcHRpb25zPy5zb3VyY2UgPT09IFJ1bldvcmtsZXRTb3VyY2UuRVZFTlQgJiYgQXJyYXkuaXNBcnJheShwYXJhbXMpKSB7XG4gICAgICBjb25zdCBmaXJzdCA9IHBhcmFtc1swXTtcbiAgICAgIGNvbnN0IHQgPSAoZmlyc3QgYXMgeyB0eXBlPzogdW5rbm93biB9KS50eXBlO1xuICAgICAgaWYgKHR5cGVvZiB0ID09PSAnc3RyaW5nJykge1xuICAgICAgICBtYWluVGhyZWFkRmx1c2hMb29wTWFyayhgZXZlbnQ6JHt0fWApO1xuICAgICAgfVxuICAgIH1cblxuICAgIG1haW5UaHJlYWRGbHVzaExvb3BNYXJrKGBNYWluVGhyZWFkRnVuY3Rpb24gaWQ9JHtTdHJpbmcoY3R4Ll93a2x0SWQpfWApO1xuICB9XG5cbiAgaWYgKCdfbGVwdXNXb3JrbGV0SGFzaCcgaW4gY3R4KSB7XG4gICAgZGVsYXlFeGVjVW50aWxKc1JlYWR5KGN0eC5fbGVwdXNXb3JrbGV0SGFzaCwgcGFyYW1zKTtcbiAgICByZXR1cm47XG4gIH1cbiAgcmV0dXJuIHJ1bldvcmtsZXRJbXBsKGN0eCwgcGFyYW1zLCBvcHRpb25zKTtcbn1cblxuZnVuY3Rpb24gcnVuV29ya2xldEltcGwoY3R4OiBXb3JrbGV0LCBwYXJhbXM6IENsb3N1cmVWYWx1ZVR5cGVbXSwgb3B0aW9ucz86IFJ1bldvcmtsZXRPcHRpb25zKTogdW5rbm93biB7XG4gIGNvbnN0IHdvcmtsZXQ6ICguLi5hcmdzOiB1bmtub3duW10pID0+IHVua25vd24gPSBwcm9maWxlKFxuICAgICd0cmFuc2Zvcm1Xb3JrbGV0Q3R4ICcgKyBjdHguX3drbHRJZCxcbiAgICAoKSA9PiB0cmFuc2Zvcm1Xb3JrbGV0KGN0eCwgdHJ1ZSksXG4gICk7XG4gIGNvbnN0IHBhcmFtc186IENsb3N1cmVWYWx1ZVR5cGVbXSA9IHByb2ZpbGUoXG4gICAgJ3RyYW5zZm9ybVdvcmtsZXRQYXJhbXMnLFxuICAgICgpID0+IHRyYW5zZm9ybVdvcmtsZXQocGFyYW1zIHx8IFtdLCBmYWxzZSksXG4gICk7XG5cbiAgY29uc3QgW2hhc0V2ZW50TWV0aG9kcywgZXZlbnRDdHhdID0gYWRkRXZlbnRNZXRob2RzSWZOZWVkZWQocGFyYW1zXywgb3B0aW9ucyk7XG5cbiAgY29uc3QgcmVzdWx0ID0gcHJvZmlsZSgncnVuV29ya2xldCcsICgpID0+IHdvcmtsZXQoLi4ucGFyYW1zXykpO1xuXG4gIGlmIChoYXNFdmVudE1ldGhvZHMpIHtcbiAgICByZXR1cm4ge1xuICAgICAgcmV0dXJuVmFsdWU6IHJlc3VsdCxcbiAgICAgIGV2ZW50UmV0dXJuUmVzdWx0OiBldmVudEN0eC5fZXZlbnRSZXR1cm5SZXN1bHQsXG4gICAgfTtcbiAgfVxuXG4gIHJldHVybiByZXN1bHQ7XG59XG5cbmZ1bmN0aW9uIHZhbGlkYXRlV29ya2xldChjdHg6IHVua25vd24pOiBjdHggaXMgV29ya2xldCB7XG4gIHJldHVybiB0eXBlb2YgY3R4ID09PSAnb2JqZWN0JyAmJiBjdHggIT09IG51bGwgJiYgKCdfd2tsdElkJyBpbiBjdHggfHwgJ19sZXB1c1dvcmtsZXRIYXNoJyBpbiBjdHgpO1xufVxuXG5jb25zdCB3b3JrbGV0Q2FjaGUgPSAvKiNfX1BVUkVfXyovIG5ldyBXZWFrTWFwPG9iamVjdCwgQ2xvc3VyZVZhbHVlVHlwZSB8ICgoLi4uYXJnczogdW5rbm93bltdKSA9PiB1bmtub3duKT4oKTtcblxuZnVuY3Rpb24gdHJhbnNmb3JtV29ya2xldChjdHg6IFdvcmtsZXQsIGlzV29ya2xldDogdHJ1ZSk6ICguLi5hcmdzOiB1bmtub3duW10pID0+IHVua25vd247XG5mdW5jdGlvbiB0cmFuc2Zvcm1Xb3JrbGV0KFxuICBjdHg6IENsb3N1cmVWYWx1ZVR5cGVbXSxcbiAgaXNXb3JrbGV0OiBmYWxzZSxcbik6IENsb3N1cmVWYWx1ZVR5cGVbXTtcblxuZnVuY3Rpb24gdHJhbnNmb3JtV29ya2xldChcbiAgY3R4OiBDbG9zdXJlVmFsdWVUeXBlLFxuICBpc1dvcmtsZXQ6IGJvb2xlYW4sXG4pOiBDbG9zdXJlVmFsdWVUeXBlIHwgKCguLi5hcmdzOiB1bmtub3duW10pID0+IHVua25vd24pIHtcbiAgLyogdjggaWdub3JlIG5leHQgMyAqL1xuICBpZiAodHlwZW9mIGN0eCAhPT0gJ29iamVjdCcgfHwgY3R4ID09PSBudWxsKSB7XG4gICAgcmV0dXJuIGN0eDtcbiAgfVxuXG4gIGlmIChpc1dvcmtsZXQpIHtcbiAgICBjb25zdCByZXMgPSB3b3JrbGV0Q2FjaGUuZ2V0KGN0eCk7XG4gICAgaWYgKHJlcykge1xuICAgICAgcmV0dXJuIHJlcztcbiAgICB9XG4gIH1cblxuICBjb25zdCB3b3JrbGV0ID0gdHJhbnNmb3JtV29ya2xldElubmVyKHsgbWFpbjogY3R4IH0sIDAsIGN0eCkgYXMgeyBtYWluOiBDbG9zdXJlVmFsdWVUeXBlIH07XG5cbiAgaWYgKGlzV29ya2xldCkge1xuICAgIHdvcmtsZXRDYWNoZS5zZXQoY3R4LCB3b3JrbGV0Lm1haW4pO1xuICB9XG5cbiAgcmV0dXJuIHdvcmtsZXQubWFpbjtcbn1cblxuY29uc3QgdHJhbnNmb3JtV29ya2xldElubmVyID0gKFxuICB2YWx1ZTogQ2xvc3VyZVZhbHVlVHlwZSxcbiAgZGVwdGg6IG51bWJlcixcbiAgY3R4OiB1bmtub3duLFxuKTogQ2xvc3VyZVZhbHVlVHlwZSA9PiB7XG4gIGNvbnN0IGxpbWl0ID0gMTAwMDtcbiAgaWYgKCsrZGVwdGggPj0gbGltaXQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0RlcHRoIG9mIHZhbHVlIGV4Y2VlZHMgbGltaXQgb2YgJyArIGxpbWl0ICsgJy4nKTtcbiAgfVxuICAvKiB2OCBpZ25vcmUgbmV4dCAzICovXG4gIGlmICh0eXBlb2YgdmFsdWUgIT09ICdvYmplY3QnIHx8IHZhbHVlID09PSBudWxsKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG4gIGxldCBvYmogPSB2YWx1ZSBhcyBSZWNvcmQ8c3RyaW5nLCBDbG9zdXJlVmFsdWVUeXBlPjtcblxuICBmb3IgKGNvbnN0IGtleSBpbiBvYmopIHtcbiAgICBjb25zdCBzdWJPYmo6IENsb3N1cmVWYWx1ZVR5cGUgPSBvYmpba2V5XTtcbiAgICBpZiAodHlwZW9mIHN1Yk9iaiAhPT0gJ29iamVjdCcgfHwgc3ViT2JqID09PSBudWxsKSB7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG5cbiAgICAvLyBBIE1haW5UaHJlYWRPYmplY3QgaW5pdGlhbGl6YXRpb24gcGF5bG9hZCBpcyB1c2VyIGRhdGEuIFJlc29sdmUgdGhlXG4gICAgLy8gdHlwZWQgZGVzY3JpcHRvciBiZWZvcmUgd2Fsa2luZyBpdCBzbyBwYXlsb2FkIHByb3BlcnRpZXMgdGhhdCByZXNlbWJsZVxuICAgIC8vIHdvcmtsZXQgbWV0YWRhdGEgcmVtYWluIHVudG91Y2hlZC4gTGVnYWN5IE1haW5UaHJlYWRSZWYgZGVzY3JpcHRvcnMgcmV0YWluXG4gICAgLy8gdGhlIGV4aXN0aW5nIHJlY3Vyc2l2ZSBwYXRoLlxuICAgIGlmIChpc1JlYWxpemVkTWFpblRocmVhZE9iamVjdChzdWJPYmopKSB7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKGlzTWFpblRocmVhZE9iamVjdERlc2NyaXB0b3Ioc3ViT2JqKSkge1xuICAgICAgb2JqID0gcmVwbGFjZUNhcHR1cmVkUHJvcGVydHkob2JqLCB2YWx1ZSwga2V5LCBnZXRGcm9tV29ya2xldFJlZk1hcChzdWJPYmopKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGlmICgvKiogaXNFdmVudFRhcmdldCAqLyAnZWxlbWVudFJlZnB0cicgaW4gc3ViT2JqKSB7XG4gICAgICBvYmpba2V5XSA9IG5ldyBFbGVtZW50KHN1Yk9iai5lbGVtZW50UmVmcHRyIGFzIEVsZW1lbnROb2RlKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH0gZWxzZSBpZiAoc3ViT2JqIGluc3RhbmNlb2YgRWxlbWVudCkge1xuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgY29uc3QgdHJhbnNmb3JtZWRTdWJPYmogPSB0cmFuc2Zvcm1Xb3JrbGV0SW5uZXIoc3ViT2JqLCBkZXB0aCwgY3R4KSBhcyBSZWNvcmQ8c3RyaW5nLCBDbG9zdXJlVmFsdWVUeXBlPjtcblxuICAgIGNvbnN0IGlzV29ya2xldFJlZiA9ICdfd3ZpZCcgaW4gKHN1Yk9iaiBhcyBvYmplY3QpO1xuICAgIGlmIChpc1dvcmtsZXRSZWYpIHtcbiAgICAgIG9ialtrZXldID0gZ2V0RnJvbVdvcmtsZXRSZWZNYXAoXG4gICAgICAgIHN1Yk9iaiBhcyB1bmtub3duIGFzIFdvcmtsZXRSZWZJbXBsPHVua25vd24+LFxuICAgICAgKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBpc1dvcmtsZXQgPSAnX3drbHRJZCcgaW4gc3ViT2JqO1xuICAgIGlmIChpc1dvcmtsZXQpIHtcbiAgICAgIGNvbnN0IGlzUm9vdFdvcmtsZXQgPSBzdWJPYmogPT09IGN0eDtcbiAgICAgIGNvbnN0IGJvdW5kQ3R4ID0geyAuLi50cmFuc2Zvcm1lZFN1Yk9iaiB9O1xuICAgICAgLy8gS2VlcCB0aGUgb3JpZ2luYWwgY29udGV4dCBjb2xsZWN0aWJsZS4gUHJpbUpTIHRyYWNlcyBXZWFrTWFwIHZhbHVlcyBldmVuXG4gICAgICAvLyB3aGVuIHRoZWlyIGtleXMgYXJlIG90aGVyd2lzZSB1bnJlYWNoYWJsZSwgc28gdGhlIGNhY2hlZCBmdW5jdGlvbiBtdXN0IG5vdCBwb2ludCBiYWNrIHRvIGl0cyBrZXkuXG4gICAgICBjb25zdCBib3VuZFdvcmtsZXQ6ICgoLi4uYXJnczogdW5rbm93bltdKSA9PiB1bmtub3duKSAmIHsgYm91bmRDdHg/OiBvYmplY3QgfSA9IGx5bnhXb3JrbGV0SW1wbFxuICAgICAgICAuX3dvcmtsZXRNYXBbKHN1Yk9iaiBhcyBXb3JrbGV0KS5fd2tsdElkXSFcbiAgICAgICAgLmJpbmQoYm91bmRDdHgpO1xuICAgICAgaWYgKHRyYW5zZm9ybWVkU3ViT2JqICE9PSBzdWJPYmogJiYgb2JqID09PSB2YWx1ZSAmJiBvYmogIT09IGN0eCkgb2JqID0gY29weUFjY2Vzc29yQ2FwdHVyZShvYmopO1xuICAgICAgb2JqID0gcmVwbGFjZUNhcHR1cmVkUHJvcGVydHkob2JqLCB2YWx1ZSwga2V5LCBib3VuZFdvcmtsZXQpO1xuICAgICAgaWYgKCFpc1Jvb3RXb3JrbGV0KSB7XG4gICAgICAgIC8vIEh5ZHJhdGlvbiBuZWVkcyB0aGUgc2FtZSBjb250ZXh0IHRoYXQgdGhlIGZ1bmN0aW9uIGFscmVhZHkgb3ducyB0aHJvdWdoIGJpbmQoKS5cbiAgICAgICAgLy8gVGhlIG9yaWdpbmFsIG5lc3RlZCBjb250ZXh0IGNhbiBkaXNhcHBlYXIgYWZ0ZXIgaXRzIHBhcmVudCByZXBsYWNlcyBpdCB3aXRoIHRoaXMgZnVuY3Rpb24uXG4gICAgICAgIGJvdW5kV29ya2xldC5ib3VuZEN0eCA9IGJvdW5kQ3R4O1xuICAgICAgfVxuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmICh0cmFuc2Zvcm1lZFN1Yk9iaiAhPT0gc3ViT2JqKSB7XG4gICAgICAvLyBUaGUgcm9vdCBjb250ZXh0IGlzIHJ1bnRpbWUtb3duZWQ6IGh5ZHJhdGlvbiBtdXN0IHNlZSBpdHMgY2FwdHVyZWQgY29weS5cbiAgICAgIGlmIChvYmogPT09IHZhbHVlICYmIG9iaiAhPT0gY3R4KSBvYmogPSBjb3B5QWNjZXNzb3JDYXB0dXJlKG9iaik7XG4gICAgICBvYmogPSByZXBsYWNlQ2FwdHVyZWRQcm9wZXJ0eShvYmosIHZhbHVlLCBrZXksIHRyYW5zZm9ybWVkU3ViT2JqKTtcbiAgICB9XG4gICAgY29uc3QgaXNKc0ZuID0gJ19qc0ZuSWQnIGluIHN1Yk9iajtcbiAgICBpZiAoaXNKc0ZuKSB7XG4gICAgICAoc3ViT2JqIGFzIFJlY29yZDxzdHJpbmcsIENsb3N1cmVWYWx1ZVR5cGU+KVsnX2V4ZWNJZCddID0gKGN0eCBhcyBXb3JrbGV0KS5fZXhlY0lkO1xuICAgICAgbHlueFdvcmtsZXRJbXBsLl9qc0Z1bmN0aW9uTGlmZWN5Y2xlTWFuYWdlcj8uYWRkUmVmKFxuICAgICAgICAoY3R4IGFzIFdvcmtsZXQpLl9leGVjSWQhLFxuICAgICAgICBzdWJPYmosXG4gICAgICApO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICB9XG4gIHJldHVybiBvYmo7XG59O1xuXG5mdW5jdGlvbiByZXBsYWNlQ2FwdHVyZWRQcm9wZXJ0eShcbiAgb2JqOiBSZWNvcmQ8c3RyaW5nLCBDbG9zdXJlVmFsdWVUeXBlPixcbiAgc291cmNlOiBvYmplY3QsXG4gIGtleTogc3RyaW5nLFxuICB2YWx1ZTogQ2xvc3VyZVZhbHVlVHlwZSxcbik6IFJlY29yZDxzdHJpbmcsIENsb3N1cmVWYWx1ZVR5cGU+IHtcbiAgY29uc3QgZGVzY3JpcHRvciA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3Iob2JqLCBrZXkpO1xuICBpZiAoZGVzY3JpcHRvcj8uZ2V0KSB7XG4gICAgLy8gR2V0dGVycyBjYW4gcmVmcmVzaCBoYW5kbGVzIG9yIG1ldGhvZCByZWNlaXZlcnMuIE1hdGVyaWFsaXplIHRoZSBjYXB0dXJlZFxuICAgIC8vIHZhbHVlIHdpdGhvdXQgY29uc3VtaW5nIHRoZSBzb3VyY2UgZ2V0dGVyIG9yIGludm9raW5nIGl0cyBzZXR0ZXIuXG4gICAgY29uc3QgY2FwdHVyZWREZXNjcmlwdG9yID0ge1xuICAgICAgdmFsdWUsXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IGRlc2NyaXB0b3IuZW51bWVyYWJsZSEsXG4gICAgICBjb25maWd1cmFibGU6IGRlc2NyaXB0b3IuY29uZmlndXJhYmxlISxcbiAgICB9O1xuICAgIGlmIChvYmogPT09IHNvdXJjZSB8fCAhZGVzY3JpcHRvci5jb25maWd1cmFibGUpIHtcbiAgICAgIC8vIFJlcGxhY2UgYmVmb3JlIGRlZmluaW5nIHRoZSBjb3B5LCBpbmNsdWRpbmcgbm9uLWNvbmZpZ3VyYWJsZSBnZXR0ZXJzLlxuICAgICAgY29uc3QgZGVzY3JpcHRvcnMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyhvYmopO1xuICAgICAgZGVzY3JpcHRvcnNba2V5XSA9IGNhcHR1cmVkRGVzY3JpcHRvcjtcbiAgICAgIHJldHVybiBjb3B5QWNjZXNzb3JDYXB0dXJlKG9iaiwgZGVzY3JpcHRvcnMpO1xuICAgIH1cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkob2JqLCBrZXksIGNhcHR1cmVkRGVzY3JpcHRvcik7XG4gIH0gZWxzZSB7XG4gICAgb2JqW2tleV0gPSB2YWx1ZTtcbiAgfVxuICByZXR1cm4gb2JqO1xufVxuXG5mdW5jdGlvbiBjb3B5QWNjZXNzb3JDYXB0dXJlKFxuICBvYmo6IFJlY29yZDxzdHJpbmcsIENsb3N1cmVWYWx1ZVR5cGU+LFxuICBkZXNjcmlwdG9yczogUHJvcGVydHlEZXNjcmlwdG9yTWFwID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMob2JqKSxcbik6IFJlY29yZDxzdHJpbmcsIENsb3N1cmVWYWx1ZVR5cGU+IHtcbiAgLy8gQ29weSBkZXNjcmlwdG9ycyB3aXRob3V0IGV2YWx1YXRpbmcgZ2V0dGVycyBhIHNlY29uZCB0aW1lLiBBcnJheSBhbmNlc3RvcnNcbiAgLy8gcmV0YWluIHRoZWlyIGFycmF5IGlkZW50aXR5IHdoZW4gYSBuZXN0ZWQgYWNjZXNzb3IgcmVxdWlyZXMgYSBjYXB0dXJlZCBjb3B5LlxuICByZXR1cm4gT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoXG4gICAgQXJyYXkuaXNBcnJheShvYmopXG4gICAgICA/IFtdXG4gICAgICA6IE9iamVjdC5jcmVhdGUoT2JqZWN0LmdldFByb3RvdHlwZU9mKG9iaikgYXMgb2JqZWN0IHwgbnVsbCkgYXMgUmVjb3JkPHN0cmluZywgQ2xvc3VyZVZhbHVlVHlwZT4sXG4gICAgZGVzY3JpcHRvcnMsXG4gICkgYXMgUmVjb3JkPHN0cmluZywgQ2xvc3VyZVZhbHVlVHlwZT47XG59XG5cbmZ1bmN0aW9uIGlzTWFpblRocmVhZE9iamVjdERlc2NyaXB0b3IoXG4gIHZhbHVlOiBvYmplY3QsXG4pOiB2YWx1ZSBpcyBXb3JrbGV0UmVmSW1wbDx1bmtub3duPiB7XG4gIGNvbnN0IGRlc2NyaXB0b3IgPSB2YWx1ZSBhcyBQYXJ0aWFsPFdvcmtsZXRSZWZJbXBsPHVua25vd24+PjtcbiAgcmV0dXJuIHR5cGVvZiBkZXNjcmlwdG9yLl93dmlkID09PSAnbnVtYmVyJ1xuICAgICYmIHR5cGVvZiBkZXNjcmlwdG9yLl90eXBlID09PSAnc3RyaW5nJ1xuICAgICYmIGRlc2NyaXB0b3IuX3R5cGUgIT09ICdtYWluLXRocmVhZCc7XG59XG5leHBvcnQgeyBpbml0V29ya2xldCB9O1xuIiwiLy8gQ29weXJpZ2h0IDIwMjQgVGhlIEx5bnggQXV0aG9ycy4gQWxsIHJpZ2h0cyByZXNlcnZlZC5cbi8vIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSBWZXJzaW9uIDIuMCB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGVcbi8vIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbmltcG9ydCB7IGluaXRBcGlFbnYgfSBmcm9tICcuL2FwaS9seW54QXBpLmpzJztcbmltcG9ydCB7IGluaXRFdmVudExpc3RlbmVycyB9IGZyb20gJy4vbGlzdGVuZXJzLmpzJztcbmltcG9ydCB7IGluaXRXb3JrbGV0IH0gZnJvbSAnLi93b3JrbGV0UnVudGltZS5qcyc7XG5cbmlmIChnbG9iYWxUaGlzLmx5bnhXb3JrbGV0SW1wbCA9PT0gdW5kZWZpbmVkKSB7XG4gIGluaXRXb3JrbGV0KCk7XG4gIGluaXRBcGlFbnYoKTtcbiAgaW5pdEV2ZW50TGlzdGVuZXJzKCk7XG59XG4iXSwibmFtZXMiOlsiQW5pbWF0aW9uIiwiX19FbGVtZW50QW5pbWF0ZSIsImVmZmVjdCIsIktleWZyYW1lRWZmZWN0IiwidGFyZ2V0Iiwia2V5ZnJhbWVzIiwib3B0aW9ucyIsIlRSQUNFX0xJTUlUIiwiREVGQVVMVF9GTFVTSF9MSU1JVCIsInRyYWNlIiwiZmx1c2hDb3VudEluV2luZG93IiwicmVzZXRTY2hlZHVsZWQiLCJ0cmlwcGVkRXJyb3IiLCJwdXNoVHJhY2UiLCJtYXJrZXIiLCJjb21wcmVzc1RyYWNlIiwibWFya2VycyIsIm91dCIsInByZXYiLCJjb3VudCIsImkiLCJjdXIiLCJtYWluVGhyZWFkRmx1c2hMb29wTWFyayIsIm1haW5UaHJlYWRGbHVzaExvb3BPbkZsdXNoTWljcm90YXNrIiwic2V0VGltZW91dCIsIm1haW5UaHJlYWRGbHVzaExvb3BSZXNldCIsImxpbWl0IiwidHJhY2VUZXh0IiwiRXJyb3IiLCJtYWluVGhyZWFkRmx1c2hMb29wUmVwb3J0IiwiZXJyb3IiLCJpc1Nka1ZlcnNpb25HdCIsIm1ham9yIiwibWlub3IiLCJfU3lzdGVtSW5mb19seW54U2RrVmVyc2lvbiIsImx5bnhTZGtWZXJzaW9uIiwidmVyc2lvbiIsIk51bWJlciIsIndpbGxGbHVzaCIsInNob3VsZEZsdXNoIiwic2V0U2hvdWxkRmx1c2giLCJ2YWx1ZSIsIkVsZW1lbnQiLCJuYW1lIiwiX19TZXRBdHRyaWJ1dGUiLCJfX0FkZElubGluZVN0eWxlIiwic3R5bGVzIiwiT2JqZWN0Iiwia2V5IiwiYXR0cmlidXRlTmFtZSIsIl9fR2V0QXR0cmlidXRlQnlOYW1lIiwiX19HZXRBdHRyaWJ1dGVOYW1lcyIsInNlbGVjdG9yIiwicmVmIiwiX19RdWVyeVNlbGVjdG9yIiwiX19RdWVyeVNlbGVjdG9yQWxsIiwiZWxlbWVudCIsIl9fR2V0Q29tcHV0ZWRTdHlsZUJ5S2V5Iiwibm9ybWFsaXplZE9wdGlvbnMiLCJtZXRob2ROYW1lIiwicGFyYW1zIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJfX0ludm9rZVVJTWV0aG9kIiwicmVzIiwiSlNPTiIsIl9fRmx1c2hFbGVtZW50VHJlZSIsIlBhZ2VFbGVtZW50IiwiX1BhZ2VFbGVtZW50IiwiX19HZXRQYWdlRWxlbWVudCIsInF1ZXJ5U2VsZWN0b3IiLCJjc3NTZWxlY3RvciIsInBhZ2VFbGVtZW50IiwicXVlcnlTZWxlY3RvckFsbCIsImluaXRBcGlFbnYiLCJfbHlueF9jbGVhckludGVydmFsIiwibHlueCIsImdsb2JhbFRoaXMiLCJyZXF1ZXN0QW5pbWF0aW9uRnJhbWUiLCJjYWxsYmFjayIsInJ1blJ1bk9uTWFpblRocmVhZFRhc2siLCJ0YXNrIiwicmVzb2x2ZUlkIiwicmV0dXJuVmFsdWUiLCJydW5Xb3JrbGV0IiwiV29ya2xldEV2ZW50cyIsIm1haW5UaHJlYWRPYmplY3REZWZpbml0aW9ucyIsIk1hcCIsInJlYWxpemVkTWFpblRocmVhZE9iamVjdFR5cGVzIiwiV2Vha01hcCIsInJlZ2lzdGVyTWFpblRocmVhZE9iamVjdFR5cGUiLCJ0eXBlIiwiY3JlYXRlIiwicmVnaXN0ZXJlZCIsImdldEZhY3RvcnlSZWdpc3RyYXRpb25JZGVudGl0eSIsImZhY3RvcnkiLCJGdW5jdGlvbiIsInJlc29sdmVGYWN0b3J5RnVuY3Rpb24iLCJseW54V29ya2xldEltcGwiLCJnZXRNYWluVGhyZWFkT2JqZWN0RmFjdG9yeSIsImRlZmluaXRpb24iLCJfZGVmaW5pdGlvbiIsImNyZWF0ZU1haW5UaHJlYWRPYmplY3QiLCJyZWZJbXBsIiwiaXNSZWFsaXplZE1haW5UaHJlYWRPYmplY3QiLCJhc3NlcnRDb21wYXRpYmxlTWFpblRocmVhZE9iamVjdCIsImhhbmRsZSIsIm9wZXJhdGlvbiIsImFjdHVhbFR5cGUiLCJleHBlY3RlZFR5cGUiLCJpbml0TWFpblRocmVhZE9iamVjdHMiLCJwcm9maWxlIiwic2xpY2VOYW1lIiwiZiIsIl9jb25zb2xlIiwiX2NvbnNvbGUxIiwiaW1wbCIsImluaXRXb3JrbGV0UmVmIiwidXBkYXRlV29ya2xldFJlZiIsInVwZGF0ZVdvcmtsZXRSZWZJbml0VmFsdWVDaGFuZ2VzIiwiY2xlYXJGaXJzdFNjcmVlbldvcmtsZXRSZWZNYXAiLCJjcmVhdGVXb3JrbGV0UmVmIiwiaWQiLCJjcmVhdGVXb3JrbGV0VmFsdWUiLCJpc011dGFibGVDZWxsIiwiaXNIeWRyYXRlZFdvcmtsZXRWYWx1ZSIsImFzc2VydENvbXBhdGlibGVXb3JrbGV0VmFsdWUiLCJhY3R1YWxLaW5kIiwiZXhwZWN0ZWRLaW5kIiwiZ2V0RnJvbVdvcmtsZXRSZWZNYXAiLCJfaW1wbF9fZmlyc3RTY3JlZW5Xb3JrbGV0UmVmTWFwIiwiX2lkIiwidW5kZWZpbmVkIiwicmVtb3ZlVmFsdWVGcm9tV29ya2xldFJlZk1hcCIsImh5ZHJhdGVXb3JrbGV0VmFsdWUiLCJwYXRjaCIsImZpcnN0RXJyb3IiLCJoYXNFcnJvciIsImV4aXN0aW5nIiwiaW5pdEV2ZW50TGlzdGVuZXJzIiwianNDb250ZXh0IiwiZXZlbnQiLCJkYXRhIiwiaW5pdFJ1bk9uQmFja2dyb3VuZERlbGF5IiwiY2xlYXJEZWxheWVkQmFja2dyb3VuZEZ1bmN0aW9ucyIsImRlbGF5UnVuT25CYWNrZ3JvdW5kIiwicnVuRGVsYXllZEJhY2tncm91bmRGdW5jdGlvbnMiLCJmbk9iaiIsIl9mbk9iaiIsImRlbGF5SW5kaWNlcyIsImRldGFpbHMiLCJpbml0RXZlbnREZWxheSIsInJ1bkRlbGF5ZWRXb3JrbGV0IiwiY2xlYXJEZWxheWVkV29ya2xldHMiLCJkZWxheUV4ZWNVbnRpbEpzUmVhZHkiLCJoYXNoIiwibWFwIiwicGFyYW1WZWMiLCJ3b3JrbGV0IiwicGFyYW1zVmVjIiwibGVmdFBhcmFtc1ZlYyIsIl9maXJzdFBhcmFtX2N1cnJlbnRUYXJnZXQiLCJmaXJzdFBhcmFtIiwiaW5pdEVvbUltcGwiLCJFdmVudFJlc3VsdCIsImlzRXZlbnRPYmplY3QiLCJjdHgiLCJBcnJheSIsIlJ1bldvcmtsZXRTb3VyY2UiLCJhZGRFdmVudE1ldGhvZHNJZk5lZWRlZCIsImV2ZW50Q3R4IiwiZXZlbnRPYmoiLCJfZXZlbnRDdHhfX2V2ZW50UmV0dXJuUmVzdWx0IiwiaHlkcmF0ZUN0eCIsImZpcnN0U2NyZWVuQ3R4IiwiaHlkcmF0ZUN0eEltcGwiLCJleGVjSWQiLCJjdHhPYmoiLCJmaXJzdFNjcmVlbkN0eE9iaiIsImlzVHlwZWRXb3JrbGV0UmVmRGVzY3JpcHRvciIsImh5ZHJhdGVXb3JrbGV0VmFsdWVIYW5kbGUiLCJoeWRyYXRlTWFpblRocmVhZFJlZiIsImh5ZHJhdGVEZWxheVJ1bk9uQmFja2dyb3VuZFRhc2tzIiwiZmlyc3RTY3JlZW5WYWx1ZSIsImRlc2NyaXB0b3IiLCJyZWZJZCIsImZuT2JqcyIsImZpcnN0U2NyZWVuRm5PYmpzIiwiZm5OYW1lIiwiZmlyc3RTY3JlZW5Gbk9iaiIsImluZGV4IiwiSnNGdW5jdGlvbkxpZmVjeWNsZU1hbmFnZXIiLCJvYmpUb1JlZiIsIl90aGlzX2V4ZWNJZFJlZkNvdW50X2dldCIsInJjIiwiU2V0IiwiV2Vha1NldCIsIkZpbmFsaXphdGlvblJlZ2lzdHJ5IiwiaXNSdW5PbkJhY2tncm91bmRFbmFibGVkIiwiaW5pdFdvcmtsZXQiLCJyZWdpc3RlcldvcmtsZXQiLCJfdHlwZSIsInZhbGlkYXRlV29ya2xldCIsImZpcnN0IiwidCIsIlN0cmluZyIsInJ1bldvcmtsZXRJbXBsIiwidHJhbnNmb3JtV29ya2xldCIsInBhcmFtc18iLCJoYXNFdmVudE1ldGhvZHMiLCJyZXN1bHQiLCJ3b3JrbGV0Q2FjaGUiLCJpc1dvcmtsZXQiLCJ0cmFuc2Zvcm1Xb3JrbGV0SW5uZXIiLCJkZXB0aCIsIm9iaiIsInN1Yk9iaiIsImlzTWFpblRocmVhZE9iamVjdERlc2NyaXB0b3IiLCJyZXBsYWNlQ2FwdHVyZWRQcm9wZXJ0eSIsInRyYW5zZm9ybWVkU3ViT2JqIiwiaXNXb3JrbGV0UmVmIiwiaXNSb290V29ya2xldCIsImJvdW5kQ3R4IiwiYm91bmRXb3JrbGV0IiwiY29weUFjY2Vzc29yQ2FwdHVyZSIsImlzSnNGbiIsIl9seW54V29ya2xldEltcGxfX2pzRnVuY3Rpb25MaWZlY3ljbGVNYW5hZ2VyIiwic291cmNlIiwiY2FwdHVyZWREZXNjcmlwdG9yIiwiZGVzY3JpcHRvcnMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0lBWU8sTUFBTUE7UUFXSixTQUFlO1lBRXBCLE9BQU9DLGlCQUFpQixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Z0JBaEI3QztnQkFnQnlFLElBQUksQ0FBQyxFQUFFO2FBQUM7UUFDMUY7UUFFTyxRQUFjO1lBRW5CLE9BQU9BLGlCQUFpQixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Z0JBdEI5QztnQkFzQnlFLElBQUksQ0FBQyxFQUFFO2FBQUM7UUFDekY7UUFFTyxPQUFhO1lBRWxCLE9BQU9BLGlCQUFpQixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Z0JBNUIvQztnQkE0QnlFLElBQUksQ0FBQyxFQUFFO2FBQUM7UUFDeEY7UUFFUSxRQUFjO1lBRXBCLE9BQU9BLGlCQUFpQixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Z0JBbEM5QztnQkFvQ0osSUFBSSxDQUFDLEVBQUU7Z0JBQ1AsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTO2dCQUNyQixJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU87YUFDcEI7UUFDSDtRQTdCQSxZQUFZQyxNQUFzQixDQUFFO1lBSHBDLHVCQUFnQixVQUFoQjtZQUNBLHVCQUFnQixNQUFoQjtZQUdFLElBQUksQ0FBQyxNQUFNLEdBQUdBO1lBQ2QsSUFBSSxDQUFDLEVBQUUsR0FBRywrQkFBK0JGLFVBQVUsS0FBSztZQUN4RCxJQUFJLENBQUMsS0FBSztRQUNaO0lBMEJGO0lBbENFLGlCQURXQSxXQUNKLFNBQVE7Ozs7Ozs7Ozs7O0lDUlYsTUFBTUc7UUFLWCxZQUNFQyxNQUFlLEVBQ2ZDLFNBQTRDLEVBQzVDQyxPQUF3QyxDQUN4QztZQVJGLDZCQUFnQixVQUFoQjtZQUNBLDZCQUFnQixhQUFoQjtZQUNBLDZCQUFnQixXQUFoQjtZQU9FLElBQUksQ0FBQyxNQUFNLEdBQUdGO1lBQ2QsSUFBSSxDQUFDLFNBQVMsR0FBR0M7WUFDakIsSUFBSSxDQUFDLE9BQU8sR0FBR0M7UUFDakI7SUFDRjtJQ2ZBLE1BQU1DLGNBQWM7SUFDcEIsTUFBTUMsc0JBQXNCO0lBRTVCLElBQUlDLFFBQWtCLEVBQUU7SUFFeEIsSUFBSUMscUJBQXFCO0lBQ3pCLElBQUlDLGlCQUFpQjtJQUNyQixJQUFJQyxlQUE2QjtJQUVqQyxTQUFTQyxVQUFVQyxNQUFjO1FBQy9CTCxNQUFNLElBQUksQ0FBQ0s7UUFDWCxJQUFJTCxNQUFNLE1BQU0sR0FBR0YsYUFDakJFLFFBQVFBLE1BQU0sS0FBSyxDQUFDQSxNQUFNLE1BQU0sR0FBR0Y7SUFFdkM7SUFFQSxTQUFTUSxjQUFjQyxPQUFpQjtRQUN0QyxJQUFJQSxBQUFtQixNQUFuQkEsUUFBUSxNQUFNLEVBQVEsT0FBTztRQUNqQyxNQUFNQyxNQUFnQixFQUFFO1FBRXhCLElBQUlDLE9BQU9GLE9BQU8sQ0FBQ0EsUUFBUSxNQUFNLEdBQUcsRUFBRTtRQUN0QyxJQUFJRyxRQUFRO1FBRVosSUFBSyxJQUFJQyxJQUFJSixRQUFRLE1BQU0sR0FBRyxHQUFHSSxLQUFLLEdBQUdBLElBQUs7WUFDNUMsTUFBTUMsTUFBTUwsT0FBTyxDQUFDSSxFQUFFO1lBQ3RCLElBQUlDLFFBQVFILE1BQU07Z0JBQ2hCQztnQkFDQTtZQUNGO1lBQ0FGLElBQUksSUFBSSxDQUFDRSxBQUFVLE1BQVZBLFFBQWNELE9BQU8sR0FBR0EsS0FBSyxFQUFFLEVBQUVDLE9BQU87WUFDakRELE9BQU9HO1lBQ1BGLFFBQVE7UUFDVjtRQUNBRixJQUFJLElBQUksQ0FBQ0UsQUFBVSxNQUFWQSxRQUFjRCxPQUFPLEdBQUdBLEtBQUssRUFBRSxFQUFFQyxPQUFPO1FBQ2pELE9BQU9GLElBQUksSUFBSSxDQUFDO0lBQ2xCO0lBRU8sU0FBU0ssd0JBQXdCUixNQUFjO1FBRWxERCxVQUFVQztJQUVkO0lBRU8sU0FBU1M7UUFHZCxJQUFJWCxjQUFjLE9BQU9BO1FBRXpCLElBQUksQ0FBQ0QsZ0JBQWdCO1lBQ25CQSxpQkFBaUI7WUFDakJhLFdBQVc7Z0JBQ1RDO1lBQ0YsR0FBRztRQUNMO1FBRUFmO1FBQ0EsTUFBTWdCLFFBQVFsQjtRQUNkLElBQUlFLHFCQUFxQmdCLE9BQU87WUFDOUIsTUFBTUMsWUFBWVosY0FBY047WUFDaENHLGVBQWUsSUFBSWdCLE1BQ2pCLENBQUMsaUVBQWlFLEVBQUVsQixtQkFBbUIsK0JBQStCLEVBQUVnQixNQUFNLFVBQVUsRUFBRUMsV0FBVztZQUV2SixPQUFPZjtRQUNUO1FBRUEsT0FBTztJQUNUO0lBRU8sU0FBU2lCLDBCQUEwQkMsS0FBWTtRQUdsRE4sV0FBVztZQUNULE1BQU1NO1FBQ1IsR0FBRztJQUVQO0lBRU8sU0FBU0w7UUFDZGhCLFFBQVEsRUFBRTtRQUNWQyxxQkFBcUI7UUFDckJDLGlCQUFpQjtRQUNqQkMsZUFBZTtJQUNqQjtJQ25GTyxTQUFTbUIsZUFBZUMsS0FBYSxFQUFFQyxLQUFhO1lBQzFCQztRQUEvQixNQUFNQyxpQkFBQUEsUUFBeUJELENBQUFBLDZCQUFBQSxXQUFXLGNBQWMsQUFBRCxJQUF4QkEsNkJBQTZCO1FBQzVELE1BQU1FLFVBQVVELGVBQWUsS0FBSyxDQUFDO1FBQ3JDLE9BQ0VFLE9BQU9ELE9BQU8sQ0FBQyxFQUFFLElBQUlKLFNBQ2pCSyxPQUFPRCxPQUFPLENBQUMsRUFBRSxLQUFLSixTQUFTSyxPQUFPRCxPQUFPLENBQUMsRUFBRSxJQUFJSDtJQUU1RDs7Ozs7Ozs7Ozs7SUNFQSxJQUFJSyxZQUFZO0lBQ2hCLElBQUlDLGNBQWM7SUFFWCxTQUFTQyxlQUFlQyxLQUFjO1FBQzNDRixjQUFjRTtJQUNoQjtJQUVPLE1BQU1DO1FBZUosYUFBYUMsSUFBWSxFQUFFRixLQUFjLEVBQVE7WUFHcERuQix3QkFBd0IsQ0FBQyxxQkFBcUIsRUFBRXFCLE1BQU07WUFFeERDLGVBQWUsSUFBSSxDQUFDLE9BQU8sRUFBRUQsTUFBTUY7WUFDbkMsSUFBSSxDQUFDLGdCQUFnQjtRQUN2QjtRQUVPLGlCQUFpQkUsSUFBWSxFQUFFRixLQUFhLEVBQVE7WUFHdkRuQix3QkFBd0IsQ0FBQyx5QkFBeUIsRUFBRXFCLE1BQU07WUFFNURFLGlCQUFpQixJQUFJLENBQUMsT0FBTyxFQUFFRixNQUFNRjtZQUNyQyxJQUFJLENBQUMsZ0JBQWdCO1FBQ3ZCO1FBRU8sbUJBQW1CSyxNQUE4QixFQUFRO1lBRzVEeEIsd0JBQ0UsQ0FBQyxnQ0FBZ0MsRUFBRXlCLE9BQU8sSUFBSSxDQUFDRCxRQUFRLE1BQU0sRUFBRTtZQUduRSxJQUFLLE1BQU1FLE9BQU9GLE9BQ2hCRCxpQkFBaUIsSUFBSSxDQUFDLE9BQU8sRUFBRUcsS0FBS0YsTUFBTSxDQUFDRSxJQUFJO1lBRWpELElBQUksQ0FBQyxnQkFBZ0I7UUFDdkI7UUFFTyxhQUFhQyxhQUFxQixFQUFXO1lBQ2xELE9BQU9DLHFCQUFxQixJQUFJLENBQUMsT0FBTyxFQUFFRDtRQUM1QztRQUVPLG9CQUE4QjtZQUNuQyxPQUFPRSxvQkFBb0IsSUFBSSxDQUFDLE9BQU87UUFDekM7UUFFTyxjQUFjQyxRQUFnQixFQUFrQjtZQUNyRCxNQUFNQyxNQUFNQyxnQkFBZ0IsSUFBSSxDQUFDLE9BQU8sRUFBRUYsVUFBVSxDQUFDO1lBQ3JELE9BQU9DLE1BQU0sSUFBSVgsUUFBUVcsT0FBTztRQUNsQztRQUVPLGlCQUFpQkQsUUFBZ0IsRUFBYTtZQUNuRCxPQUFPRyxtQkFBbUIsSUFBSSxDQUFDLE9BQU8sRUFBRUgsVUFBVSxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUNJLFVBQ2xELElBQUlkLFFBQVFjO1FBRXZCO1FBRU8seUJBQXlCUixHQUFXLEVBQVU7WUFDbkQsSUFBSSxDQUFDakIsZUFBZSxHQUFHLElBQ3JCLE1BQU0sSUFBSUgsTUFDUjtZQUlKLElBQUksQ0FBQ29CLEtBQ0gsTUFBTSxJQUFJcEIsTUFBTTtZQUVsQixPQUFPNkIsd0JBQXdCLElBQUksQ0FBQyxPQUFPLEVBQUVUO1FBQy9DO1FBRU8sUUFDTDNDLFNBQTRDLEVBQzVDQyxPQUFrRCxFQUN2QztZQUNYLE1BQU1vRCxvQkFBb0IsQUFBbUIsWUFBbkIsT0FBT3BELFVBQXVCO2dCQUFFLFVBQVVBO1lBQVEsSUFBSUEsUUFBQUEsVUFBQUEsVUFBVyxDQUFDO1lBQzVGLE9BQU8sSUFBSU4sVUFBVSxJQUFJRyxlQUFlLElBQUksRUFBRUUsV0FBV3FEO1FBQzNEO1FBRU8sT0FDTEMsVUFBa0IsRUFDbEJDLE1BQWdDLEVBQ2Q7WUFHaEJ0Qyx3QkFBd0IsQ0FBQyxlQUFlLEVBQUVxQyxZQUFZO1lBRXhELE9BQU8sSUFBSUUsUUFBUSxDQUFDQyxTQUFTQztnQkFDM0JDLGlCQUNFLElBQUksQ0FBQyxPQUFPLEVBQ1pMLFlBQ0FDLFFBQUFBLFNBQUFBLFNBQVUsQ0FBQyxHQUNYLENBQUNLO29CQUNDLElBQUlBLEFBQWEsTUFBYkEsSUFBSSxJQUFJLEVBQ1ZILFFBQVFHLElBQUksSUFBSTt5QkFFaEJGLE9BQU8sSUFBSW5DLE1BQU0sdUJBQXVCc0MsS0FBSyxTQUFTLENBQUNEO2dCQUUzRDtnQkFFRixJQUFJLENBQUMsZ0JBQWdCO1lBQ3ZCO1FBQ0Y7UUFFUSxtQkFBbUI7WUFDekIsSUFBSTNCLGFBQWEsQ0FBQ0MsYUFDaEI7WUFFRkQsWUFBWTtZQUNQdUIsUUFBUSxPQUFPLEdBQUcsSUFBSSxDQUFDO2dCQUMxQnZCLFlBQVk7Z0JBQ0M7b0JBQ1hoQix3QkFBd0I7b0JBQ3hCLE1BQU1RLFFBQVFQO29CQUNkLElBQUlPLE9BQU87d0JBR1RTLGNBQWM7d0JBQ2RWLDBCQUEwQkM7d0JBQzFCO29CQUNGO2dCQUNGO2dCQUNBcUM7WUFDRjtRQUNGO1FBL0hBLFlBQVlYLE9BQW9CLENBQUU7WUFGbEMsOEJBQWlCLFdBQWpCO1lBTUVULE9BQU8sY0FBYyxDQUFDLElBQUksRUFBRSxXQUFXO2dCQUNyQztvQkFDRSxPQUFPUztnQkFDVDtZQUNGO1FBQ0Y7SUF1SEY7Ozs7Ozs7Ozs7O0lDbEpBLE1BQU1ZO1FBR0osT0FBTyxNQUFNO2dCQUNYQztvQkFBQUEsQUFBQUEsQ0FBQUEsZUFBQUEsV0FBVSxFQUFFLFdBQVcsSUFBdkJBLENBQUFBLGFBQVksV0FBVyxHQUFLQyxrQkFBaUI7WUFDN0MsT0FBT0YsWUFBWSxXQUFXO1FBQ2hDO0lBQ0Y7SUFORSxtQ0FESUEsYUFDVyxlQUFmO0lBUUssU0FBU0csY0FBY0MsV0FBbUI7UUFDL0MsTUFBTUMsY0FBY0wsWUFBWSxHQUFHO1FBQ25DLElBQUksQ0FBQ0ssYUFDSCxPQUFPO1FBRVQsTUFBTWpCLFVBQVVGLGdCQUFnQm1CLGFBQWFELGFBQWEsQ0FBQztRQUMzRCxPQUFPaEIsVUFBVSxJQUFJZCxRQUFRYyxXQUFXO0lBQzFDO0lBRU8sU0FBU2tCLGlCQUFpQkYsV0FBbUI7UUFDbEQsTUFBTUMsY0FBY0wsWUFBWSxHQUFHO1FBQ25DLElBQUksQ0FBQ0ssYUFDSCxPQUFPLEVBQUU7UUFFWCxPQUFPbEIsbUJBQW1Ca0IsYUFBYUQsYUFBYSxDQUFDLEdBQUcsR0FBRyxDQUN6RCxDQUFDaEIsVUFDUSxJQUFJZCxRQUFRYztJQUd6QjtJQzNCQSxTQUFTbUI7WUFhcUJDO1FBWDVCQyxLQUFLLGFBQWEsR0FBR047UUFFckJNLEtBQUssZ0JBQWdCLEdBQUdIO1FBRXhCSSxXQUFXLFVBQVUsR0FBR0QsS0FBSyxVQUFVO1FBRXZDQyxXQUFXLFdBQVcsR0FBR0QsS0FBSyxXQUFXO1FBRXpDQyxXQUFXLFlBQVksR0FBR0QsS0FBSyxZQUFZO1FBRzNDQyxXQUFXLGFBQWEsR0FBRyxRQUFDRixDQUFBQSxzQkFBQUEsS0FBSyxhQUFhLEFBQUQsSUFBakJBLHNCQUFzQkMsS0FBSyxpQkFBaUI7UUFFeEU7WUFFRSxNQUFNRSx3QkFBd0JGLEtBQUsscUJBQXFCO1lBRXhEQSxLQUFLLHFCQUFxQixHQUFHQyxXQUFXLHFCQUFxQixHQUFHLENBQzlERTtnQkFFQSxJQUFJLENBQUNqRCxlQUFlLEdBQUcsS0FDckIsTUFBTSxJQUFJSCxNQUNSO2dCQUdKLE9BQU9tRCxzQkFBc0JDO1lBQy9CO1FBQ0Y7UUFHQUYsV0FBVyxvQkFBb0IsR0FBR0QsS0FBSyxvQkFBb0I7SUFDN0Q7SUNqQ08sU0FBU0ksdUJBQXVCQyxJQUFhLEVBQUV0QixNQUEwQixFQUFFdUIsU0FBaUI7UUFDakcsSUFBSUM7UUFDSixJQUFJO1lBQ0ZBLGNBQWNDLFdBQVdILE1BQU10QjtRQUNqQyxTQUFVO1lBRVJpQixLQUFLLFlBQVksR0FBRyxhQUFhLENBQUM7Z0JBQ2hDLE1BQU1TO2dCQUNOLE1BQU1wQixLQUFLLFNBQVMsQ0FBQztvQkFDbkJpQjtvQkFDQUM7Z0JBQ0Y7WUFDRjtRQUNGO0lBQ0Y7SUNUQSxNQUFNRyw4QkFBOEIsSUFBSUM7SUFHeEMsSUFBSUMsZ0NBQWdDLElBQUlDO0lBRXhDLFNBQVNDLDZCQUNQQyxJQUFZLEVBQ1pDLE1BQXlDO1FBRXpDLElBQUlELEFBQVMsa0JBQVRBLE1BQ0YsTUFBTSxJQUFJaEUsTUFDUjtRQUdKLE1BQU1rRSxhQUFhUCw0QkFBNEIsR0FBRyxDQUFDSztRQUNuRCxJQUFJRSxZQUFZO1lBQ2QsSUFDRUMsK0JBQStCRCxXQUFXLE1BQU0sTUFDMUNDLCtCQUErQkYsU0FFckMsTUFBTSxJQUFJakUsTUFDUixDQUFDLG9EQUFvRCxFQUFFZ0UsS0FBSyx1REFBdUQsQ0FBQztZQUd4SDtRQUNGO1FBQ0FMLDRCQUE0QixHQUFHLENBQUNLLE1BQU07WUFBRUM7UUFBTztJQUNqRDtJQUVBLFNBQVNFLCtCQUNQQyxPQUEwQztRQUUxQyxJQUFJLEFBQW1CLGNBQW5CLE9BQU9BLFNBQ1QsT0FBT0MsU0FBUyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQ0Q7UUFFMUMsT0FBTyxDQUFDLFFBQVEsRUFBRUEsUUFBUSxPQUFPLEVBQUU7SUFDckM7SUFFQSxTQUFTRSx1QkFDUEYsT0FBMEM7UUFFMUMsSUFBSSxBQUFtQixjQUFuQixPQUFPQSxTQUNULE9BQU9BO1FBRVQsSUFBSSxDQUFFLGNBQWFBLE9BQU0sS0FBTSx1QkFBdUJBLFNBQ3BELE1BQU0sSUFBSXBFLE1BQU07UUFJbEIsT0FBT3VFLGdCQUFnQixXQUFXLENBQUNILFFBQVEsT0FBTyxDQUFDO0lBQ3JEO0lBRUEsU0FBU0ksMkJBQ1BDLFVBQXNDO1lBRS9CQyxhQUFBQTtRQUFQLE9BQU8sUUFBQUEsQ0FBQUEsa0JBQUFBLEFBQUFBLENBQUFBLGNBQUFBLFVBQVMsRUFBRSxjQUFjLEFBQUQsSUFBeEJBLGtCQUFBQSxZQUFXLGNBQWMsR0FBS0osdUJBQXVCRyxXQUFXLE1BQU07SUFDL0U7SUFFQSxTQUFTRSx1QkFBdUJDLE9BQWdDO1FBQzlELE1BQU1aLE9BQU9ZLFFBQVEsS0FBSztRQUMxQixNQUFNSCxhQUFhZCw0QkFBNEIsR0FBRyxDQUFDSztRQUNuRCxJQUFJLENBQUNTLFlBQ0gsTUFBTSxJQUFJekUsTUFDUixDQUFDLDBDQUEwQyxFQUFFZ0UsS0FBSywyRkFBMkYsQ0FBQztRQUlsSixNQUFNbkQsUUFBUTJELDJCQUEyQkMsWUFBWUcsUUFBUSxVQUFVO1FBQ3ZFLElBQUksQUFBaUIsWUFBakIsT0FBTy9ELFNBQXNCQSxBQUFVLFNBQVZBLE9BQy9CLE1BQU0sSUFBSWIsTUFBTSxDQUFDLHVCQUF1QixFQUFFZ0UsS0FBSyw2QkFBNkIsQ0FBQztRQUUvRUgsOEJBQThCLEdBQUcsQ0FBQ2hELE9BQU9tRDtRQUN6QyxPQUFPbkQ7SUFDVDtJQUVBLFNBQVNnRSwyQkFBMkJoRSxLQUFhO1FBQy9DLE9BQU9nRCw4QkFBOEIsR0FBRyxDQUFDaEQ7SUFDM0M7SUFFQSxTQUFTaUUsaUNBQ1BDLE1BQStCLEVBQy9CbEUsS0FBYSxFQUNibUUsU0FBK0M7UUFFL0MsTUFBTUMsYUFBYXBCLDhCQUE4QixHQUFHLENBQUNoRDtRQUNyRCxNQUFNcUUsZUFBZUgsT0FBTyxLQUFLO1FBQ2pDLElBQUlFLGVBQWVDLGNBQ2pCLE1BQU0sSUFBSWxGLE1BQ1IsQ0FBQyxzQ0FBc0MsRUFBRWdGLFVBQVUsWUFBWSxFQUFFRCxPQUFPLEtBQUssQ0FBQyxrQ0FBa0MsRUFBRUcsYUFBYSx1Q0FBdUMsRUFBRUQsV0FBVyxFQUFFLENBQUM7SUFHNUw7SUFFQSxTQUFTRTtRQUNQeEIsNEJBQTRCLEtBQUs7UUFDakNFLGdDQUFnQyxJQUFJQztJQUN0QztJQ3hHTyxTQUFTc0IsUUFDZEMsU0FBaUIsRUFDakJDLENBQUs7WUFLSEMsa0JBQUFBO2dCQUFBQSxDQUFBQSxtQkFBQUEsQUFBQUEsQ0FBQUEsV0FBQUEsT0FBTSxFQUFFLE9BQU8sQUFBRCxLQUFkQSxpQkFBQUEsSUFBQUEsQ0FBQUEsVUFBa0JGO1FBQ2xCLElBQUk7WUFDRixPQUFPQztRQUNULFNBQVU7Z0JBQ1JFLHFCQUFBQTtvQkFBQUEsQ0FBQUEsc0JBQUFBLEFBQUFBLENBQUFBLFlBQUFBLE9BQU0sRUFBRSxVQUFVLEFBQUQsS0FBakJBLG9CQUFBQSxJQUFBQSxDQUFBQTtRQUNGO0lBSUo7SUNvQkEsSUFBSUM7SUFDSixTQUFTQztRQUNQUDtRQUNBLE9BQVFNLE9BQU87WUFDYixnQkFBZ0IsQ0FBQztZQU9qQiwyQkFBMkIsQ0FBQztZQUM1QkU7WUFDQUM7WUFDQTdCLDhCQUE0QkE7WUFDNUI4QjtRQUNGO0lBQ0Y7SUFFQSxNQUFNQyxtQkFBbUIsQ0FDdkJDLElBQ0FsRjtRQUVBLE1BQU1ZLE1BQU07WUFDVixTQUFTWjtZQUNULE9BQU9rRjtRQUNUO1FBQ0EsT0FBT3RFO0lBQ1Q7SUFFQSxTQUFTdUUsbUJBQW1CcEIsT0FBZ0M7UUFDMUQsT0FBTyxBQUFDQSxRQUFRLEtBQUssSUFBSUEsQUFBa0Isa0JBQWxCQSxRQUFRLEtBQUssR0FFbENELHVCQUF1QkMsV0FEdkJrQixpQkFBaUJsQixRQUFRLEtBQUssRUFBRUEsUUFBUSxVQUFVO0lBRXhEO0lBRUEsU0FBU3FCLGNBQWNwRixLQUFjO1FBQ25DLE9BQU8sQUFBaUIsWUFBakIsT0FBT0EsU0FBc0JBLEFBQVUsU0FBVkEsU0FDL0IsQUFBeUQsWUFBekQsT0FBUUEsTUFBdUMsS0FBSyxJQUNwRE0sT0FBTyxTQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQ04sT0FBTztJQUNuRDtJQUVBLFNBQVNxRix1QkFBdUJyRixLQUFjO1FBQzVDLE9BQU8sQUFBaUIsWUFBakIsT0FBT0EsU0FBc0JBLEFBQVUsU0FBVkEsU0FDOUJnRSxDQUFBQSwyQkFBMkJoRSxVQUFVb0YsY0FBY3BGLE1BQUs7SUFDaEU7SUFFQSxTQUFTc0YsNkJBQ1BwQixNQUErQixFQUMvQmxFLEtBQWEsRUFDYm1FLFNBQStDO1FBRS9DLElBQUlvQjtRQUNKLElBQUl2QiwyQkFBMkJoRSxRQUM3QnVGLGFBQWE7YUFDUixJQUFJSCxjQUFjcEYsUUFDdkJ1RixhQUFhO1FBRWYsSUFBSSxDQUFDQSxZQUNILE1BQU0sSUFBSXBHLE1BQ1IsQ0FBQyw4QkFBOEIsRUFBRWdGLFVBQVUsWUFBWSxFQUFFRCxPQUFPLEtBQUssQ0FBQyxvREFBb0QsQ0FBQztRQUkvSCxNQUFNRyxlQUFlSCxPQUFPLEtBQUs7UUFDakMsTUFBTXNCLGVBQWUsQUFBQ25CLGdCQUFnQkEsQUFBaUIsa0JBQWpCQSxlQUVsQyxpQkFEQTtRQUVKLElBQUlrQixlQUFlQyxjQUNqQixNQUFNLElBQUlyRyxNQUNSLENBQUMsbUNBQW1DLEVBQUVnRixVQUFVLFlBQVksRUFBRUQsT0FBTyxLQUFLLENBQUMsNEJBQTRCLEVBQUVzQixhQUFhLGdDQUFnQyxFQUFFRCxXQUFXLENBQUMsQ0FBQztRQUd6SyxJQUFJQSxBQUFlLG1CQUFmQSxZQUNGdEIsaUNBQWlDQyxRQUFRbEUsT0FBT21FO0lBRXBEO0lBRUEsTUFBTXNCLHVCQUF1QixDQUMzQjFCO1FBRUEsTUFBTW1CLEtBQUtuQixRQUFRLEtBQUs7UUFHdEJsRix3QkFBd0IsQ0FBQyxxQkFBcUIsRUFBRXFHLElBQUk7UUFFdEQsSUFBSWxGO1FBQ0osSUFBSWtGLEtBQUssR0FBRztnQkFLRlEsaUNBQWdDQyxLQUFoQ0Q7WUFBUjFGLFFBQVEsUUFBQTBGLENBQUFBLElBQUFBLEFBQUFBLENBQUFBLGtDQUFBQSxLQUFNLHlCQUF5QixBQUFELENBQUMsQ0FBQ0MsTUFBQUEsR0FBRyxBQUFELElBQWxDRCxJQUFBQSwrQkFBK0IsQ0FBQ0MsSUFBRyxHQUFLUixtQkFBbUJwQjtRQUNyRSxPQUNFL0QsUUFBUTRFLEtBQU0sY0FBYyxDQUFDTSxHQUFHO1FBSWxDLElBQWVsRixBQUFVNEYsV0FBVjVGLE9BQ2IsTUFBTSxJQUFJYixNQUFNLHVDQUF1QytGO1FBRXpELE9BQU9sRjtJQUNUO0lBRUEsU0FBUzZGLDZCQUE2QlgsRUFBZ0I7UUFDcEQsT0FBT04sS0FBTSxjQUFjLENBQUNNLEdBQUc7SUFDakM7SUFFQSxTQUFTWSxvQkFDUDVCLE1BQStCLEVBQy9CbEUsS0FBYTtRQUVic0YsNkJBQTZCcEIsUUFBUWxFLE9BQU87UUFDNUM0RSxLQUFNLGNBQWMsQ0FBQ1YsT0FBTyxLQUFLLENBQUMsR0FBR2xFO0lBQ3ZDO0lBUUEsU0FBUzhFLGlCQUNQWixNQUFzQyxFQUN0Q25ELE9BQTJCO1FBRTFCMEUscUJBQXFCdkIsUUFBdUMsT0FBTyxHQUFHbkQsVUFDbkUsSUFBSWQsUUFBUWMsV0FDWjtJQUNOO0lBRUEsU0FBU2dFLGlDQUNQZ0IsS0FBa0M7UUFFbEN4QixRQUFRLG9DQUFvQztZQUMxQyxJQUFJeUI7WUFDSixJQUFJQyxXQUFXO1lBQ2ZGLE1BQU0sT0FBTyxDQUFDLENBQUMsQ0FBQ2IsSUFBSWxGLE9BQU9tRCxLQUFLO2dCQUM5QixJQUFJO29CQUNGLE1BQU1lLFNBQVM7d0JBQ2IsT0FBT2dCO3dCQUNQLFlBQVlsRjt3QkFDWixPQUFPbUQ7b0JBQ1Q7b0JBQ0EsTUFBTStDLFdBQVd0QixLQUFNLGNBQWMsQ0FBQ00sR0FBRztvQkFDekMsSUFBSWdCLFVBQ0ZaLDZCQUNFcEIsUUFDQWdDLFVBQ0E7eUJBR0Z0QixLQUFNLGNBQWMsQ0FBQ00sR0FBRyxHQUFHQyxtQkFBbUJqQjtnQkFFbEQsRUFBRSxPQUFPN0UsT0FBTztvQkFDZCxJQUFJLENBQUM0RyxVQUFVO3dCQUNiRCxhQUFhM0c7d0JBQ2I0RyxXQUFXO29CQUNiO2dCQUNGO1lBQ0Y7WUFDQSxJQUFJQSxVQUNGLE1BQU1EO1FBRVY7SUFDRjtJQUVBLFNBQVNoQjtRQUNQSixLQUFNLHlCQUF5QixHQUFHLENBQUM7SUFDckM7SUN0TUEsU0FBU3VCO1FBQ1AsTUFBTUMsWUFBWWhFLEtBQUssWUFBWTtRQUNuQ2dFLFVBQVUsZ0JBQWdCLENBQ3hCdkQsOEJBQ0EsQ0FBQ3dEO1lBQ0MsTUFBTUMsT0FBTzdFLEtBQUssS0FBSyxDQUFDNEUsTUFBTSxJQUFJO1lBQ2xDN0QsdUJBQXVCOEQsS0FBSyxPQUFPLEVBQUVBLEtBQUssTUFBTSxFQUF3QkEsS0FBSyxTQUFTO1FBQ3hGO1FBRUZGLFVBQVUsZ0JBQWdCLENBQ3hCdkQsa0NBQ0EsQ0FBQ3dEO1lBQ0NSLDZCQUE4QlEsTUFBTSxJQUFJLENBQTJCLEVBQUU7UUFDdkU7SUFFSjtJQ0xBLElBQUl6QjtJQUVKLFNBQVMyQjtRQUNQLE9BQVEzQiw0QkFBTztZQUNiLGdDQUFnQyxFQUFFO1lBQ2xDNEI7WUFDQUM7WUFDQUM7UUFDRjtJQUNGO0lBRUEsU0FBU0QscUJBQXFCRSxLQUFpQixFQUFFbEUsSUFBNEM7WUFFdEVtRSxRQUFBQTtRQURyQmhDLDBCQUFNLDhCQUE4QixDQUFDLElBQUksQ0FBQztZQUFFbkM7UUFBSztRQUNqRCxNQUFNb0UsZUFBZSxRQUFBRCxDQUFBQSxpQkFBQUEsQUFBQUEsQ0FBQUEsU0FBQUEsS0FBSSxFQUFFLGFBQWEsQUFBRCxJQUFsQkEsaUJBQUFBLE9BQU0sYUFBYSxHQUFLLEVBQUU7UUFDL0NDLGFBQWEsSUFBSSxDQUFDakMsMEJBQU0sOEJBQThCLENBQUMsTUFBTSxHQUFHO0lBQ2xFO0lBRUEsU0FBUzRCO1FBQ1A1QiwwQkFBTSw4QkFBOEIsQ0FBQyxNQUFNLEdBQUc7SUFDaEQ7SUFFQSxTQUFTOEI7UUFDUCxLQUFLLE1BQU1JLFdBQVdsQywwQkFBTSw4QkFBOEIsQ0FDeEQsSUFBSWtDLFFBQUFBLFVBQUFBLEtBQUFBLElBQUFBLFFBQVMsVUFBVSxFQUNyQkEsUUFBUSxJQUFJLENBQUNBLFFBQVEsVUFBVSxDQUFDLE9BQU8sRUFBR0EsUUFBUSxVQUFVLENBQUMsT0FBTztRQUd4RU47SUFDRjtJQ3BDQSxJQUFJNUI7SUFFSixTQUFTbUM7UUFDUCxPQUFRbkMseUJBQU87WUFDYiwwQkFBMEIsSUFBSTdCO1lBQzlCaUU7WUFDQUM7UUFDRjtJQUNGO0lBRUEsU0FBU0Msc0JBQ1BDLElBQVksRUFDWmhHLE1BQTBCO1FBRTFCb0QsUUFBUSw0QkFBNEI0QyxNQUFNO1lBQ3hDLE1BQU1DLE1BQU14Qyx1QkFBTSx3QkFBd0I7WUFDMUMsTUFBTXlDLFdBQVdELElBQUksR0FBRyxDQUFDRDtZQUN6QixJQUFJRSxVQUNGQSxTQUFTLElBQUksQ0FBQ2xHO2lCQUVkaUcsSUFBSSxHQUFHLENBQUNELE1BQU07Z0JBQUNoRzthQUFPO1FBRTFCO0lBQ0Y7SUFFQSxTQUFTNkYsa0JBQWtCTSxPQUFnQixFQUFFdkcsT0FBb0I7UUFDL0R3RCxRQUFRLHdCQUF3QjtZQUM5QixNQUFNZ0QsWUFBWTNDLHVCQUFNLHdCQUF3QixDQUFDLEdBQUcsQ0FDbEQwQyxRQUFRLE9BQU87WUFFakIsSUFBSUMsQUFBYzNCLFdBQWQyQixXQUNGO1lBRUYsTUFBTUMsZ0JBQXNDLEVBQUU7WUFDOUNELFVBQVUsT0FBTyxDQUFDLENBQUNwRztvQkFFYnNHO2dCQURKLE1BQU1DLGFBQWF2RyxNQUFNLENBQUMsRUFBRTtnQkFDNUIsSUFBSXNHLEFBQUFBLENBQUFBLFFBQUFBLGFBQUFBLEtBQUFBLElBQUFBLFFBQUFBLENBQUFBLDRCQUFBQSxXQUFZLGFBQWEsQUFBRCxJQUF4QkEsS0FBQUEsSUFBQUEsMEJBQTJCLGFBQWEsQUFBRCxNQUFNMUcsU0FDL0NoQyxXQUFXO29CQUNUd0YsUUFBUSxxQkFBcUI7d0JBQzNCM0IsV0FBVzBFLFNBQVNuRztvQkFDdEI7Z0JBQ0YsR0FBRztxQkFFSHFHLGNBQWMsSUFBSSxDQUFDckc7WUFFdkI7WUFDQXlELHVCQUFNLHdCQUF3QixDQUFDLEdBQUcsQ0FDaEMwQyxRQUFRLE9BQU8sRUFDZkU7UUFFSjtJQUNGO0lBRUEsU0FBU1A7UUFDUHJDLHVCQUFNLHdCQUF3QixDQUFDLEtBQUs7SUFDdEM7SUMxRE8sU0FBUytDO1FBQ2QsT0FBTztZQUNMNUgsZ0JBQWNBO1FBQ2hCO0lBQ0Y7SUNMTyxNQUFNNkgsY0FBYztRQUN6QixVQUFVO1FBQ1Ysc0JBQXNCO1FBQ3RCLCtCQUErQjtJQUNqQztJQUlPLFNBQVNDLGNBQ2RDLEdBQXVCLEVBQ3ZCakssT0FBMkI7UUFFM0IsSUFBSSxDQUFDa0ssTUFBTSxPQUFPLENBQUNELFFBQVEsQUFBa0IsWUFBbEIsT0FBT0EsR0FBRyxDQUFDLEVBQUUsSUFBaUJBLEFBQVcsU0FBWEEsR0FBRyxDQUFDLEVBQUUsRUFDN0QsT0FBTztRQUVULElBQUlqSyxXQUFXQSxBQUFtQm1LLE1BQW5CbkssUUFBUSxNQUFNLEVBQzNCLE9BQU87UUFFVCxPQUFPO0lBQ1Q7SUFRTyxTQUFTb0ssd0JBQXdCSCxHQUF1QixFQUFFakssT0FBMkI7UUFDMUYsSUFBSSxDQUFDZ0ssY0FBY0MsS0FBS2pLLFVBQ3RCLE9BQU87WUFBQztZQUFPLENBQUM7U0FBRTtRQUVwQixNQUFNcUssV0FBcUIsQ0FBQztRQUM1QixNQUFNQyxXQUFXTCxHQUFHLENBQUMsRUFBRTtRQUd2QkssUUFBUSxDQUFDLGtCQUFrQixHQUFHO2dCQUNHQztZQUEvQkYsU0FBUyxrQkFBa0IsR0FBRyxBQUFDLFNBQUFFLENBQUFBLCtCQUFBQSxTQUFTLGtCQUFrQixBQUFELElBQTFCQSwrQkFBK0JSLFlBQVksUUFBUSxBQUFELElBQzdFQSxZQUFZLG9CQUFvQjtRQUN0QztRQUdBTyxRQUFRLENBQUMsMkJBQTJCLEdBQUc7Z0JBQ05DO1lBQS9CRixTQUFTLGtCQUFrQixHQUFHLEFBQUMsU0FBQUUsQ0FBQUEsK0JBQUFBLFNBQVMsa0JBQWtCLEFBQUQsSUFBMUJBLCtCQUErQlIsWUFBWSxRQUFRLEFBQUQsSUFDN0VBLFlBQVksNkJBQTZCO1FBQy9DO1FBRUEsT0FBTztZQUFDO1lBQU1NO1NBQVM7SUFDekI7SUMvQk8sU0FBU0csV0FBV1AsR0FBWSxFQUFFUSxjQUF1QjtRQUM5RC9ELFFBQVEsY0FBYztZQUNwQmdFLGVBQWVULEtBQUtRLGdCQUFnQlIsSUFBSSxPQUFPO1FBQ2pEO0lBQ0Y7SUFFQSxTQUFTUyxlQUNQVCxHQUFxQixFQUNyQlEsY0FBZ0MsRUFDaENFLE1BQWM7UUFFZCxJQUNFLENBQUNWLE9BQU8sQUFBZSxZQUFmLE9BQU9BLE9BQW9CLENBQUNRLGtCQUNqQyxBQUEwQixZQUExQixPQUFPQSxnQkFDVjtRQUVGLE1BQU1HLFNBQVNYO1FBQ2YsTUFBTVksb0JBQW9CSjtRQUUxQixJQUFJRyxNQUFNLENBQUMsVUFBVSxJQUFJQSxNQUFNLENBQUMsVUFBVSxLQUFLQyxpQkFBaUIsQ0FBQyxVQUFVLEVBQ3pFO1FBTUYsSUFBSUMsNEJBQTRCRixTQUFTLFlBQ3ZDRywwQkFBMEJILFFBQVFDO1FBR3BDLElBQUssTUFBTW5JLE9BQU91SCxJQUNoQixJQUFJdkgsQUFBUSxZQUFSQSxLQUNGc0kscUJBQ0VKLE1BQU0sQ0FBQ2xJLElBQUksRUFDWG1JO2FBRUcsSUFBSW5JLEFBQVEsWUFBUkEsS0FDVHVJLGlDQUNFTCxNQUFNLENBQUNsSSxJQUFJLEVBQ1htSSxpQkFBaUIsQ0FBQ25JLElBQUksRUFDdEJpSTthQUVHO1lBQ0wsTUFBTU8sbUJBQW1CLEFBQWtDLGNBQWxDLE9BQU9MLGlCQUFpQixDQUFDbkksSUFBSSxHQUNqRG1JLGlCQUFpQixDQUFDbkksSUFBSSxDQUEyQixRQUFRLEdBQzFEbUksaUJBQWlCLENBQUNuSSxJQUFJO1lBQzFCZ0ksZUFBZUUsTUFBTSxDQUFDbEksSUFBSSxFQUFFd0ksa0JBQWtCUDtRQUNoRDtJQUVKO0lBRUEsU0FBU0csNEJBQ1AzSSxLQUFhO1FBRWIsTUFBTWdKLGFBQWFoSjtRQUNuQixPQUFPLEFBQTRCLFlBQTVCLE9BQU9nSixXQUFXLEtBQUssSUFDekIsQUFBNEIsWUFBNUIsT0FBT0EsV0FBVyxLQUFLO0lBQzlCO0lBT0EsU0FBU0gscUJBQ1BJLEtBQW1CLEVBQ25CakosS0FBOEI7UUFFOUIsSUFBSSxnQkFBZ0JBLE9BQ2xCO1FBRUYwRCxnQkFBaUIsUUFBUSxDQUFDLGNBQWMsQ0FBQ3VGLE1BQU0sR0FBR2pKO0lBQ3BEO0lBTUEsU0FBUzRJLDBCQUNQMUUsTUFBK0IsRUFDL0JsRSxLQUF1QjtRQUV2QixJQUFJLENBQUNxRix1QkFBdUJyRixRQUUxQjtRQUVGOEYsb0JBQW9CNUIsUUFBUWxFO0lBQzlCO0lBUUEsU0FBUzhJLGlDQUNQSSxNQUFrQyxFQUNsQ0MsaUJBQTZDLEVBQzdDWCxNQUFjO1FBRWQsSUFBSyxNQUFNWSxVQUFVRixPQUFRO1lBQzNCLE1BQU12QyxRQUFRdUMsTUFBTSxDQUFDRSxPQUFPO1lBQzVCLE1BQU1DLG1CQUEyQ0YsaUJBQWlCLENBQUNDLE9BQU87WUFDMUUsSUFBSSxDQUFDQyxDQUFBQSxRQUFBQSxtQkFBQUEsS0FBQUEsSUFBQUEsaUJBQWtCLGFBQWEsQUFBRCxHQUFHO2dCQUNwQyxJQUFJQSxrQkFBa0I7b0JBQ3BCQSxpQkFBaUIsY0FBYyxHQUFHO29CQUNsQ0EsaUJBQWlCLE9BQU8sR0FBR2I7b0JBQzNCbEksT0FBTyxNQUFNLENBQUMrSSxrQkFBa0IxQztnQkFDbEM7Z0JBQ0E7WUFDRjtZQUNBLEtBQUssTUFBTTJDLFNBQVNELGlCQUFpQixhQUFhLENBQUU7Z0JBQ2xELE1BQU12QyxVQUFVcEQsZ0JBQWlCLHlCQUF5QixDQUN2RCw4QkFBOEIsQ0FBQzRGLE1BQU07Z0JBQ3hDLElBQUt4QztvQkFHTEgsTUFBTSxPQUFPLEdBQUc2QjtvQkFDaEIxQixRQUFRLFVBQVUsR0FBR0g7O1lBQ3ZCO1FBQ0Y7SUFDRjs7Ozs7Ozs7Ozs7SUNwSUEsTUFBTTRDO1FBV0osT0FBT2YsTUFBYyxFQUFFZ0IsUUFBZ0IsRUFBUTtnQkFPMUNDO1lBTkgsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQ0QsV0FDM0I7WUFFRixJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQ0E7WUFDekIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQ3JCaEIsUUFDQSxBQUFDLFNBQUFpQixDQUFBQSwyQkFBQUEsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUNqQixPQUFNLElBQTlCaUIsMkJBQW1DLEtBQUs7WUFFM0MsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUNELFVBQVVoQjtRQUNuQztRQUVBLFVBQVVBLE1BQWMsRUFBUTtZQUM5QixNQUFNa0IsS0FBSyxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQ2xCO1lBQ25DLElBQUlrQixLQUFLLEdBQUcsWUFDVixJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQ2xCLFFBQVFrQixLQUFLO1lBR3ZDLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDbEI7WUFDM0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUNBO1lBQ3pCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO2dCQUNsQixJQUFJLENBQUMsUUFBUSxHQUFHO2dCQUNYcEgsUUFBUSxPQUFPLEdBQUcsSUFBSSxDQUFDO29CQUMxQixJQUFJLENBQUMsSUFBSTtnQkFDWDtZQUNGO1FBQ0Y7UUFFQSxPQUFhO1lBQ1htRCxRQUFRLG1DQUFtQztnQkFDekNuQyxLQUFLLFlBQVksR0FBRyxhQUFhLENBQUM7b0JBQ2hDLE1BQU1TO29CQUNOLE1BQU1rRixNQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZTtnQkFDdkM7Z0JBQ0EsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLO2dCQUMxQixJQUFJLENBQUMsUUFBUSxHQUFHO1lBQ2xCO1FBQ0Y7UUF6Q0EsYUFBYztZQU5kLDBDQUFRLGtCQUFpQixJQUFJaEY7WUFDN0IsMENBQVEsbUJBQWtCLElBQUk0RztZQUM5QiwwQ0FBUSxtQkFBa0IsSUFBSUM7WUFDOUIsMENBQVEsWUFBVztZQUNuQiwwQ0FBUSxZQUFSO1lBR0UsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJQyxxQkFBNkIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSTtRQUMzRTtJQXdDRjtJQUVBLFNBQVNDO1FBQ1AsT0FBT3hLLGVBQWUsR0FBRztJQUMzQjtJQ2hEQSxTQUFTeUs7UUFDUDFILFdBQVcsZUFBZSxHQUFHO1lBQzNCLGFBQWEsQ0FBQztZQUNkLFVBQVV3QztZQUNWLDJCQUEyQjBCO1lBQzNCLGFBQWE4QjtZQUNiLGlCQUFpQnRCO1lBQ2pCLFVBQVVZO1lBQ1YseUJBQXlCbkY7UUFDM0I7UUFFQSxJQUFJc0gsNEJBQ0Z6SCxXQUFXLGVBQWUsQ0FBQywyQkFBMkIsR0FBRyxJQUFJa0g7UUFHL0RsSCxXQUFXLGVBQWUsR0FBRzJIO1FBQzdCM0gsV0FBVyx1QkFBdUIsR0FBRzJIO1FBQ3JDM0gsV0FBVyxVQUFVLEdBQUdPO0lBQzFCO0lBU0EsU0FBU29ILGdCQUFnQkMsS0FBYSxFQUFFL0UsRUFBVSxFQUFFb0MsT0FBd0M7UUFDMUY1RCxnQkFBZ0IsV0FBVyxDQUFDd0IsR0FBRyxHQUFHb0M7SUFDcEM7SUFTQSxTQUFTMUUsMEJBQVdrRixHQUFZLEVBQUUzRyxNQUEwQixFQUFFdEQsT0FBMkI7UUFDdkYsSUFBSSxDQUFDcU0sZ0JBQWdCcEMsTUFDbkI7UUFJQSxJQUFJakssQUFBQUEsQ0FBQUEsUUFBQUEsVUFBQUEsS0FBQUEsSUFBQUEsUUFBUyxNQUFNLEFBQUQsTUFBTW1LLEtBQTBCRCxNQUFNLE9BQU8sQ0FBQzVHLFNBQVM7WUFDdkUsTUFBTWdKLFFBQVFoSixNQUFNLENBQUMsRUFBRTtZQUN2QixNQUFNaUosSUFBS0QsTUFBNkIsSUFBSTtZQUM1QyxJQUFJLEFBQWEsWUFBYixPQUFPQyxHQUNUdkwsd0JBQXdCLENBQUMsTUFBTSxFQUFFdUwsR0FBRztRQUV4QztRQUVBdkwsd0JBQXdCLENBQUMsc0JBQXNCLEVBQUV3TCxPQUFPdkMsSUFBSSxPQUFPLEdBQUc7UUFHeEUsSUFBSSx1QkFBdUJBLEtBQUssWUFDOUJaLHNCQUFzQlksSUFBSSxpQkFBaUIsRUFBRTNHO1FBRy9DLE9BQU9tSixlQUFleEMsS0FBSzNHLFFBQVF0RDtJQUNyQztJQUVBLFNBQVN5TSxlQUFleEMsR0FBWSxFQUFFM0csTUFBMEIsRUFBRXRELE9BQTJCO1FBQzNGLE1BQU15SixVQUEyQy9DLFFBQy9DLHlCQUF5QnVELElBQUksT0FBTyxFQUNwQyxJQUFNeUMsaUJBQWlCekMsS0FBSztRQUU5QixNQUFNMEMsVUFBOEJqRyxRQUNsQywwQkFDQSxJQUFNZ0csaUJBQWlCcEosVUFBVSxFQUFFLEVBQUU7UUFHdkMsTUFBTSxDQUFDc0osaUJBQWlCdkMsU0FBUyxHQUFHRCx3QkFBd0J1QyxTQUFTM007UUFFckUsTUFBTTZNLFNBQVNuRyxRQUFRLGNBQWMsSUFBTStDLFdBQVdrRDtRQUV0RCxJQUFJQyxpQkFDRixPQUFPO1lBQ0wsYUFBYUM7WUFDYixtQkFBbUJ4QyxTQUFTLGtCQUFrQjtRQUNoRDtRQUdGLE9BQU93QztJQUNUO0lBRUEsU0FBU1IsZ0JBQWdCcEMsR0FBWTtRQUNuQyxPQUFPLEFBQWUsWUFBZixPQUFPQSxPQUFvQkEsQUFBUSxTQUFSQSxPQUFpQixjQUFhQSxPQUFPLHVCQUF1QkEsR0FBRTtJQUNsRztJQUVBLE1BQU02QyxlQUFlLFdBQVcsR0FBRyxJQUFJMUg7SUFRdkMsU0FBU3NILGlCQUNQekMsR0FBcUIsRUFDckI4QyxTQUFrQjtRQUdsQixJQUFJLEFBQWUsWUFBZixPQUFPOUMsT0FBb0JBLEFBQVEsU0FBUkEsS0FDN0IsT0FBT0E7UUFHVCxJQUFJOEMsV0FBVztZQUNiLE1BQU1wSixNQUFNbUosYUFBYSxHQUFHLENBQUM3QztZQUM3QixJQUFJdEcsS0FDRixPQUFPQTtRQUVYO1FBRUEsTUFBTThGLFVBQVV1RCxzQkFBc0I7WUFBRSxNQUFNL0M7UUFBSSxHQUFHLEdBQUdBO1FBRXhELElBQUk4QyxXQUNGRCxhQUFhLEdBQUcsQ0FBQzdDLEtBQUtSLFFBQVEsSUFBSTtRQUdwQyxPQUFPQSxRQUFRLElBQUk7SUFDckI7SUFFQSxNQUFNdUQsd0JBQXdCLENBQzVCN0ssT0FDQThLLE9BQ0FoRDtRQUVBLE1BQU03SSxRQUFRO1FBQ2QsSUFBSSxFQUFFNkwsU0FBUzdMLE9BQ2IsTUFBTSxJQUFJRSxNQUFNLHFDQUFxQ0YsUUFBUTtRQUcvRCxJQUFJLEFBQWlCLFlBQWpCLE9BQU9lLFNBQXNCQSxBQUFVLFNBQVZBLE9BQy9CLE9BQU9BO1FBRVQsSUFBSStLLE1BQU0vSztRQUVWLElBQUssTUFBTU8sT0FBT3dLLElBQUs7WUFDckIsTUFBTUMsU0FBMkJELEdBQUcsQ0FBQ3hLLElBQUk7WUFDekMsSUFBSSxBQUFrQixZQUFsQixPQUFPeUssVUFBdUJBLEFBQVcsU0FBWEEsUUFDaEM7WUFPRixJQUFJaEgsMkJBQTJCZ0gsU0FDN0I7WUFFRixJQUFJQyw2QkFBNkJELFNBQVM7Z0JBQ3hDRCxNQUFNRyx3QkFBd0JILEtBQUsvSyxPQUFPTyxLQUFLa0YscUJBQXFCdUY7Z0JBQ3BFO1lBQ0Y7WUFFQSxJQUF5QixtQkFBbUJBLFFBQVE7Z0JBQ2xERCxHQUFHLENBQUN4SyxJQUFJLEdBQUcsSUFBSU4sUUFBUStLLE9BQU8sYUFBYTtnQkFDM0M7WUFDRixPQUFPLElBQUlBLGtCQUFrQi9LLFNBQzNCO1lBR0YsTUFBTWtMLG9CQUFvQk4sc0JBQXNCRyxRQUFRRixPQUFPaEQ7WUFFL0QsTUFBTXNELGVBQWUsV0FBWUo7WUFDakMsSUFBSUksY0FBYztnQkFDaEJMLEdBQUcsQ0FBQ3hLLElBQUksR0FBR2tGLHFCQUNUdUY7Z0JBRUY7WUFDRjtZQUNBLE1BQU1KLFlBQVksYUFBYUk7WUFDL0IsSUFBSUosV0FBVztnQkFDYixNQUFNUyxnQkFBZ0JMLFdBQVdsRDtnQkFDakMsTUFBTXdELFdBQVc7b0JBQUUsR0FBR0gsaUJBQWlCO2dCQUFDO2dCQUd4QyxNQUFNSSxlQUEwRTdILGdCQUM3RSxXQUFXLENBQUVzSCxPQUFtQixPQUFPLENBQUMsQ0FDeEMsSUFBSSxDQUFDTTtnQkFDUixJQUFJSCxzQkFBc0JILFVBQVVELFFBQVEvSyxTQUFTK0ssUUFBUWpELEtBQUtpRCxNQUFNUyxvQkFBb0JUO2dCQUM1RkEsTUFBTUcsd0JBQXdCSCxLQUFLL0ssT0FBT08sS0FBS2dMO2dCQUMvQyxJQUFJLENBQUNGLGVBR0hFLGFBQWEsUUFBUSxHQUFHRDtnQkFFMUI7WUFDRjtZQUNBLElBQUlILHNCQUFzQkgsUUFBUTtnQkFFaEMsSUFBSUQsUUFBUS9LLFNBQVMrSyxRQUFRakQsS0FBS2lELE1BQU1TLG9CQUFvQlQ7Z0JBQzVEQSxNQUFNRyx3QkFBd0JILEtBQUsvSyxPQUFPTyxLQUFLNEs7WUFDakQ7WUFDQSxNQUFNTSxTQUFTLGFBQWFUO1lBQzVCLElBQUlTLFFBQVE7b0JBRVZDO2dCQURDVixNQUEyQyxDQUFDLFVBQVUsR0FBSWxELElBQWdCLE9BQU87d0JBQ2xGNEQsQ0FBQUEsK0NBQUFBLGdCQUFnQiwyQkFBMkIsQUFBRCxLQUExQ0EsNkNBQTZDLE1BQU0sQ0FDaEQ1RCxJQUFnQixPQUFPLEVBQ3hCa0Q7Z0JBRUY7WUFDRjtRQUNGO1FBQ0EsT0FBT0Q7SUFDVDtJQUVBLFNBQVNHLHdCQUNQSCxHQUFxQyxFQUNyQ1ksTUFBYyxFQUNkcEwsR0FBVyxFQUNYUCxLQUF1QjtRQUV2QixNQUFNZ0osYUFBYTFJLE9BQU8sd0JBQXdCLENBQUN5SyxLQUFLeEs7UUFDeEQsSUFBSXlJLFFBQUFBLGFBQUFBLEtBQUFBLElBQUFBLFdBQVksR0FBRyxFQUFFO1lBR25CLE1BQU00QyxxQkFBcUI7Z0JBQ3pCNUw7Z0JBQ0EsVUFBVTtnQkFDVixZQUFZZ0osV0FBVyxVQUFVO2dCQUNqQyxjQUFjQSxXQUFXLFlBQVk7WUFDdkM7WUFDQSxJQUFJK0IsUUFBUVksVUFBVSxDQUFDM0MsV0FBVyxZQUFZLEVBQUU7Z0JBRTlDLE1BQU02QyxjQUFjdkwsT0FBTyx5QkFBeUIsQ0FBQ3lLO2dCQUNyRGMsV0FBVyxDQUFDdEwsSUFBSSxHQUFHcUw7Z0JBQ25CLE9BQU9KLG9CQUFvQlQsS0FBS2M7WUFDbEM7WUFDQXZMLE9BQU8sY0FBYyxDQUFDeUssS0FBS3hLLEtBQUtxTDtRQUNsQyxPQUNFYixHQUFHLENBQUN4SyxJQUFJLEdBQUdQO1FBRWIsT0FBTytLO0lBQ1Q7SUFFQSxTQUFTUyxvQkFDUFQsR0FBcUMsRUFDckNjLGNBQXFDdkwsT0FBTyx5QkFBeUIsQ0FBQ3lLLElBQUk7UUFJMUUsT0FBT3pLLE9BQU8sZ0JBQWdCLENBQzVCeUgsTUFBTSxPQUFPLENBQUNnRCxPQUNWLEVBQUUsR0FDRnpLLE9BQU8sTUFBTSxDQUFDQSxPQUFPLGNBQWMsQ0FBQ3lLLE9BQ3hDYztJQUVKO0lBRUEsU0FBU1osNkJBQ1BqTCxLQUFhO1FBRWIsTUFBTWdKLGFBQWFoSjtRQUNuQixPQUFPLEFBQTRCLFlBQTVCLE9BQU9nSixXQUFXLEtBQUssSUFDekIsQUFBNEIsWUFBNUIsT0FBT0EsV0FBVyxLQUFLLElBQ3ZCQSxBQUFxQixrQkFBckJBLFdBQVcsS0FBSztJQUN2QjtJQzdRQSxJQUFJM0csQUFBK0J1RCxXQUEvQnZELFdBQVcsZUFBZSxFQUFnQjtRQUM1QzBIO1FBQ0E3SDtRQUNBaUU7SUFDRiJ9