import '../../lazy/import.js';

import { describe, expect, onTestFinished, test, vi } from 'vitest';
import * as ReactExports from '../../lazy/react.js';
import * as ReactCompatExports from '../../lazy/compat.js';
import * as ReactLepusExports from '../../lazy/react-lepus.js';
import * as ReactInternalExports from '../../lazy/internal.js';
import * as ReactJSXRuntimeExports from '../../lazy/jsx-runtime.js';
import * as ReactJSXDevRuntimeExports from '../../lazy/jsx-dev-runtime.js';
import * as ReactLegacyReactRuntimeExports from '../../lazy/legacy-react-runtime.js';
import {
  sExportsReact,
  sExportsReactCompat,
  sExportsReactInternal,
  sRuntimeBackend,
  target,
} from '../../lazy/target.js';
const {
  RUNTIME_BACKEND_ELEMENT_TEMPLATE,
  RUNTIME_BACKEND_SNAPSHOT,
  registerRuntimeBackend,
} = ReactInternalExports;

function restoreDescriptor(target, symbol, descriptor) {
  if (descriptor) {
    Object.defineProperty(target, symbol, descriptor);
  } else {
    delete target[symbol];
  }
}

async function withRuntimeBackend(backend, callback) {
  const descriptor = Object.getOwnPropertyDescriptor(target, sRuntimeBackend);
  if (backend === undefined) {
    delete target[sRuntimeBackend];
  } else {
    Object.defineProperty(target, sRuntimeBackend, {
      value: backend,
      enumerable: false,
      writable: false,
      configurable: true,
    });
  }

  try {
    return await callback();
  } finally {
    restoreDescriptor(target, sRuntimeBackend, descriptor);
  }
}

async function withoutRecordedRuntimeVersion(callback) {
  const symbol = Symbol.for('__REACT_LYNX_RUNTIME_VERSION__');
  const descriptor = Object.getOwnPropertyDescriptor(target, symbol);
  delete target[symbol];

  try {
    return await callback();
  } finally {
    restoreDescriptor(target, symbol, descriptor);
  }
}

describe('Lazy Exports', () => {
  test('export APIs from "react"', async () => {
    const realAPIs = Object.assign(
      {},
      await import('@lynx-js/react'),
    );

    expect(
      new Set(Object.keys(ReactExports)),
    ).toStrictEqual(
      new Set(Object.keys(realAPIs)),
    );
  });

  test('export APIs from "react/compat"', async () => {
    const realAPIs = Object.assign(
      {},
      await import('@lynx-js/react/compat'),
    );

    expect(
      new Set(Object.keys(ReactCompatExports)),
    ).toStrictEqual(
      new Set(Object.keys(realAPIs)),
    );
  });

  test('export APIs from "react/lepus"', async () => {
    const realAPIs = Object.assign(
      {},
      await import('@lynx-js/react/lepus'),
    );

    expect(
      new Set(Object.keys(ReactLepusExports)),
    ).toStrictEqual(
      new Set(Object.keys(realAPIs)),
    );
  });

  test('export APIs from "internal"', async () => {
    const realAPIs = Object.assign(
      {},
      await import('@lynx-js/react/internal'),
    );

    expect(
      new Set(Object.keys(ReactInternalExports)),
    ).toStrictEqual(
      new Set(Object.keys(realAPIs)),
    );
  });

  test('export APIs from "jsx-runtime"', async () => {
    const realAPIs = Object.assign(
      {},
      await import('@lynx-js/react/jsx-runtime'),
    );

    expect(
      new Set(Object.keys(ReactJSXRuntimeExports)),
    ).toStrictEqual(
      new Set(Object.keys(realAPIs)),
    );
  });

  test('export APIs from "jsx-dev-runtime"', async () => {
    const realAPIs = Object.assign(
      {},
      await import('@lynx-js/react/jsx-dev-runtime'),
    );

    expect(
      new Set(Object.keys(ReactJSXDevRuntimeExports)),
    ).toStrictEqual(
      new Set(Object.keys(realAPIs)),
    );
  });

  test('export APIs from "legacy-react-runtime"', async () => {
    const realAPIs = Object.assign(
      {},
      await import('@lynx-js/react/legacy-react-runtime'),
    );

    expect(
      new Set(Object.keys(ReactLegacyReactRuntimeExports)),
    ).toStrictEqual(
      new Set(Object.keys(realAPIs)),
    );
  });

  test('forwards MainThreadObject lazy exports from the host runtime', () => {
    expect(ReactExports.defineMainThreadObjectType).toBe(
      target[sExportsReact].defineMainThreadObjectType,
    );
    expect(ReactExports.useMainThreadObject).toBe(target[sExportsReact].useMainThreadObject);
    expect(ReactCompatExports.defineMainThreadObjectType).toBe(
      target[sExportsReactCompat].defineMainThreadObjectType,
    );
    expect(ReactCompatExports.useMainThreadObject).toBe(
      target[sExportsReactCompat].useMainThreadObject,
    );
    expect(ReactInternalExports.captureMainThreadObject).toBe(
      target[sExportsReactInternal].captureMainThreadObject,
    );
  });

  test('registers a MainThreadObject type while evaluating a lazy MTS module', () => {
    const originalJS = globalThis.__JS__;
    const originalLepus = globalThis.__LEPUS__;
    const originalMainThread = globalThis.__MAIN_THREAD__;
    const originalBackground = globalThis.__BACKGROUND__;
    const originalWorkletImpl = globalThis.lynxWorkletImpl;
    const registerMainThreadObjectType = vi.fn();
    const create = value => ({ value });

    globalThis.__JS__ = false;
    globalThis.__LEPUS__ = true;
    globalThis.__MAIN_THREAD__ = true;
    globalThis.__BACKGROUND__ = false;
    globalThis.lynxWorkletImpl = {
      _refImpl: {
        registerMainThreadObjectType,
      },
    };

    try {
      ReactExports.defineMainThreadObjectType({
        type: '@test/lazy-module-evaluation',
        create,
      });

      expect(registerMainThreadObjectType).toHaveBeenCalledWith(
        '@test/lazy-module-evaluation',
        create,
      );
    } finally {
      globalThis.__JS__ = originalJS;
      globalThis.__LEPUS__ = originalLepus;
      globalThis.__MAIN_THREAD__ = originalMainThread;
      globalThis.__BACKGROUND__ = originalBackground;
      globalThis.lynxWorkletImpl = originalWorkletImpl;
    }
  });

  test('target background', async () => {
    vi.resetModules();

    const lynx = {};
    vi.stubGlobal('lynx', lynx);
    onTestFinished(() => vi.unstubAllGlobals());
    vi.stubGlobal('__LEPUS__', false);

    const { target } = await import('../../lazy/target.js');
    expect(target).toBe(lynx);
  });

  test('target main-thread', async () => {
    vi.resetModules();

    vi.stubGlobal('__LEPUS__', true);

    const { target } = await import('../../lazy/target.js');
    expect(target).toBe(globalThis);
  });

  test('records the Snapshot backend for the standalone lazy import', () => {
    expect(target[sRuntimeBackend]).toBe(RUNTIME_BACKEND_SNAPSHOT);
  });

  test('records a stamped runtime version from the host runtime marker', async () => {
    await withoutRecordedRuntimeVersion(async () => {
      vi.stubGlobal('__RUNTIME_VERSION__', '1.2.0');
      onTestFinished(() => vi.unstubAllGlobals());
      vi.resetModules();

      await import('../../src/runtime-marker.ts');

      expect(ReactInternalExports.getRuntimeVersion()).toBe('1.2.0');
    });
  });

  test('records a stamped runtime version from the standalone lazy import', async () => {
    await withoutRecordedRuntimeVersion(async () => {
      vi.stubGlobal('__RUNTIME_VERSION__', '1.2.0');
      onTestFinished(() => vi.unstubAllGlobals());
      vi.resetModules();

      await import('../../lazy/internal.js');

      expect(ReactInternalExports.getRuntimeVersion()).toBe('1.2.0');
    });
  });

  test('allows a standalone lazy import without a stamped runtime version', async () => {
    await withoutRecordedRuntimeVersion(async () => {
      vi.stubGlobal('__RUNTIME_VERSION__', undefined);
      onTestFinished(() => vi.unstubAllGlobals());
      vi.resetModules();

      await import('../../lazy/internal.js');

      expect(ReactInternalExports.getRuntimeVersion()).toBeUndefined();
    });
  });

  test('records a lazy backend when no main template marker exists', async () => {
    await withRuntimeBackend(undefined, () => {
      registerRuntimeBackend(RUNTIME_BACKEND_SNAPSHOT);

      expect(target[sRuntimeBackend]).toBe(RUNTIME_BACKEND_SNAPSHOT);
    });
  });

  test('allows matching lazy backend registration', () => {
    expect(() => registerRuntimeBackend(RUNTIME_BACKEND_SNAPSHOT)).not.toThrow();
  });

  test('throws when a lazy bundle backend does not match the main template backend', () => {
    expect(() => registerRuntimeBackend(RUNTIME_BACKEND_ELEMENT_TEMPLATE)).toThrow(
      'Snapshot and Element Template templates cannot share lazy bundles.',
    );
  });

  test('throws before ET lazy import initializes ET runtime under a Snapshot template', async () => {
    const originalUpdateCardData = lynx.getApp().updateCardData;

    await expect(import('../../lazy/element-template-import.js')).rejects.toThrow(
      'Snapshot and Element Template templates cannot share lazy bundles.',
    );
    expect(lynx.getApp().updateCardData).toBe(originalUpdateCardData);
  });

  test('throws when an ET runtime marker imports the Snapshot standalone lazy entry', async () => {
    await withRuntimeBackend(undefined, async () => {
      vi.resetModules();

      await import('../../src/element-template/runtime-marker.ts');
      expect(target[sRuntimeBackend]).toBe(RUNTIME_BACKEND_ELEMENT_TEMPLATE);

      await expect(import('../../lazy/import.js')).rejects.toThrow(
        'Snapshot and Element Template templates cannot share lazy bundles.',
      );
    });
  });
});
