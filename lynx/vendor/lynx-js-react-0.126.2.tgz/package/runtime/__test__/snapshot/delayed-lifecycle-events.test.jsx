import { describe, it, beforeAll, beforeEach, afterEach, vi } from 'vitest';
import { delayedLifecycleEvents } from '../../src/snapshot/lifecycle/event/delayLifecycleEvents';
import { flushDelayedLifecycleEvents } from '../../src/snapshot/lynx/tt';
import { __root } from '../../src/root';
import { globalEnvManager } from './utils/envManager';
import { expect } from 'vitest';
import { render } from 'preact';
import { replaceCommitHook } from '../../src/snapshot/lifecycle/patch/commit';

beforeAll(() => {
  replaceCommitHook();
});

beforeEach(() => {
  globalEnvManager.resetEnv();
});
afterEach(() => {
  vi.restoreAllMocks();
});

describe('delayedLifecycleEvents', () => {
  it('should flush', async () => {
    function Comp() {
      return <view />;
    }
    __root.__jsx = <Comp />;
    renderPage();
    globalEnvManager.switchToBackground();
    expect(__FIRST_SCREEN_SYNC_TIMING__).toMatchInlineSnapshot(`"immediately"`);
    expect(globalThis.__OnLifecycleEvent.mock.calls).toMatchInlineSnapshot(`
      [
        [
          [
            "rLynxFirstScreen",
            {
              "firstScreenEventIdSwap": {},
              "root": "{"id":-1,"type":"root","children":[{"id":-2,"type":"__snapshot_a94a8_test_1"}]}",
            },
          ],
        ],
      ]
    `);
    lynx.getApp().OnLifecycleEvent(...globalThis.__OnLifecycleEvent.mock.calls[0]);
    expect(delayedLifecycleEvents).toMatchInlineSnapshot(`
      [
        [
          "rLynxFirstScreen",
          {
            "firstScreenEventIdSwap": {},
            "root": "{"id":-1,"type":"root","children":[{"id":-2,"type":"__snapshot_a94a8_test_1"}]}",
          },
        ],
      ]
    `);
    render(
      <Comp />,
      __root,
    );
    flushDelayedLifecycleEvents();
    expect(delayedLifecycleEvents).toMatchInlineSnapshot(`[]`);
  });
});
